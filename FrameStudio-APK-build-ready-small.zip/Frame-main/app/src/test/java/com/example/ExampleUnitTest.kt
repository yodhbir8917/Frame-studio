package com.example

import com.example.model.formatShortDuration
import com.example.model.formatTimecode
import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun timecode_formatting_isCorrect() {
        val tc = formatTimecode(74.5f, 30) // 1 min, 14 sec, 15 frames
        assertEquals("00:01:14:15", tc)
    }

    @Test
    fun shortDuration_formatting_isCorrect() {
        val sd = formatShortDuration(125f) // 2 min, 5 sec
        assertEquals("02:05", sd)
    }
}
