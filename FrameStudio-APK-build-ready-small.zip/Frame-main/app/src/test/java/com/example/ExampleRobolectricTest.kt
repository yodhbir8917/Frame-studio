package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("FrameStudio", appName)
  }

  @Test
  fun `create project from gallery creates project with gallery clips and sets duration`() {
    val viewModel = com.example.viewmodel.EditorViewModel()
    val media = listOf(
      com.example.util.ExtractedMediaInfo(
        uriString = "content://media/external/video/media/101",
        displayName = "holiday_trip.mp4",
        durationSec = 14.5f
      ),
      com.example.util.ExtractedMediaInfo(
        uriString = "content://media/external/video/media/102",
        displayName = "sunset_beach.mp4",
        durationSec = 8.2f
      )
    )
    viewModel.createProjectFromGallery(
      name = "My Summer Vlog",
      ratio = com.example.model.AspectRatio.VERTICAL_9_16,
      fps = 30,
      mediaList = media
    )

    val currentProject = viewModel.uiState.value.currentProject
    org.junit.Assert.assertNotNull(currentProject)
    assertEquals("My Summer Vlog", currentProject?.name)
    assertEquals(com.example.model.AspectRatio.VERTICAL_9_16, currentProject?.aspectRatio)
    val videoTrack = currentProject?.tracks?.firstOrNull { it.type == com.example.model.TrackType.VIDEO }
    org.junit.Assert.assertNotNull(videoTrack)
    assertEquals(2, videoTrack?.clips?.size)
    assertEquals("holiday_trip.mp4", videoTrack?.clips?.get(0)?.name)
    assertEquals("content://media/external/video/media/101", videoTrack?.clips?.get(0)?.contentUri)
    assertEquals(14.5f, videoTrack?.clips?.get(0)?.durationSec ?: 0f, 0.01f)
    assertEquals(22.7f, currentProject?.durationSec ?: 0f, 0.1f)
  }

  @Test
  fun `create project with 4K resolution and toggle resolution on the fly`() {
    val viewModel = com.example.viewmodel.EditorViewModel()
    viewModel.createNewProject(
      name = "4K Cinematic Reel",
      ratio = com.example.model.AspectRatio.CINEMA_16_9,
      fps = 60,
      resolution = com.example.model.Resolution.UHD_4K
    )

    val project = viewModel.uiState.value.currentProject
    org.junit.Assert.assertNotNull(project)
    assertEquals(com.example.model.Resolution.UHD_4K, project?.resolution)

    viewModel.setProjectResolution(com.example.model.Resolution.FHD_1080P)
    assertEquals(com.example.model.Resolution.FHD_1080P, viewModel.uiState.value.currentProject?.resolution)
  }

  @Test
  fun `select clip and toggle edit tools`() {
    val viewModel = com.example.viewmodel.EditorViewModel()
    viewModel.createNewProject(
      name = "Test Project",
      ratio = com.example.model.AspectRatio.VERTICAL_9_16,
      fps = 30
    )
    val clip = viewModel.uiState.value.currentProject?.tracks?.firstOrNull()?.clips?.firstOrNull()
    org.junit.Assert.assertNotNull(clip)
    viewModel.selectClip(clip!!.id)
    assertEquals(clip.id, viewModel.uiState.value.selectedClipId)

    viewModel.toggleNoiseReduction()
    val updatedClip1 = viewModel.uiState.value.currentProject?.tracks?.flatMap { it.clips }?.firstOrNull { it.id == clip.id }
    assertEquals(true, updatedClip1?.noiseReduced)

    viewModel.toggleVoiceIsolation()
    val updatedClip2 = viewModel.uiState.value.currentProject?.tracks?.flatMap { it.clips }?.firstOrNull { it.id == clip.id }
    assertEquals(true, updatedClip2?.voiceIsolated)

    viewModel.toggleToolPanel(com.example.model.ToolPanelType.BEATS)
    assertEquals(com.example.model.ToolPanelType.BEATS, viewModel.uiState.value.activeToolPanel)
  }
}
