package com.example.util

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns

data class ExtractedMediaInfo(
    val uriString: String,
    val displayName: String,
    val durationSec: Float
) {
    val contentUri: String get() = uriString
}

object MediaUtils {
    fun extractInfo(context: Context, uri: Uri): ExtractedMediaInfo {
        var name = "Video_${System.currentTimeMillis() % 10000}.mp4"
        var durationSec = 12.0f

        try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (nameIndex != -1 && cursor.moveToFirst()) {
                    val displayName = cursor.getString(nameIndex)
                    if (!displayName.isNullOrBlank()) {
                        name = displayName
                    }
                }
            }
        } catch (_: Exception) {}

        try {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(context, uri)
            val durStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            val durMs = durStr?.toLongOrNull() ?: 12000L
            durationSec = (durMs / 1000f).coerceAtLeast(1.0f)
            retriever.release()
        } catch (_: Exception) {}

        return ExtractedMediaInfo(
            uriString = uri.toString(),
            displayName = name,
            durationSec = durationSec
        )
    }

    fun extractMultiple(context: Context, uris: List<Uri>): List<ExtractedMediaInfo> {
        return uris.map { extractInfo(context, it) }
    }
}
