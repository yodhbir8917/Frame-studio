package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.*
import com.example.ui.theme.BgPureDark
import com.example.ui.theme.FrameStudioTheme
import com.example.viewmodel.EditorViewModel
import com.example.viewmodel.ScreenDestination

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            FrameStudioTheme {
                FrameStudioApp()
            }
        }
    }
}

@Composable
fun FrameStudioApp(
    viewModel: EditorViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    // Android System Back navigation handling
    BackHandler(enabled = uiState.currentScreen != ScreenDestination.HOME) {
        viewModel.navigateBack()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BgPureDark)
    ) {
        when (uiState.currentScreen) {
            ScreenDestination.HOME -> {
                HomeScreen(
                    projects = uiState.projects,
                    onOpenProject = { viewModel.openProject(it) },
                    onCreateNewProject = { name, ratio, fps, res ->
                        viewModel.createNewProject(name, ratio, fps, res)
                    },
                    onCreateProjectFromGallery = { name, ratio, fps, res, mediaList ->
                        viewModel.createProjectFromGallery(name, ratio, fps, res, mediaList)
                    },
                    onNavigateTab = { dest -> viewModel.navigateTo(dest) }
                )
            }
            ScreenDestination.EDITOR -> {
                EditorScreen(
                    uiState = uiState,
                    viewModel = viewModel,
                    onBack = { viewModel.navigateBack() },
                    onNavigateExport = { viewModel.navigateTo(ScreenDestination.EXPORT) },
                    onNavigateMedia = { viewModel.navigateTo(ScreenDestination.MEDIA_LIBRARY) }
                )
            }
            ScreenDestination.MEDIA_LIBRARY -> {
                MediaLibraryScreen(
                    mediaItems = uiState.mediaItems,
                    selectedIds = uiState.selectedMediaIds,
                    onToggleSelect = { viewModel.toggleMediaSelection(it) },
                    onClearSelection = { viewModel.clearMediaSelection() },
                    onAddSelected = { viewModel.addSelectedMediaToProject() },
                    onImportFromGallery = { viewModel.importMediaFromGallery(it) },
                    onBack = { viewModel.navigateBack() },
                    onNavigateTab = { dest -> viewModel.navigateTo(dest) }
                )
            }
            ScreenDestination.EXPORT -> {
                ExportScreen(
                    uiState = uiState,
                    viewModel = viewModel,
                    onBack = { viewModel.navigateBack() }
                )
            }
            ScreenDestination.TEMPLATES -> {
                TemplatesScreen(
                    templates = uiState.templates,
                    onSelectTemplate = { template ->
                        viewModel.createNewProject(
                            name = "${template.title} Sequence",
                            ratio = template.aspectRatio,
                            fps = 24
                        )
                    },
                    onBack = { viewModel.navigateBack() },
                    onNavigateTab = { dest -> viewModel.navigateTo(dest) }
                )
            }
            ScreenDestination.SETTINGS -> {
                SettingsScreen(
                    uiState = uiState,
                    viewModel = viewModel,
                    onNavigateTab = { dest -> viewModel.navigateTo(dest) }
                )
            }
        }
    }
}
