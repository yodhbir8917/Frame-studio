package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.model.*
import com.example.ui.theme.*

@Composable
fun TimelineView(
    project: Project,
    currentTimeSec: Float,
    selectedClipId: String?,
    timelineZoom: Float, // px per sec
    onSeek: (Float) -> Unit,
    onSelectClip: (String?) -> Unit,
    onAddAudio: () -> Unit,
    onAddText: () -> Unit,
    onAddMedia: () -> Unit,
    onToggleMuteClip: () -> Unit,
    onAiClipperClick: () -> Unit,
    onCoverClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val totalDuration = project.durationSec.coerceAtLeast(30f)
    val timelineWidthDp = (totalDuration * timelineZoom).dp.coerceAtLeast(1000.dp)
    val scrollState = rememberScrollState()

    // Sync scroll when playhead moves beyond view
    LaunchedEffect(currentTimeSec) {
        val playheadPx = (currentTimeSec * timelineZoom)
        val viewportPx = 800
        if (playheadPx > scrollState.value + viewportPx - 100) {
            scrollState.animateScrollTo((playheadPx - viewportPx / 2).toInt().coerceAtLeast(0))
        }
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(TrackBg)
    ) {
        // Fixed Left Header Column (Mute clip, AI clipper, Cover, ♪, T)
        TimelineLeftHeaderColumn(
            isMuted = project.isAudioMutedGlobally,
            coverThumbnailRes = project.thumbnailRes,
            onToggleMute = onToggleMuteClip,
            onAiClipper = onAiClipperClick,
            onCover = onCoverClick,
            onAudioHeaderClick = onAddAudio,
            onTextHeaderClick = onAddText
        )

        VerticalDivider(thickness = 1.dp, color = PanelBorder)

        // Right Scrollable Timeline Tracks
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(scrollState)
                    .width(timelineWidthDp + 200.dp)
            ) {
                // 1. Timecode Ruler with tick marks
                TimecodeRuler(
                    durationSec = totalDuration,
                    zoom = timelineZoom,
                    fps = project.fps,
                    onSeek = onSeek,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(28.dp)
                )

                HorizontalDivider(thickness = 0.8.dp, color = PanelBorder)

                // 2. Primary Video Track (Filmstrip Style with [+] button at end)
                val videoTrack = project.tracks.firstOrNull { it.type == TrackType.VIDEO }
                if (videoTrack != null) {
                    VideoFilmstripTrackView(
                        track = videoTrack,
                        zoom = timelineZoom,
                        selectedClipId = selectedClipId,
                        onSelectClip = onSelectClip,
                        onAddMedia = onAddMedia,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(68.dp)
                    )
                    HorizontalDivider(thickness = 0.8.dp, color = PanelBorderSubtle)
                }

                // 3. Audio Track Row (with + Add Audio row button)
                val audioTrack = project.tracks.firstOrNull { it.type == TrackType.AUDIO }
                AudioTrackRowWithAction(
                    track = audioTrack,
                    zoom = timelineZoom,
                    selectedClipId = selectedClipId,
                    onSelectClip = onSelectClip,
                    onAddAudio = onAddAudio,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                )

                HorizontalDivider(thickness = 0.8.dp, color = PanelBorderSubtle)

                // 4. Text Track Row (with + Add Text row button)
                val textTrack = project.tracks.firstOrNull { it.type == TrackType.TEXT }
                TextTrackRowWithAction(
                    track = textTrack,
                    zoom = timelineZoom,
                    selectedClipId = selectedClipId,
                    onSelectClip = onSelectClip,
                    onAddText = onAddText,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(40.dp)
                )
            }

            // Draggable White Playhead overlay across scrollable tracks
            Box(
                modifier = Modifier
                    .offset(x = (currentTimeSec * timelineZoom).dp - scrollState.value.dp)
                    .fillMaxHeight()
                    .width(28.dp)
                    .offset(x = (-14).dp)
                    .pointerInput(totalDuration, timelineZoom) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            val deltaSec = dragAmount.x / timelineZoom
                            val next = (currentTimeSec + deltaSec).coerceIn(0f, totalDuration)
                            onSeek(next)
                        }
                    }
            ) {
                // Playhead Pin Cursor at top
                Canvas(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .size(width = 16.dp, height = 20.dp)
                ) {
                    val path = Path().apply {
                        moveTo(0f, 0f)
                        lineTo(size.width, 0f)
                        lineTo(size.width, size.height * 0.6f)
                        lineTo(size.width / 2f, size.height)
                        lineTo(0f, size.height * 0.6f)
                        close()
                    }
                    drawPath(path, color = Color.White)
                }

                // Thin vertical playhead line
                Box(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 18.dp)
                        .fillMaxHeight()
                        .width(1.5.dp)
                        .background(Color.White)
                )
            }
        }
    }
}

/**
 * Fixed left column shown in CapCut video:
 * Contains Mute clip, AI clipper, Cover, and Audio (♪), Text (T) track headers
 */
@Composable
fun TimelineLeftHeaderColumn(
    isMuted: Boolean,
    coverThumbnailRes: Int,
    onToggleMute: () -> Unit,
    onAiClipper: () -> Unit,
    onCover: () -> Unit,
    onAudioHeaderClick: () -> Unit,
    onTextHeaderClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .width(128.dp)
            .fillMaxHeight()
            .background(PanelDark)
    ) {
        // Aligned with Timecode Ruler height
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(28.dp)
                .background(PanelDarkElevated)
                .padding(horizontal = 6.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Text(
                text = "TRACKS",
                style = TimecodeStyleSmall,
                color = TextMuted,
                fontSize = 9.sp,
                letterSpacing = 1.sp
            )
        }

        HorizontalDivider(thickness = 0.8.dp, color = PanelBorder)

        // Aligned with Video Track (height 68.dp): Mute clip, AI clipper, Cover
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(68.dp)
                .padding(horizontal = 2.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 1. Mute Clip
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .clickable(onClick = onToggleMute)
                    .padding(2.dp)
            ) {
                Icon(
                    imageVector = if (isMuted) Icons.Outlined.VolumeOff else Icons.Outlined.VolumeUp,
                    contentDescription = "Mute clip",
                    tint = if (isMuted) AccentCoolBlue else TextSecondary,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = if (isMuted) "Unmute" else "Mute clip",
                    fontSize = 8.sp,
                    color = if (isMuted) AccentCoolBlue else TextSecondary,
                    maxLines = 1
                )
            }

            // 2. AI Clipper with "New" orange badge
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .clickable(onClick = onAiClipper)
                    .padding(2.dp)
            ) {
                Box(contentAlignment = Alignment.TopEnd) {
                    Icon(
                        imageVector = Icons.Outlined.ContentCut,
                        contentDescription = "AI clipper",
                        tint = TextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Box(
                        modifier = Modifier
                            .offset(x = 10.dp, y = (-4).dp)
                            .background(Color(0xFFFF7A00), RoundedCornerShape(2.dp))
                            .padding(horizontal = 2.dp, vertical = 0.5.dp)
                    ) {
                        Text("New", fontSize = 6.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "AI clipper",
                    fontSize = 8.sp,
                    color = TextSecondary,
                    maxLines = 1
                )
            }

            // 3. Cover frame thumbnail with edit pencil
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .clickable(onClick = onCover)
                    .padding(2.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(width = 24.dp, height = 20.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .border(0.5.dp, PanelBorderActive, RoundedCornerShape(2.dp))
                ) {
                    Image(
                        painter = painterResource(id = coverThumbnailRes),
                        contentDescription = "Cover",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                    Icon(
                        imageVector = Icons.Outlined.Edit,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier
                            .align(Alignment.Center)
                            .size(10.dp)
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Cover",
                    fontSize = 8.sp,
                    color = TextSecondary,
                    maxLines = 1
                )
            }
        }

        HorizontalDivider(thickness = 0.8.dp, color = PanelBorderSubtle)

        // Aligned with Audio Track (height 44.dp): ♪ Audio Track header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
                .clickable(onClick = onAudioHeaderClick)
                .padding(horizontal = 10.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(18.dp)
                        .background(PanelDarkElevated, CircleShape)
                        .border(0.5.dp, PanelBorder, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text("♪", fontSize = 10.sp, color = TextSecondary)
                }
                Text("Audio", style = TimecodeStyleSmall, fontSize = 10.sp, color = TextSecondary)
            }
        }

        HorizontalDivider(thickness = 0.8.dp, color = PanelBorderSubtle)

        // Aligned with Text Track (height 40.dp): T Text Track header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(40.dp)
                .clickable(onClick = onTextHeaderClick)
                .padding(horizontal = 10.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(18.dp)
                        .background(PanelDarkElevated, RoundedCornerShape(2.dp))
                        .border(0.5.dp, PanelBorder, RoundedCornerShape(2.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("T", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
                }
                Text("Text", style = TimecodeStyleSmall, fontSize = 10.sp, color = TextSecondary)
            }
        }
    }
}

@Composable
fun TimecodeRuler(
    durationSec: Float,
    zoom: Float,
    fps: Int,
    onSeek: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    Canvas(
        modifier = modifier
            .background(PanelDark)
            .pointerInput(durationSec, zoom) {
                detectDragGestures { change, _ ->
                    change.consume()
                    val sec = (change.position.x / zoom).coerceIn(0f, durationSec)
                    onSeek(sec)
                }
            }
    ) {
        val totalSecs = durationSec.toInt()
        val majorInterval = if (zoom < 25f) 5 else if (zoom < 60f) 2 else 1

        for (sec in 0..totalSecs) {
            val x = sec * zoom
            val isMajor = sec % majorInterval == 0

            if (isMajor) {
                drawLine(
                    color = RulerTickMajor,
                    start = Offset(x, size.height - 12f),
                    end = Offset(x, size.height),
                    strokeWidth = 1.5f
                )
            } else {
                drawLine(
                    color = RulerTickMinor,
                    start = Offset(x, size.height - 6f),
                    end = Offset(x, size.height),
                    strokeWidth = 1f
                )
            }

            if (zoom >= 40f) {
                val subStep = zoom / 4f
                for (sub in 1..3) {
                    drawLine(
                        color = RulerTickMinor,
                        start = Offset(x + sub * subStep, size.height - 4f),
                        end = Offset(x + sub * subStep, size.height),
                        strokeWidth = 0.8f
                    )
                }
            }
        }
    }
}

@Composable
fun VideoFilmstripTrackView(
    track: TimelineTrack,
    zoom: Float,
    selectedClipId: String?,
    onSelectClip: (String?) -> Unit,
    onAddMedia: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .background(TrackBg)
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(modifier = Modifier.fillMaxHeight()) {
            track.clips.forEach { clip ->
                val isSelected = clip.id == selectedClipId
                val clipWidthDp = (clip.durationSec * zoom).dp.coerceAtLeast(50.dp)
                val clipOffsetDp = (clip.startTimeSec * zoom).dp

                Box(
                    modifier = Modifier
                        .offset(x = clipOffsetDp)
                        .width(clipWidthDp)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(4.dp))
                        .background(VideoClipBg)
                        .border(
                            width = if (isSelected) 2.dp else 1.dp,
                            color = if (isSelected) Color.White else VideoClipBorder,
                            shape = RoundedCornerShape(4.dp)
                        )
                        .clickable { onSelectClip(clip.id) }
                ) {
                    Row(modifier = Modifier.fillMaxSize()) {
                        if (!clip.contentUri.isNullOrBlank()) {
                            AsyncImage(
                                model = clip.contentUri,
                                contentDescription = clip.name,
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .width(72.dp),
                                contentScale = ContentScale.Crop
                            )
                        } else if (clip.thumbnailRes != null) {
                            Image(
                                painter = painterResource(id = clip.thumbnailRes),
                                contentDescription = clip.name,
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .width(72.dp),
                                contentScale = ContentScale.Crop
                            )
                        }
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(PanelDark.copy(alpha = 0.45f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Column {
                                Text(
                                    text = clip.name,
                                    style = TimecodeStyleSmall,
                                    color = TextPrimary,
                                    maxLines = 1
                                )
                                Text(
                                    text = if (clip.isFrozen) "Freeze 3.0s" else if (clip.isReversed) "Reversed" else "${String.format("%.1f", clip.durationSec)}s",
                                    fontFamily = MonoTimecodeFont,
                                    fontSize = 9.sp,
                                    color = if (isSelected) AccentCoolBlue else TextSecondary
                                )
                            }
                        }
                    }

                    // Top-left duration label badge like in CapCut screenshot (e.g. 25.9s)
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(start = 4.dp, top = 2.dp)
                            .background(Color.Black.copy(alpha = 0.75f), RoundedCornerShape(2.dp))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = "${String.format("%.1f", clip.durationSec)}s",
                            fontFamily = MonoTimecodeFont,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White
                        )
                    }

                    if (clip.hasKeyframe) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.Center)
                                .size(8.dp)
                                .background(AccentCoolBlue, RoundedCornerShape(1.dp))
                        )
                    }

                    // Left & Right Selection Trim Handles (Solid White like CapCut screenshot)
                    if (isSelected) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.CenterStart)
                                .width(7.dp)
                                .fillMaxHeight()
                                .background(Color.White)
                        ) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.Center)
                                    .size(width = 2.dp, height = 16.dp)
                                    .background(Color.Black, RoundedCornerShape(1.dp))
                            )
                        }
                        Box(
                            modifier = Modifier
                                .align(Alignment.CenterEnd)
                                .width(7.dp)
                                .fillMaxHeight()
                                .background(Color.White)
                        ) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.Center)
                                    .size(width = 2.dp, height = 16.dp)
                                    .background(Color.Black, RoundedCornerShape(1.dp))
                            )
                        }
                    }
                }
            }

            // [+] Add Media Clip button right after the last clip
            val lastClipEndSec = track.clips.maxOfOrNull { it.endTimeSec } ?: 0f
            Box(
                modifier = Modifier
                    .offset(x = (lastClipEndSec * zoom).dp + 12.dp)
                    .size(width = 44.dp, height = 60.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(PanelDark)
                    .border(1.dp, PanelBorderActive, RoundedCornerShape(4.dp))
                    .clickable(onClick = onAddMedia),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Outlined.Add,
                    contentDescription = "Add clip",
                    tint = TextPrimary,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}

@Composable
fun AudioTrackRowWithAction(
    track: TimelineTrack?,
    zoom: Float,
    selectedClipId: String?,
    onSelectClip: (String?) -> Unit,
    onAddAudio: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(TrackBg)
            .padding(vertical = 3.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Row(
            modifier = Modifier
                .padding(start = 8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(PanelDark)
                .border(1.dp, PanelBorder, RoundedCornerShape(4.dp))
                .clickable(onClick = onAddAudio)
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = Icons.Outlined.Add,
                contentDescription = null,
                tint = TextSecondary,
                modifier = Modifier.size(12.dp)
            )
            Text(
                text = "Add audio",
                style = TimecodeStyleSmall,
                color = TextSecondary
            )
        }

        track?.clips?.forEach { clip ->
            val isSelected = clip.id == selectedClipId
            val clipWidthDp = (clip.durationSec * zoom).dp.coerceAtLeast(50.dp)
            val clipOffsetDp = (clip.startTimeSec * zoom).dp + 110.dp

            Box(
                modifier = Modifier
                    .offset(x = clipOffsetDp)
                    .width(clipWidthDp)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(4.dp))
                    .background(AudioClipBg)
                    .border(
                        width = if (isSelected) 1.5.dp else 1.dp,
                        color = if (isSelected) AccentCoolBlue else AudioClipBorder,
                        shape = RoundedCornerShape(4.dp)
                    )
                    .clickable { onSelectClip(clip.id) }
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 4.dp, vertical = 4.dp)
                ) {
                    val points = clip.waveformPoints.ifEmpty {
                        listOf(0.2f, 0.5f, 0.8f, 0.4f, 0.6f, 0.9f, 0.3f, 0.7f, 0.5f, 0.3f)
                    }
                    val barWidth = 3f
                    val gap = 2f
                    val totalBars = (size.width / (barWidth + gap)).toInt().coerceAtLeast(1)
                    val centerY = size.height / 2f

                    for (i in 0 until totalBars) {
                        val ptIndex = i % points.size
                        val amp = points[ptIndex]
                        val barHeight = (size.height * 0.85f * amp).coerceAtLeast(4f)
                        val x = i * (barWidth + gap)

                        drawLine(
                            color = if (isSelected) AccentCoolBlue else WaveformBar,
                            start = Offset(x, centerY - barHeight / 2f),
                            end = Offset(x, centerY + barHeight / 2f),
                            strokeWidth = barWidth
                        )
                    }
                }

                Text(
                    text = clip.name,
                    style = TimecodeStyleSmall,
                    color = TextSecondary,
                    maxLines = 1,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(start = 6.dp, top = 2.dp)
                )
            }
        }
    }
}

@Composable
fun TextTrackRowWithAction(
    track: TimelineTrack?,
    zoom: Float,
    selectedClipId: String?,
    onSelectClip: (String?) -> Unit,
    onAddText: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(TrackBg)
            .padding(vertical = 3.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Row(
            modifier = Modifier
                .padding(start = 8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(PanelDark)
                .border(1.dp, PanelBorder, RoundedCornerShape(4.dp))
                .clickable(onClick = onAddText)
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = Icons.Outlined.Add,
                contentDescription = null,
                tint = TextSecondary,
                modifier = Modifier.size(12.dp)
            )
            Text(
                text = "Add text",
                style = TimecodeStyleSmall,
                color = TextSecondary
            )
        }

        track?.clips?.forEach { clip ->
            val isSelected = clip.id == selectedClipId
            val clipWidthDp = (clip.durationSec * zoom).dp.coerceAtLeast(50.dp)
            val clipOffsetDp = (clip.startTimeSec * zoom).dp + 100.dp

            Box(
                modifier = Modifier
                    .offset(x = clipOffsetDp)
                    .width(clipWidthDp)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (isSelected) AccentCoolBlueSubtle else TextClipBg)
                    .border(
                        width = if (isSelected) 1.5.dp else 1.dp,
                        color = if (isSelected) AccentCoolBlue else TextClipBorder,
                        shape = RoundedCornerShape(4.dp)
                    )
                    .clickable { onSelectClip(clip.id) }
                    .padding(horizontal = 6.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(14.dp)
                            .background(if (isSelected) AccentCoolBlue else TextClipPill, RoundedCornerShape(2.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "T",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = BgPureDark
                        )
                    }
                    Text(
                        text = clip.textOverlay ?: clip.name,
                        style = TimecodeStyleSmall,
                        color = if (isSelected) TextWhite else TextPrimary,
                        maxLines = 1
                    )
                }
            }
        }
    }
}
