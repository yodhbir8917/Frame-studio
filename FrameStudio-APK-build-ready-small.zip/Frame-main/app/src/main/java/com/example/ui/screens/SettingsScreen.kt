package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.EditorUiState
import com.example.viewmodel.EditorViewModel
import com.example.viewmodel.ScreenDestination

@Composable
fun SettingsScreen(
    uiState: EditorUiState,
    viewModel: EditorViewModel,
    onNavigateTab: (ScreenDestination) -> Unit,
    modifier: Modifier = Modifier
) {
    var cacheCleared by remember { mutableStateOf(false) }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(BgPureDark),
        containerColor = BgPureDark,
        topBar = {
            SettingsTopBar()
        },
        bottomBar = {
            AppBottomNavBar(
                activeDestination = ScreenDestination.SETTINGS,
                onSelectTab = onNavigateTab
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Editor Behavior Section
            SettingsSectionHeader(title = "TIMELINE & EDITING BEHAVIOR")
            SettingsCard {
                SettingsToggleRow(
                    title = "Magnetic Timeline Snapping",
                    subtitle = "Clips automatically snap to playhead and adjacent cuts",
                    checked = uiState.magneticSnap,
                    onCheckedChange = { viewModel.toggleMagneticSnap() }
                )
                HorizontalDivider(thickness = 0.8.dp, color = PanelBorderSubtle)
                SettingsToggleRow(
                    title = "Ripple Deletion",
                    subtitle = "Close gaps automatically when deleting or trimming clips",
                    checked = uiState.rippleEdit,
                    onCheckedChange = { viewModel.toggleRippleEdit() }
                )
                HorizontalDivider(thickness = 0.8.dp, color = PanelBorderSubtle)
                SettingsToggleRow(
                    title = "Live Audio Scrubbing",
                    subtitle = "Output waveform audio samples while dragging playhead",
                    checked = uiState.audioScrubbing,
                    onCheckedChange = { viewModel.toggleAudioScrubbing() }
                )
            }

            // Storage & Render Cache Section
            SettingsSectionHeader(title = "CACHE & STORAGE")
            SettingsCard {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Proxy Render Cache",
                            style = FrameStudioTypography.titleMedium,
                            color = TextWhite
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (cacheCleared) "0.0 MB Used • Freshly Cleared" else "4.2 GB Used • 18 Timeline Pre-renders",
                            fontFamily = MonoTimecodeFont,
                            fontSize = 11.sp,
                            color = if (cacheCleared) AccentCoolBlue else TextSecondary
                        )
                    }

                    OutlinedButton(
                        onClick = { cacheCleared = true },
                        shape = RoundedCornerShape(4.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, PanelBorderActive),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = if (cacheCleared) "Cleared" else "Clear Cache",
                            style = TimecodeStyleSmall,
                            color = if (cacheCleared) TextMuted else TextPrimary
                        )
                    }
                }
            }

            // Hardware & Export Defaults Section
            SettingsSectionHeader(title = "EXPORT DEFAULTS")
            SettingsCard {
                SettingsInfoRow(title = "Hardware Acceleration", value = "GPU Compute (Vulkan)")
                HorizontalDivider(thickness = 0.8.dp, color = PanelBorderSubtle)
                SettingsInfoRow(title = "Master Color Space", value = "Rec.709 Standard (10-bit)")
                HorizontalDivider(thickness = 0.8.dp, color = PanelBorderSubtle)
                SettingsInfoRow(title = "Default Audio Sample Rate", value = "48.0 kHz 24-bit Stereo")
            }

            // About FrameStudio
            SettingsSectionHeader(title = "ABOUT")
            SettingsCard {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "FrameStudio",
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.Medium,
                        fontSize = 16.sp,
                        color = TextWhite
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Version 2.4.0 (Build 820) • Mobile Workstation",
                        fontFamily = MonoTimecodeFont,
                        fontSize = 11.sp,
                        color = AccentCoolBlue
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Engineered for pure dark minimal mobile editing. Precision timecodes, multi-track timeline, filmstrip preview, and hardware-accelerated exports.",
                        style = FrameStudioTypography.bodyMedium,
                        color = TextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun SettingsTopBar() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = "SETTINGS",
                style = TimecodeStyleSmall,
                color = AccentCoolBlue,
                letterSpacing = 1.5.sp
            )
            Text(
                text = "Editor Preferences & Engine",
                fontFamily = FontFamily.SansSerif,
                fontSize = 11.sp,
                color = TextSecondary
            )
        }
    }
}

@Composable
fun SettingsSectionHeader(title: String) {
    Text(
        text = title,
        style = TimecodeStyleSmall,
        color = TextMuted,
        letterSpacing = 1.sp,
        modifier = Modifier.padding(top = 4.dp, bottom = 2.dp)
    )
}

@Composable
fun SettingsCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .border(1.dp, PanelBorder, RoundedCornerShape(6.dp)),
        shape = RoundedCornerShape(6.dp),
        colors = CardDefaults.cardColors(containerColor = PanelDark),
        content = content
    )
}

@Composable
fun SettingsToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, style = FrameStudioTypography.titleMedium, color = TextWhite)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = subtitle, style = FrameStudioTypography.bodyMedium, color = TextSecondary)
        }
        Spacer(modifier = Modifier.width(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = AccentCoolBlue,
                checkedTrackColor = AccentCoolBlueMuted,
                uncheckedTrackColor = PanelDarkElevated,
                uncheckedThumbColor = TextMuted
            )
        )
    }
}

@Composable
fun SettingsInfoRow(
    title: String,
    value: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = title, style = FrameStudioTypography.titleMedium, color = TextWhite)
        Text(text = value, fontFamily = MonoTimecodeFont, fontSize = 11.sp, color = TextSecondary)
    }
}
