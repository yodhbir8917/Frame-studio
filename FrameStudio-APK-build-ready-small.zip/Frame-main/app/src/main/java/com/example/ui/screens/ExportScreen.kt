package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.FileDownload
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.*
import com.example.ui.theme.*
import com.example.viewmodel.EditorUiState
import com.example.viewmodel.EditorViewModel

@Composable
fun ExportScreen(
    uiState: EditorUiState,
    viewModel: EditorViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val project = uiState.currentProject ?: return
    val exportConfig = uiState.exportConfig
    val simulation = uiState.exportSimulation

    val estimatedSizeMb = remember(exportConfig.resolution, exportConfig.frameRate, project.durationSec, exportConfig.quality) {
        val baseBitrate = when {
            exportConfig.quality.contains("Master") -> 48f
            exportConfig.quality.contains("High") -> 22f
            else -> 12f
        }
        val size = (project.durationSec * baseBitrate * exportConfig.resolution.bitMultiplier / 8f)
        String.format("%.1f MB", size)
    }

    val estimatedTimeSec = remember(exportConfig.resolution, project.durationSec) {
        val factor = if (exportConfig.resolution == Resolution.UHD_4K) 1.2f else 0.7f
        (project.durationSec * factor).toInt().coerceAtLeast(15)
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(BgPureDark),
        containerColor = BgPureDark,
        topBar = {
            ExportTopBar(onBack = onBack)
        },
        bottomBar = {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding(),
                color = PanelDark,
                border = androidx.compose.foundation.BorderStroke(1.dp, PanelBorder)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    // Estimated stats row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("ESTIMATED SIZE", style = TimecodeStyleSmall, color = TextMuted)
                            Text(
                                text = estimatedSizeMb,
                                style = TimecodeStyleLarge,
                                color = TextWhite
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("ESTIMATED TIME", style = TimecodeStyleSmall, color = TextMuted)
                            Text(
                                text = "~ ${estimatedTimeSec}s",
                                style = TimecodeStyleLarge,
                                color = AccentCoolBlue
                            )
                        }
                    }

                    // Large primary Export button using soft accent color
                    Button(
                        onClick = { viewModel.startExportSimulation() },
                        shape = RoundedCornerShape(4.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AccentCoolBlue,
                            contentColor = BgPureDark
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("primary_export_button")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.FileDownload,
                            contentDescription = null,
                            tint = BgPureDark,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Export Master Video",
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Medium,
                            fontSize = 14.sp,
                            color = BgPureDark
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Preview Card of final video
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .clip(RoundedCornerShape(6.dp))
                    .background(PanelDark)
                    .border(1.dp, PanelBorder, RoundedCornerShape(6.dp))
            ) {
                Image(
                    painter = painterResource(id = project.thumbnailRes),
                    contentDescription = project.name,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )

                // Technical overlay badge
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(8.dp)
                        .background(BgPureDark.copy(alpha = 0.85f), RoundedCornerShape(3.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "${exportConfig.resolution.dimensions} • ${exportConfig.frameRate}fps • ${formatShortDuration(project.durationSec)}",
                        fontFamily = MonoTimecodeFont,
                        fontSize = 10.sp,
                        color = TextWhite
                    )
                }
            }

            // Options: Resolution
            OptionSection(title = "RESOLUTION") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Resolution.values().forEach { res ->
                        val isSel = exportConfig.resolution == res
                        SelectPill(
                            label = res.label,
                            subLabel = res.dimensions,
                            isSelected = isSel,
                            onClick = { viewModel.setExportResolution(res) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Options: Frame Rate
            OptionSection(title = "FRAME RATE") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(24, 30, 60).forEach { fps ->
                        val isSel = exportConfig.frameRate == fps
                        val desc = if (fps == 24) "Cinema" else if (fps == 60) "Smooth" else "Standard"
                        SelectPill(
                            label = "${fps} fps",
                            subLabel = desc,
                            isSelected = isSel,
                            onClick = { viewModel.setExportFrameRate(fps) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Options: Quality / Bitrate
            OptionSection(title = "QUALITY / BITRATE") {
                val qualities = listOf("Standard (12 Mbps)", "High (24 Mbps)", "Master (50 Mbps)")
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    qualities.forEach { q ->
                        val isSel = exportConfig.quality == q
                        val shortLabel = q.substringBefore(" (")
                        val bitrate = q.substringAfter("(").substringBefore(")")
                        SelectPill(
                            label = shortLabel,
                            subLabel = bitrate,
                            isSelected = isSel,
                            onClick = { viewModel.setExportQuality(q) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Options: Format
            OptionSection(title = "FORMAT & CODEC") {
                val formats = listOf("MP4 (H.264)", "MP4 (HEVC)", "MOV (ProRes)")
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    formats.forEach { fmt ->
                        val isSel = exportConfig.format == fmt
                        val container = fmt.substringBefore(" (")
                        val codec = fmt.substringAfter("(").substringBefore(")")
                        SelectPill(
                            label = container,
                            subLabel = codec,
                            isSelected = isSel,
                            onClick = { viewModel.setExportFormat(fmt) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }

        // Realistic Export Simulation Progress Modal
        if (simulation.isExporting) {
            ExportProgressModal(
                simulation = simulation,
                exportConfig = exportConfig,
                onCancel = { viewModel.cancelExportSimulation() },
                onDismiss = { viewModel.dismissExportCompleted() }
            )
        }
    }
}

@Composable
fun ExportTopBar(onBack: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Outlined.ArrowBack,
                    contentDescription = "Back",
                    tint = TextPrimary,
                    modifier = Modifier.size(20.dp)
                )
            }
            Column {
                Text(
                    text = "EXPORT MASTER",
                    style = TimecodeStyleSmall,
                    color = AccentCoolBlue,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Hardware Render Engine",
                    fontFamily = FontFamily.SansSerif,
                    fontSize = 11.sp,
                    color = TextSecondary
                )
            }
        }
    }
}

@Composable
fun OptionSection(
    title: String,
    content: @Composable () -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = title,
            style = TimecodeStyleSmall,
            color = TextMuted,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        content()
    }
}

@Composable
fun SelectPill(
    label: String,
    subLabel: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(if (isSelected) AccentCoolBlueSubtle else PanelDark)
            .border(
                1.dp,
                if (isSelected) AccentCoolBlue else PanelBorder,
                RoundedCornerShape(4.dp)
            )
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp, horizontal = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = label,
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Medium,
                fontSize = 12.sp,
                color = if (isSelected) TextWhite else TextPrimary
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subLabel,
                fontFamily = MonoTimecodeFont,
                fontSize = 9.sp,
                color = if (isSelected) AccentCoolBlue else TextSecondary
            )
        }
    }
}

@Composable
fun ExportProgressModal(
    simulation: com.example.viewmodel.ExportSimulationState,
    exportConfig: ExportConfig,
    onCancel: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = { if (simulation.isCompleted) onDismiss() },
        containerColor = PanelDark,
        shape = RoundedCornerShape(8.dp),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (simulation.isCompleted) "RENDER COMPLETED" else "EXPORTING MASTER",
                    style = TimecodeStyleSmall,
                    color = AccentCoolBlue,
                    letterSpacing = 1.sp
                )
                if (simulation.isCompleted) {
                    IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                        Icon(
                            imageVector = Icons.Outlined.Close,
                            contentDescription = "Close",
                            tint = TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                if (!simulation.isCompleted) {
                    // Linear progress indicator
                    LinearProgressIndicator(
                        progress = { simulation.progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = AccentCoolBlue,
                        trackColor = PanelBorder
                    )

                    // Percentage & Frame stats
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${(simulation.progress * 100).toInt()}%",
                            style = TimecodeStyleLarge,
                            color = TextWhite
                        )
                        Text(
                            text = "Frame ${simulation.currentFrame} / ${simulation.totalFrames}",
                            fontFamily = MonoTimecodeFont,
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }

                    // Render telemetry stats
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(PanelDarkElevated, RoundedCornerShape(4.dp))
                            .border(1.dp, PanelBorderSubtle, RoundedCornerShape(4.dp))
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("RENDER RATE", style = TimecodeStyleSmall, color = TextMuted)
                            Text("${simulation.renderFps} fps (HEVC)", fontFamily = MonoTimecodeFont, fontSize = 11.sp, color = TextPrimary)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("REMAINING TIME", style = TimecodeStyleSmall, color = TextMuted)
                            Text("~ ${simulation.timeRemainingSec}s", fontFamily = MonoTimecodeFont, fontSize = 11.sp, color = AccentCoolBlue)
                        }
                    }
                } else {
                    // Completed State
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .background(AccentCoolBlueSubtle, CircleShape)
                                .border(1.dp, AccentCoolBlue, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.CheckCircle,
                                contentDescription = "Done",
                                tint = AccentCoolBlue,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        Text(
                            text = "Master video successfully encoded and saved to Gallery.",
                            style = FrameStudioTypography.bodyMedium,
                            color = TextPrimary,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                        Text(
                            text = "DCIM / FrameStudio / Master_4K_60.mp4",
                            fontFamily = MonoTimecodeFont,
                            fontSize = 10.sp,
                            color = TextSecondary
                        )
                    }
                }
            }
        },
        confirmButton = {
            if (simulation.isCompleted) {
                Button(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(4.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AccentCoolBlue,
                        contentColor = BgPureDark
                    )
                ) {
                    Text("Done", color = BgPureDark)
                }
            } else {
                TextButton(onClick = onCancel) {
                    Text("Cancel Render", color = TextSecondary)
                }
            }
        }
    )
}
