package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = AccentCoolBlue,
    onPrimary = BgPureDark,
    primaryContainer = AccentCoolBlueMuted,
    onPrimaryContainer = TextWhite,
    secondary = AccentCoolBlue,
    onSecondary = BgPureDark,
    background = BgPureDark,
    onBackground = TextPrimary,
    surface = PanelDark,
    onSurface = TextPrimary,
    surfaceVariant = PanelDarkElevated,
    onSurfaceVariant = TextSecondary,
    outline = PanelBorder,
    outlineVariant = PanelBorderSubtle
)

@Composable
fun FrameStudioTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = FrameStudioTypography,
        content = content
    )
}
