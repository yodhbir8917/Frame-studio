package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.Redo
import androidx.compose.material.icons.automirrored.outlined.Undo
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.util.MediaUtils
import com.example.viewmodel.EditorUiState
import com.example.viewmodel.EditorViewModel

@Composable
fun EditorScreen(
    uiState: EditorUiState,
    viewModel: EditorViewModel,
    onBack: () -> Unit,
    onNavigateExport: () -> Unit,
    onNavigateMedia: () -> Unit,
    modifier: Modifier = Modifier
) {
    val project = uiState.currentProject ?: return
    val context = LocalContext.current

    val galleryAddLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris ->
        if (uris.isNotEmpty()) {
            val mediaList = MediaUtils.extractMultiple(context, uris)
            viewModel.addGalleryClipsToCurrentProject(mediaList)
        }
    }

    val videoTrack = project.tracks.firstOrNull { it.type == TrackType.VIDEO }
    val activeClip = videoTrack?.clips?.firstOrNull {
        uiState.currentTimeSec >= it.startTimeSec && uiState.currentTimeSec <= it.endTimeSec
    } ?: videoTrack?.clips?.firstOrNull()

    val textTrack = project.tracks.firstOrNull { it.type == TrackType.TEXT }
    val activeTextOverlay = textTrack?.clips?.firstOrNull {
        uiState.currentTimeSec >= it.startTimeSec && uiState.currentTimeSec <= it.endTimeSec
    }?.textOverlay

    val isClipSelected = uiState.selectedClipId != null

    // Back navigation hierarchy handling
    BackHandler {
        when {
            uiState.isExportDraftZipModalOpen -> viewModel.setExportDraftZipModal(false)
            uiState.isAutoCaptionsModalOpen -> viewModel.setAutoCaptionsModal(false)
            uiState.isCoverPickerOpen -> viewModel.setCoverPickerModal(false)
            uiState.isSoundsModalOpen -> viewModel.setSoundsModal(false)
            uiState.isSoundFxModalOpen -> viewModel.setSoundFxModal(false)
            uiState.isVoiceoverModalOpen -> viewModel.setVoiceoverModal(false)
            uiState.isTextToSpeechModalOpen -> viewModel.setTextToSpeechModal(false)
            uiState.activeToolPanel != ToolPanelType.NONE -> viewModel.closeToolPanel()
            uiState.activeSubToolbar != null -> viewModel.closeSubToolbar()
            uiState.selectedClipId != null -> viewModel.deselectClip()
            else -> onBack()
        }
    }

    // Auto Captions Modal
    if (uiState.isAutoCaptionsModalOpen) {
        AutoCaptionsModal(
            onDismiss = { viewModel.setAutoCaptionsModal(false) },
            onGenerate = {
                viewModel.setAutoCaptionsModal(false)
                viewModel.addTextTrackPrompt()
            }
        )
    }

    // Cover Picker Modal
    if (uiState.isCoverPickerOpen) {
        CoverPickerModal(
            currentTimeSec = project.coverTimeSec,
            totalDurationSec = project.durationSec,
            onDismiss = { viewModel.setCoverPickerModal(false) },
            onSaveCover = { viewModel.setCoverTime(it) }
        )
    }

    // Export Draft Zip Modal
    if (uiState.isExportDraftZipModalOpen) {
        ExportDraftZipModal(
            onDismiss = { viewModel.setExportDraftZipModal(false) }
        )
    }

    // Sounds / Music Library Modal
    if (uiState.isSoundsModalOpen) {
        SoundsPickerModal(
            onDismiss = { viewModel.setSoundsModal(false) },
            onSelectSound = { name, dur -> viewModel.addCustomAudioClip(name, dur) }
        )
    }

    // Sound FX Library Modal
    if (uiState.isSoundFxModalOpen) {
        SoundFxModal(
            onDismiss = { viewModel.setSoundFxModal(false) },
            onSelectFx = { name, dur -> viewModel.addCustomAudioClip(name, dur) }
        )
    }

    // Voiceover Recording Modal
    if (uiState.isVoiceoverModalOpen) {
        VoiceoverRecordModal(
            onDismiss = { viewModel.setVoiceoverModal(false) },
            onSaveVoiceover = { dur -> viewModel.addVoiceoverClip(dur) }
        )
    }

    // Text to Speech Voice Synthesis Modal
    if (uiState.isTextToSpeechModalOpen) {
        TextToSpeechModal(
            onDismiss = { viewModel.setTextToSpeechModal(false) },
            onGenerateVoice = { prompt -> viewModel.addCustomAudioClip("AI_Voice_${prompt.take(12)}", 5f) }
        )
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(BgPureDark),
        containerColor = BgPureDark,
        topBar = {
            EditorTopBar(
                project = project,
                showGrid = uiState.showGridOverlay,
                onBack = onBack,
                onToggleGrid = { viewModel.toggleGridOverlay() },
                onExportClick = onNavigateExport,
                onExportDraftZip = { viewModel.setExportDraftZipModal(true) },
                onChangeRatio = { viewModel.setAspectRatio(it) },
                onChangeResolution = { viewModel.setProjectResolution(it) }
            )
        },
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
            ) {
                // Interactive tool parameter panel when open
                ToolPanelContainer(
                    panelType = uiState.activeToolPanel,
                    colorGrade = uiState.colorGrade,
                    activeEffect = uiState.activeEffect,
                    activeTransition = uiState.activeTransition,
                    onUpdateColor = { viewModel.updateColorGrade(it) },
                    onSelectEffect = { viewModel.setEffect(it) },
                    onSelectTransition = { viewModel.setTransition(it) },
                    onSetSpeed = { viewModel.setClipSpeed(it) },
                    onSetVolume = { viewModel.setClipVolume(it) },
                    onSetOpacity = { viewModel.setClipOpacity(it) },
                    onSetMask = { viewModel.setClipMask(it) },
                    onSetAnimation = { viewModel.setClipAnimation(it) },
                    onClose = { viewModel.closeToolPanel() },
                    onSplit = { viewModel.splitClipAtPlayhead() },
                    onDuplicate = { viewModel.duplicateSelectedClip() },
                    onDelete = { viewModel.deleteSelectedClip() },
                    onFreeze = { viewModel.freezeSelectedClip() },
                    onReverse = { viewModel.reverseSelectedClip() },
                    onReplace = onNavigateMedia,
                    onAddSticker = { viewModel.addSticker(it) }
                )

                // Bottom toolbar row: SubToolbarHost (if active) OR Clip-Selected Toolbar OR Default Toolbar
                if (uiState.activeSubToolbar != null) {
                    SubToolbarHost(
                        subToolbar = uiState.activeSubToolbar,
                        colorGrade = uiState.colorGrade,
                        activeBackgroundBlur = uiState.activeBackgroundBlur,
                        onBack = { viewModel.closeSubToolbar() },
                        onUpdateColor = { viewModel.updateColorGrade(it) },
                        onSetAspectRatio = { viewModel.setAspectRatio(it) },
                        onSetBackgroundBlur = { viewModel.setBackgroundBlur(it) },
                        onAddSticker = { viewModel.addSticker(it) },
                        onOpenAutoCaptions = { viewModel.setAutoCaptionsModal(true) },
                        onOpenSounds = { viewModel.setSoundsModal(true) },
                        onOpenSoundFx = { viewModel.setSoundFxModal(true) },
                        onOpenVoiceover = { viewModel.setVoiceoverModal(true) },
                        onOpenTextToSpeech = { viewModel.setTextToSpeechModal(true) },
                        onAddAudioPrompt = { viewModel.addAudioTrackPrompt() },
                        onAddTextPrompt = { viewModel.addTextTrackPrompt() },
                        onAddOverlayPrompt = { onNavigateMedia() },
                        onSetAnimation = { viewModel.setClipAnimation(it) }
                    )
                } else if (isClipSelected) {
                    BottomToolbarClipSelected(
                        activePanel = uiState.activeToolPanel,
                        onBackToSequence = { viewModel.deselectClip() },
                        onSelectTool = { tool ->
                            when (tool) {
                                ToolPanelType.SPLIT -> {
                                    viewModel.splitClipAtPlayhead()
                                    viewModel.toggleToolPanel(ToolPanelType.SPLIT)
                                }
                                ToolPanelType.DELETE -> {
                                    viewModel.toggleToolPanel(ToolPanelType.DELETE)
                                }
                                ToolPanelType.DUPLICATE -> {
                                    viewModel.duplicateSelectedClip()
                                    viewModel.toggleToolPanel(ToolPanelType.DUPLICATE)
                                }
                                ToolPanelType.FREEZE -> {
                                    viewModel.freezeSelectedClip()
                                    viewModel.toggleToolPanel(ToolPanelType.FREEZE)
                                }
                                ToolPanelType.REVERSE -> {
                                    viewModel.reverseSelectedClip()
                                    viewModel.toggleToolPanel(ToolPanelType.REVERSE)
                                }
                                ToolPanelType.EXTRACT_AUDIO, ToolPanelType.UNLINK -> {
                                    viewModel.unlinkAudioFromSelectedClip()
                                    viewModel.toggleToolPanel(ToolPanelType.EXTRACT_AUDIO)
                                }
                                ToolPanelType.REDUCE_NOISE -> {
                                    viewModel.toggleNoiseReduction()
                                    viewModel.toggleToolPanel(ToolPanelType.REDUCE_NOISE)
                                }
                                ToolPanelType.ISOLATE_VOICE -> {
                                    viewModel.toggleVoiceIsolation()
                                    viewModel.toggleToolPanel(ToolPanelType.ISOLATE_VOICE)
                                }
                                ToolPanelType.REMOVE_BG -> {
                                    viewModel.toggleRemoveBackground()
                                    viewModel.toggleToolPanel(ToolPanelType.REMOVE_BG)
                                }
                                ToolPanelType.REPLACE -> {
                                    viewModel.toggleToolPanel(ToolPanelType.REPLACE)
                                }
                                ToolPanelType.ANIMATIONS -> viewModel.openSubToolbar(SubToolbarType.ANIMATIONS_SHEET)
                                ToolPanelType.FILTERS -> viewModel.openSubToolbar(SubToolbarType.FILTERS_SHEET)
                                ToolPanelType.ADJUST -> viewModel.openSubToolbar(SubToolbarType.ADJUST_SHEET)
                                else -> viewModel.toggleToolPanel(tool)
                            }
                        }
                    )
                } else {
                    BottomToolbarDefault(
                        activePanel = uiState.activeToolPanel,
                        onSelectTool = { tool ->
                            when (tool) {
                                ToolPanelType.EDIT -> {
                                    viewModel.selectClipAtPlayhead()
                                    viewModel.toggleToolPanel(ToolPanelType.EDIT)
                                }
                                ToolPanelType.AUDIO -> viewModel.openSubToolbar(SubToolbarType.AUDIO_MENU)
                                ToolPanelType.TEXT -> viewModel.openSubToolbar(SubToolbarType.TEXT_MENU)
                                ToolPanelType.EFFECTS -> viewModel.openSubToolbar(SubToolbarType.EFFECTS_MENU)
                                ToolPanelType.OVERLAY -> viewModel.openSubToolbar(SubToolbarType.OVERLAY_MENU)
                                ToolPanelType.CAPTIONS -> viewModel.openSubToolbar(SubToolbarType.CAPTIONS_MENU)
                                ToolPanelType.FILTERS -> viewModel.openSubToolbar(SubToolbarType.FILTERS_SHEET)
                                ToolPanelType.ADJUST -> viewModel.openSubToolbar(SubToolbarType.ADJUST_SHEET)
                                ToolPanelType.STICKERS -> viewModel.openSubToolbar(SubToolbarType.STICKERS_SHEET)
                                ToolPanelType.ASPECT_RATIO -> viewModel.openSubToolbar(SubToolbarType.ASPECT_RATIO_SHEET)
                                ToolPanelType.BACKGROUND -> viewModel.openSubToolbar(SubToolbarType.BACKGROUND_SHEET)
                                else -> viewModel.toggleToolPanel(tool)
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // 1. Large Video Preview at the top with rounded corners and framing guides
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.05f)
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                VideoPreviewBox(
                    project = project,
                    currentThumbnailRes = activeClip?.thumbnailRes ?: R.drawable.thumb_architecture,
                    currentContentUri = activeClip?.contentUri,
                    textOverlay = activeTextOverlay,
                    isPlaying = uiState.isPlaying,
                    showGrid = uiState.showGridOverlay,
                    opacity = activeClip?.opacity ?: 1.0f,
                    isClipSelected = isClipSelected,
                    isAspectRatioActive = uiState.activeSubToolbar == SubToolbarType.ASPECT_RATIO_SHEET,
                    activeMask = activeClip?.activeMask,
                    hasKeyframe = activeClip?.hasKeyframe ?: false,
                    isReversed = activeClip?.isReversed ?: false,
                    isFrozen = activeClip?.isFrozen ?: false,
                    stickers = uiState.activeStickers,
                    onTogglePlay = { viewModel.togglePlayback() }
                )
            }

            // 2. Playback Controls Row (Fullscreen, Timecode, Play/Pause, Keyframe, Undo, Redo)
            CapCutStyleControlsRow(
                isPlaying = uiState.isPlaying,
                currentTimeSec = uiState.currentTimeSec,
                totalDurationSec = project.durationSec,
                fps = project.fps,
                hasKeyframe = activeClip?.hasKeyframe ?: false,
                canUndo = uiState.canUndo,
                canRedo = uiState.canRedo,
                onTogglePlay = { viewModel.togglePlayback() },
                onToggleKeyframe = { viewModel.toggleKeyframeAtPlayhead() },
                onUndo = { },
                onRedo = { },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 4.dp)
            )

            // 3. Multi-track Timeline with Fixed Header (Mute clip, AI clipper, Cover, ♪, T), + Add Audio, + Add Text, and [+] Add Media
            TimelineView(
                project = project,
                currentTimeSec = uiState.currentTimeSec,
                selectedClipId = uiState.selectedClipId,
                timelineZoom = uiState.timelineZoom,
                onSeek = { viewModel.seekTo(it) },
                onSelectClip = { viewModel.selectClip(it) },
                onAddAudio = { viewModel.addAudioTrackPrompt() },
                onAddText = { viewModel.addTextTrackPrompt() },
                onAddMedia = {
                    galleryAddLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                    )
                },
                onToggleMuteClip = { viewModel.toggleGlobalMute() },
                onAiClipperClick = { viewModel.splitClipAtPlayhead() },
                onCoverClick = { viewModel.setCoverPickerModal(true) },
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.95f)
                    .border(width = 1.dp, color = PanelBorder)
            )
        }
    }
}

@Composable
fun EditorTopBar(
    project: Project,
    showGrid: Boolean,
    onBack: () -> Unit,
    onToggleGrid: () -> Unit,
    onExportClick: () -> Unit,
    onExportDraftZip: () -> Unit,
    onChangeRatio: (AspectRatio) -> Unit,
    onChangeResolution: (Resolution) -> Unit
) {
    var showRatioMenu by remember { mutableStateOf(false) }
    var showResolutionMenu by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Back / Close button and sequence info
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(36.dp)
                    .testTag("back_button")
            ) {
                Icon(
                    imageVector = Icons.Outlined.Close,
                    contentDescription = "Close",
                    tint = TextPrimary,
                    modifier = Modifier.size(20.dp)
                )
            }

            Column {
                Text(
                    text = project.name,
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Medium,
                    fontSize = 14.sp,
                    color = TextWhite,
                    maxLines = 1
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${project.resolution.label.take(4)} • ${project.fps}fps",
                        style = TimecodeStyleSmall,
                        color = AccentCoolBlue
                    )

                    // Aspect ratio selector dropdown tag
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(3.dp))
                            .background(PanelDark)
                            .border(0.5.dp, PanelBorder, RoundedCornerShape(3.dp))
                            .clickable { showRatioMenu = true }
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = "${project.aspectRatio.label} ▾",
                            fontFamily = MonoTimecodeFont,
                            fontSize = 9.sp,
                            color = TextSecondary
                        )
                        DropdownMenu(
                            expanded = showRatioMenu,
                            onDismissRequest = { showRatioMenu = false },
                            modifier = Modifier.background(PanelDark)
                        ) {
                            AspectRatio.values().forEach { ratio ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = ratio.label,
                                            style = TimecodeStyleSmall,
                                            color = if (ratio == project.aspectRatio) AccentCoolBlue else TextPrimary
                                        )
                                    },
                                    onClick = {
                                        showRatioMenu = false
                                        onChangeRatio(ratio)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Top right: Resolution Pill, Export Button, and Export Draft Zip below
        Column(
            horizontalAlignment = Alignment.End,
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Grid toggle
                IconButton(
                    onClick = onToggleGrid,
                    modifier = Modifier.size(30.dp)
                ) {
                    Icon(
                        imageVector = if (showGrid) Icons.Outlined.GridOn else Icons.Outlined.GridOff,
                        contentDescription = "Grid",
                        tint = if (showGrid) AccentCoolBlue else TextSecondary,
                        modifier = Modifier.size(17.dp)
                    )
                }

                // Interactive Resolution badge like CapCut [1080P ▾]
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(PanelDarkElevated)
                        .border(0.8.dp, PanelBorderActive, RoundedCornerShape(4.dp))
                        .clickable { showResolutionMenu = true }
                        .padding(horizontal = 7.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "${project.resolution.label.take(5).trim()} ▾",
                        fontFamily = MonoTimecodeFont,
                        fontWeight = FontWeight.Medium,
                        fontSize = 11.sp,
                        color = TextWhite
                    )

                    DropdownMenu(
                        expanded = showResolutionMenu,
                        onDismissRequest = { showResolutionMenu = false },
                        modifier = Modifier
                            .background(PanelDark)
                            .border(1.dp, PanelBorder)
                    ) {
                        Resolution.values().forEach { res ->
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(
                                            text = res.label,
                                            style = TimecodeStyleSmall,
                                            fontWeight = if (res == project.resolution) FontWeight.Bold else FontWeight.Normal,
                                            color = if (res == project.resolution) AccentCoolBlue else TextPrimary
                                        )
                                        Text(
                                            text = res.dimensions,
                                            fontFamily = MonoTimecodeFont,
                                            fontSize = 8.sp,
                                            color = TextSecondary
                                        )
                                    }
                                },
                                onClick = {
                                    showResolutionMenu = false
                                    onChangeResolution(res)
                                }
                            )
                        }
                    }
                }

                // Primary Export button in #7A9BB8
                Button(
                    onClick = onExportClick,
                    shape = RoundedCornerShape(4.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AccentCoolBlue,
                        contentColor = BgPureDark
                    ),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 5.dp),
                    modifier = Modifier
                        .height(28.dp)
                        .testTag("export_button")
                ) {
                    Text(
                        text = "Export",
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.Medium,
                        fontSize = 12.sp,
                        color = BgPureDark
                    )
                }
            }

            // Export Draft Zip badge (as shown in user's video & screenshot)
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(3.dp))
                    .background(PanelDarkElevated.copy(alpha = 0.85f))
                    .border(0.6.dp, PanelBorderActive, RoundedCornerShape(3.dp))
                    .clickable { onExportDraftZip() }
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "Export Draft Zip",
                    fontFamily = MonoTimecodeFont,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Medium,
                    color = TextSecondary
                )
            }
        }
    }
}

@Composable
fun VideoPreviewBox(
    project: Project,
    currentThumbnailRes: Int,
    currentContentUri: String? = null,
    textOverlay: String?,
    isPlaying: Boolean,
    showGrid: Boolean,
    opacity: Float,
    isClipSelected: Boolean,
    isAspectRatioActive: Boolean = false,
    activeMask: String? = null,
    hasKeyframe: Boolean = false,
    isReversed: Boolean = false,
    isFrozen: Boolean = false,
    stickers: List<String> = emptyList(),
    onTogglePlay: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(8.dp))
            .background(PanelDark)
            .border(1.dp, PanelBorder, RoundedCornerShape(8.dp))
            .clickable(onClick = onTogglePlay),
        contentAlignment = Alignment.Center
    ) {
        // Aspect ratio container box
        Box(
            modifier = Modifier
                .aspectRatio(project.aspectRatio.ratio, matchHeightConstraintsFirst = true)
                .fillMaxSize()
                .clip(RoundedCornerShape(6.dp))
                .background(Color.Black)
        ) {
            // Video Frame Image
            if (!currentContentUri.isNullOrBlank()) {
                AsyncImage(
                    model = currentContentUri,
                    contentDescription = "Video Frame",
                    modifier = Modifier.fillMaxSize(),
                    alpha = opacity,
                    contentScale = ContentScale.Crop
                )
            } else {
                Image(
                    painter = painterResource(id = currentThumbnailRes),
                    contentDescription = "Video Frame",
                    modifier = Modifier.fillMaxSize(),
                    alpha = opacity,
                    contentScale = ContentScale.Crop
                )
            }

            // Cyan center line guides when clip is selected (just like in CapCut screenshot)
            if (isClipSelected) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .width(1.5.dp)
                        .height(32.dp)
                        .background(AccentCoolBlue)
                )
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .width(1.5.dp)
                        .height(32.dp)
                        .background(AccentCoolBlue)
                )
            }

            // Framing Grid overlay (Rule of Thirds)
            if (showGrid) {
                Column(modifier = Modifier.fillMaxSize()) {
                    Spacer(modifier = Modifier.weight(1f))
                    HorizontalDivider(thickness = 0.8.dp, color = Color.White.copy(alpha = 0.25f))
                    Spacer(modifier = Modifier.weight(1f))
                    HorizontalDivider(thickness = 0.8.dp, color = Color.White.copy(alpha = 0.25f))
                    Spacer(modifier = Modifier.weight(1f))
                }
                Row(modifier = Modifier.fillMaxSize()) {
                    Spacer(modifier = Modifier.weight(1f))
                    VerticalDivider(thickness = 0.8.dp, color = Color.White.copy(alpha = 0.25f))
                    Spacer(modifier = Modifier.weight(1f))
                    VerticalDivider(thickness = 0.8.dp, color = Color.White.copy(alpha = 0.25f))
                    Spacer(modifier = Modifier.weight(1f))
                }
            }

            // Subtitle text caption overlay
            if (textOverlay != null) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 20.dp)
                        .background(BgPureDark.copy(alpha = 0.75f), RoundedCornerShape(3.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = textOverlay,
                        fontFamily = MonoTimecodeFont,
                        fontWeight = FontWeight.Medium,
                        fontSize = 12.sp,
                        letterSpacing = 1.2.sp,
                        color = TextWhite
                    )
                }
            }

            // Active stickers overlay
            if (stickers.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    stickers.forEach { s ->
                        Box(
                            modifier = Modifier
                                .background(BgPureDark.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 4.dp)
                        ) {
                            Text(text = s, fontSize = 16.sp)
                        }
                    }
                }
            }

            // "Use both fingers to resize your video" banner when Aspect Ratio tool is active
            if (isAspectRatioActive) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 10.dp)
                        .background(BgPureDark.copy(alpha = 0.85f), RoundedCornerShape(16.dp))
                        .border(0.5.dp, PanelBorderActive, RoundedCornerShape(16.dp))
                        .padding(horizontal = 12.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = "Use both fingers to resize your video",
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 10.sp,
                        color = TextWhite
                    )
                }
            }

            // Mask boundary visualizer (like CapCut masking tutorial)
            if (activeMask != null && activeMask != "None") {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    when (activeMask) {
                        "Split" -> {
                            HorizontalDivider(thickness = 2.dp, color = AccentCoolBlue)
                        }
                        "Circle" -> {
                            Box(
                                modifier = Modifier
                                    .size(160.dp)
                                    .border(2.dp, AccentCoolBlue, CircleShape)
                            )
                        }
                        "Rectangle" -> {
                            Box(
                                modifier = Modifier
                                    .size(width = 200.dp, height = 130.dp)
                                    .border(2.dp, AccentCoolBlue, RoundedCornerShape(12.dp))
                            )
                        }
                        "Filmstrip" -> {
                            Column(modifier = Modifier.fillMaxSize()) {
                                Box(modifier = Modifier.fillMaxWidth().weight(0.2f).background(Color.Black.copy(alpha = 0.85f)))
                                HorizontalDivider(thickness = 1.5.dp, color = AccentCoolBlue)
                                Spacer(modifier = Modifier.weight(0.6f))
                                HorizontalDivider(thickness = 1.5.dp, color = AccentCoolBlue)
                                Box(modifier = Modifier.fillMaxWidth().weight(0.2f).background(Color.Black.copy(alpha = 0.85f)))
                            }
                        }
                        else -> {
                            Box(
                                modifier = Modifier
                                    .size(140.dp)
                                    .border(2.dp, AccentCoolBlue, RoundedCornerShape(16.dp))
                            )
                        }
                    }
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(8.dp)
                            .background(BgPureDark.copy(alpha = 0.85f), RoundedCornerShape(4.dp))
                            .border(0.5.dp, AccentCoolBlue, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text("MASK: $activeMask", fontFamily = MonoTimecodeFont, fontSize = 8.sp, color = AccentCoolBlue)
                    }
                }
            }

            // Status badges: Keyframe, Reverse, Freeze
            Row(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(8.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                if (hasKeyframe) {
                    Box(
                        modifier = Modifier
                            .background(AccentCoolBlue, RoundedCornerShape(2.dp))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text("◇ KEYFRAME", fontSize = 7.sp, fontWeight = FontWeight.Bold, color = BgPureDark)
                    }
                }
                if (isReversed) {
                    Box(
                        modifier = Modifier
                            .background(PanelDarkElevated, RoundedCornerShape(2.dp))
                            .border(0.5.dp, AccentCoolBlue, RoundedCornerShape(2.dp))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text("◀ REVERSE", fontSize = 7.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                    }
                }
                if (isFrozen) {
                    Box(
                        modifier = Modifier
                            .background(PanelDarkElevated, RoundedCornerShape(2.dp))
                            .border(0.5.dp, AccentCoolBlue, RoundedCornerShape(2.dp))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text("⏸ FREEZE", fontSize = 7.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                    }
                }
            }

            // Center play icon when paused
            if (!isPlaying) {
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .size(44.dp)
                        .background(BgPureDark.copy(alpha = 0.65f), CircleShape)
                        .border(1.dp, PanelBorderActive, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Outlined.PlayArrow,
                        contentDescription = "Play",
                        tint = TextWhite,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun CapCutStyleControlsRow(
    isPlaying: Boolean,
    currentTimeSec: Float,
    totalDurationSec: Float,
    fps: Int,
    hasKeyframe: Boolean,
    canUndo: Boolean,
    canRedo: Boolean,
    onTogglePlay: () -> Unit,
    onToggleKeyframe: () -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Left: Fullscreen icon & Timecode
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            IconButton(
                onClick = { },
                modifier = Modifier.size(30.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.Fullscreen,
                    contentDescription = "Fullscreen",
                    tint = TextSecondary,
                    modifier = Modifier.size(19.dp)
                )
            }

            // Timecode: 00:02 / 00:27
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text(
                    text = formatShortDuration(currentTimeSec),
                    fontFamily = MonoTimecodeFont,
                    fontSize = 11.sp,
                    color = TextPrimary
                )
                Text(
                    text = "/",
                    fontFamily = MonoTimecodeFont,
                    fontSize = 11.sp,
                    color = TextMuted
                )
                Text(
                    text = formatShortDuration(totalDurationSec),
                    fontFamily = MonoTimecodeFont,
                    fontSize = 11.sp,
                    color = TextSecondary
                )
            }
        }

        // Center: Play/Pause button
        IconButton(
            onClick = onTogglePlay,
            modifier = Modifier.size(34.dp)
        ) {
            Icon(
                imageVector = if (isPlaying) Icons.Outlined.Pause else Icons.Outlined.PlayArrow,
                contentDescription = if (isPlaying) "Pause" else "Play",
                tint = if (isPlaying) AccentCoolBlue else TextWhite,
                modifier = Modifier.size(22.dp)
            )
        }

        // Right: Keyframe diamond button & Undo/Redo
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // Keyframe diamond icon [◇+]
            IconButton(
                onClick = onToggleKeyframe,
                modifier = Modifier.size(30.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.Diamond,
                    contentDescription = "Keyframe",
                    tint = if (hasKeyframe) AccentCoolBlue else TextSecondary,
                    modifier = Modifier.size(18.dp)
                )
            }

            // Undo
            IconButton(
                onClick = onUndo,
                enabled = canUndo,
                modifier = Modifier.size(30.dp)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Outlined.Undo,
                    contentDescription = "Undo",
                    tint = if (canUndo) TextPrimary else TextDisabled,
                    modifier = Modifier.size(17.dp)
                )
            }

            // Redo
            IconButton(
                onClick = onRedo,
                enabled = canRedo,
                modifier = Modifier.size(30.dp)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Outlined.Redo,
                    contentDescription = "Redo",
                    tint = if (canRedo) TextPrimary else TextDisabled,
                    modifier = Modifier.size(17.dp)
                )
            }
        }
    }
}

/**
 * DEFAULT BOTTOM TOOLBAR (when NO clip is selected):
 * Shows: Edit, Audio, Text, Effects, Overlay, Captions, Filters, Adjust, Stickers, Aspect ratio, Background
 */
@Composable
fun BottomToolbarDefault(
    activePanel: ToolPanelType,
    onSelectTool: (ToolPanelType) -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = PanelDark,
        tonalElevation = 0.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, PanelBorder)
    ) {
        val tools = listOf(
            Triple(ToolPanelType.EDIT, "Edit", Icons.Outlined.ContentCut),
            Triple(ToolPanelType.AUDIO, "Audio", Icons.Outlined.Audiotrack),
            Triple(ToolPanelType.TEXT, "Text", Icons.Outlined.Title),
            Triple(ToolPanelType.EFFECTS, "Effects", Icons.Outlined.StarOutline),
            Triple(ToolPanelType.OVERLAY, "Overlay", Icons.Outlined.Layers),
            Triple(ToolPanelType.CAPTIONS, "Captions", Icons.Outlined.Subtitles),
            Triple(ToolPanelType.FILTERS, "Filters", Icons.Outlined.FilterVintage),
            Triple(ToolPanelType.ADJUST, "Adjust", Icons.Outlined.Tune),
            Triple(ToolPanelType.STICKERS, "Stickers", Icons.Outlined.EmojiEmotions),
            Triple(ToolPanelType.ASPECT_RATIO, "Aspect ratio", Icons.Outlined.AspectRatio),
            Triple(ToolPanelType.BACKGROUND, "Background", Icons.Outlined.Texture)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 6.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            tools.forEach { (tool, label, icon) ->
                val isActive = activePanel == tool
                ToolbarToolItem(
                    label = label,
                    icon = icon,
                    isActive = isActive,
                    onClick = { onSelectTool(tool) }
                )
            }
        }
    }
}

/**
 * CLIP SELECTED TOOLBAR (when video clip IS selected):
 * Shows: [< Back] + Split, Speed, Volume, Animations, Crop, Delete, Beats, Duplicate, Replace, Effects,
 * Transform, Auto reframe, Stabilize, Camera tracking, Extract audio, Isolate voice, Reduce noise,
 * Audio effects, Enhance voice, Freeze, Reverse, Mask, Remove BG, Relight, Opacity, Motion blur,
 * Retouch, Video quality, Adjust, Filters, Unlink
 */
@Composable
fun BottomToolbarClipSelected(
    activePanel: ToolPanelType,
    onBackToSequence: () -> Unit,
    onSelectTool: (ToolPanelType) -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = PanelDark,
        tonalElevation = 0.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, PanelBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Far Left: [< Back] button to deselect clip and exit clip editing mode
            Box(
                modifier = Modifier
                    .padding(start = 6.dp, end = 4.dp)
                    .size(width = 38.dp, height = 48.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(PanelDarkElevated)
                    .border(1.dp, PanelBorderActive, RoundedCornerShape(4.dp))
                    .clickable(onClick = onBackToSequence),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Outlined.ArrowBack,
                    contentDescription = "Back to timeline",
                    tint = TextPrimary,
                    modifier = Modifier.size(18.dp)
                )
            }

            // Scrollable list of ALL 31 clip-level tools
            val clipTools = listOf(
                Triple(ToolPanelType.SPLIT, "Split", Icons.Outlined.ContentCut),
                Triple(ToolPanelType.SPEED, "Speed", Icons.Outlined.Speed),
                Triple(ToolPanelType.VOLUME, "Volume", Icons.Outlined.VolumeUp),
                Triple(ToolPanelType.ANIMATIONS, "Animations", Icons.Outlined.Animation),
                Triple(ToolPanelType.CROP, "Crop", Icons.Outlined.Crop),
                Triple(ToolPanelType.DELETE, "Delete", Icons.Outlined.Delete),
                Triple(ToolPanelType.BEATS, "Beats", Icons.Outlined.Flag),
                Triple(ToolPanelType.DUPLICATE, "Duplicate", Icons.Outlined.ContentCopy),
                Triple(ToolPanelType.REPLACE, "Replace", Icons.Outlined.FindReplace),
                Triple(ToolPanelType.EFFECTS, "Effects", Icons.Outlined.StarOutline),
                Triple(ToolPanelType.TRANSFORM, "Transform", Icons.Outlined.Transform),
                Triple(ToolPanelType.AUTO_REFRAME, "Auto reframe", Icons.Outlined.CropFree),
                Triple(ToolPanelType.STABILIZE, "Stabilize", Icons.Outlined.MotionPhotosAuto),
                Triple(ToolPanelType.CAMERA_TRACKING, "Camera tracking", Icons.Outlined.Videocam),
                Triple(ToolPanelType.EXTRACT_AUDIO, "Extract audio", Icons.Outlined.AudioFile),
                Triple(ToolPanelType.ISOLATE_VOICE, "Isolate voice", Icons.Outlined.RecordVoiceOver),
                Triple(ToolPanelType.REDUCE_NOISE, "Reduce noise", Icons.Outlined.GraphicEq),
                Triple(ToolPanelType.AUDIO_EFFECTS, "Audio effects", Icons.Outlined.SurroundSound),
                Triple(ToolPanelType.ENHANCE_VOICE, "Enhance voice", Icons.Outlined.Mic),
                Triple(ToolPanelType.FREEZE, "Freeze", Icons.Outlined.PauseCircle),
                Triple(ToolPanelType.REVERSE, "Reverse", Icons.Outlined.FastRewind),
                Triple(ToolPanelType.MASK, "Mask", Icons.Outlined.FilterCenterFocus),
                Triple(ToolPanelType.REMOVE_BG, "Remove BG", Icons.Outlined.PersonRemove),
                Triple(ToolPanelType.RELIGHT, "Relight", Icons.Outlined.Lightbulb),
                Triple(ToolPanelType.OPACITY, "Opacity", Icons.Outlined.Opacity),
                Triple(ToolPanelType.MOTION_BLUR, "Motion blur", Icons.Outlined.DirectionsRun),
                Triple(ToolPanelType.RETOUCH, "Retouch", Icons.Outlined.Face),
                Triple(ToolPanelType.VIDEO_QUALITY, "Video quality", Icons.Outlined.HighQuality),
                Triple(ToolPanelType.ADJUST, "Adjust", Icons.Outlined.Tune),
                Triple(ToolPanelType.FILTERS, "Filters", Icons.Outlined.Palette),
                Triple(ToolPanelType.UNLINK, "Unlink", Icons.Outlined.LinkOff)
            )

            Row(
                modifier = Modifier
                    .weight(1f)
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                clipTools.forEach { (tool, label, icon) ->
                    val isActive = activePanel == tool
                    ToolbarToolItem(
                        label = label,
                        icon = icon,
                        isActive = isActive,
                        isNew = tool == ToolPanelType.CAMERA_TRACKING,
                        onClick = { onSelectTool(tool) }
                    )
                }
            }
        }
    }
}

@Composable
fun ToolbarToolItem(
    label: String,
    icon: ImageVector,
    isActive: Boolean,
    isNew: Boolean = false,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .widthIn(min = 52.dp)
            .clip(RoundedCornerShape(4.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 4.dp, vertical = 4.dp)
    ) {
        Box(contentAlignment = Alignment.TopEnd) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isActive) AccentCoolBlue else TextSecondary,
                modifier = Modifier
                    .size(20.dp)
                    .padding(1.dp)
            )
            if (isNew) {
                Box(
                    modifier = Modifier
                        .offset(x = 10.dp, y = (-4).dp)
                        .background(AccentCoolBlue, RoundedCornerShape(2.dp))
                        .padding(horizontal = 2.dp, vertical = 0.5.dp)
                ) {
                    Text("New", fontSize = 7.sp, fontWeight = FontWeight.Bold, color = BgPureDark)
                }
            }
        }
        Spacer(modifier = Modifier.height(3.dp))
        Text(
            text = label,
            fontFamily = FontFamily.SansSerif,
            fontSize = 9.sp,
            fontWeight = if (isActive) FontWeight.Medium else FontWeight.Normal,
            color = if (isActive) AccentCoolBlue else TextSecondary,
            maxLines = 1
        )
    }
}
