package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Pure dark minimal professional color system for FrameStudio
val BgPureDark = Color(0xFF0A0A0A)
val PanelDark = Color(0xFF141414)
val PanelDarkElevated = Color(0xFF181818)
val PanelBorder = Color(0xFF222222)
val PanelBorderSubtle = Color(0xFF1C1C1C)
val PanelBorderActive = Color(0xFF333333)

// Text tokens
val TextWhite = Color(0xFFFFFFFF)
val TextPrimary = Color(0xFFE5E5E5)
val TextSecondary = Color(0xFFA0A0A0)
val TextMuted = Color(0xFF666666)
val TextDisabled = Color(0xFF444444)

// Accent color: only soft cool blue-gray (#7A9BB8) used very sparingly
val AccentCoolBlue = Color(0xFF7A9BB8)
val AccentCoolBlueMuted = Color(0xFF2C3945)
val AccentCoolBlueSubtle = Color(0xFF19222B)
val AccentCoolBlueHighlight = Color(0xFF9AB7D1)

// Track and Timeline tokens
val TrackBg = Color(0xFF0E0E0E)
val VideoClipBg = Color(0xFF161A1E)
val VideoClipBorder = Color(0xFF26303B)
val VideoClipSelected = Color(0xFF7A9BB8)

val AudioClipBg = Color(0xFF131A17)
val AudioClipBorder = Color(0xFF203028)
val WaveformBar = Color(0xFF6B9080)
val WaveformBarMuted = Color(0xFF35483F)

val TextClipBg = Color(0xFF1C1A14)
val TextClipBorder = Color(0xFF332D1F)
val TextClipPill = Color(0xFF8A826B)

val PlayheadColor = Color(0xFF7A9BB8)
val RulerTickMajor = Color(0xFF666666)
val RulerTickMinor = Color(0xFF333333)
