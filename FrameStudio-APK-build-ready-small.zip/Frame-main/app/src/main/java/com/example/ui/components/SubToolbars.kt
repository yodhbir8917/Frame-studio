package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.*
import com.example.ui.theme.*

/**
 * Renders the dedicated sub-toolbars shown in the video:
 * Audio, Text, Effects, Overlay, Captions, Filters, Adjust, Stickers, Aspect Ratio, Background
 */
@Composable
fun SubToolbarHost(
    subToolbar: SubToolbarType,
    colorGrade: ColorGradeSettings,
    activeBackgroundBlur: String,
    onBack: () -> Unit,
    onUpdateColor: ((ColorGradeSettings) -> ColorGradeSettings) -> Unit,
    onSetAspectRatio: (AspectRatio) -> Unit,
    onSetBackgroundBlur: (String) -> Unit,
    onAddSticker: (String) -> Unit,
    onOpenAutoCaptions: () -> Unit,
    onOpenSounds: () -> Unit,
    onOpenSoundFx: () -> Unit,
    onOpenVoiceover: () -> Unit,
    onOpenTextToSpeech: () -> Unit,
    onAddAudioPrompt: () -> Unit,
    onAddTextPrompt: () -> Unit,
    onAddOverlayPrompt: () -> Unit,
    onSetAnimation: (String?) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = PanelDark,
        tonalElevation = 0.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, PanelBorder)
    ) {
        when (subToolbar) {
            SubToolbarType.AUDIO_MENU -> AudioSubToolbar(
                onBack = onBack,
                onOpenSounds = onOpenSounds,
                onOpenSoundFx = onOpenSoundFx,
                onOpenVoiceover = onOpenVoiceover,
                onOpenTextToSpeech = onOpenTextToSpeech,
                onAddAudio = onAddAudioPrompt
            )
            SubToolbarType.TEXT_MENU -> TextSubToolbar(
                onBack = onBack,
                onAddText = onAddTextPrompt,
                onOpenAutoCaptions = onOpenAutoCaptions,
                onOpenTextToSpeech = onOpenTextToSpeech
            )
            SubToolbarType.EFFECTS_MENU -> EffectsSubToolbar(onBack = onBack)
            SubToolbarType.OVERLAY_MENU -> OverlaySubToolbar(onBack = onBack, onAddOverlay = onAddOverlayPrompt)
            SubToolbarType.CAPTIONS_MENU -> CaptionsSubToolbar(onBack = onBack, onOpenAutoCaptions = onOpenAutoCaptions)
            SubToolbarType.FILTERS_SHEET -> FiltersSheet(settings = colorGrade, onBack = onBack, onUpdate = onUpdateColor)
            SubToolbarType.ADJUST_SHEET -> AdjustSheet(settings = colorGrade, onBack = onBack, onUpdate = onUpdateColor)
            SubToolbarType.STICKERS_SHEET -> StickersSheet(onBack = onBack, onAddSticker = onAddSticker)
            SubToolbarType.ASPECT_RATIO_SHEET -> AspectRatioSheet(onBack = onBack, onSelectRatio = onSetAspectRatio)
            SubToolbarType.BACKGROUND_SHEET -> BackgroundSheet(activeBlur = activeBackgroundBlur, onBack = onBack, onSelectBlur = onSetBackgroundBlur)
            SubToolbarType.ANIMATIONS_SHEET -> AnimationsSheet(onBack = onBack, onSelectAnim = onSetAnimation)
            else -> {}
        }
    }
}

@Composable
fun AudioSubToolbar(
    onBack: () -> Unit,
    onOpenSounds: () -> Unit,
    onOpenSoundFx: () -> Unit,
    onOpenVoiceover: () -> Unit,
    onOpenTextToSpeech: () -> Unit,
    onAddAudio: () -> Unit
) {
    val items = listOf(
        Pair("Extract", Icons.Outlined.ContentCut),
        Pair("Sounds", Icons.Outlined.LibraryMusic),
        Pair("Sound FX", Icons.Outlined.GraphicEq),
        Pair("Record", Icons.Outlined.Mic),
        Pair("Text to audio", Icons.Outlined.RecordVoiceOver),
        Pair("Brand music", Icons.Outlined.Audiotrack),
        Pair("Custom voices", Icons.Outlined.VoiceChat),
        Pair("Copyright", Icons.Outlined.CheckCircleOutline)
    )

    GenericSubToolbarRow(
        title = "Audio",
        items = items,
        onBack = onBack,
        onItemClick = { label ->
            when (label) {
                "Sounds", "Brand music" -> onOpenSounds()
                "Sound FX" -> onOpenSoundFx()
                "Record" -> onOpenVoiceover()
                "Text to audio", "Custom voices" -> onOpenTextToSpeech()
                "Extract" -> onAddAudio()
                else -> {}
            }
        }
    )
}

@Composable
fun TextSubToolbar(
    onBack: () -> Unit,
    onAddText: () -> Unit,
    onOpenAutoCaptions: () -> Unit,
    onOpenTextToSpeech: () -> Unit = {}
) {
    val items = listOf(
        Pair("Add text", Icons.Outlined.TextFields),
        Pair("Auto Captions", Icons.Outlined.Subtitles),
        Pair("Stickers", Icons.Outlined.EmojiEmotions),
        Pair("Draw", Icons.Outlined.Draw),
        Pair("Text template", Icons.Outlined.Article),
        Pair("Text to audio", Icons.Outlined.RecordVoiceOver),
        Pair("Auto lyrics", Icons.Outlined.MusicNote),
        Pair("AI writer", Icons.Outlined.AutoFixHigh)
    )

    GenericSubToolbarRow(
        title = "Text",
        items = items,
        onBack = onBack,
        onItemClick = { label ->
            when (label) {
                "Add text", "Text template" -> onAddText()
                "Auto Captions", "Auto lyrics" -> onOpenAutoCaptions()
                "Text to audio" -> onOpenTextToSpeech()
            }
        }
    )
}

@Composable
fun EffectsSubToolbar(onBack: () -> Unit) {
    val items = listOf(
        Pair("Video effects", Icons.Outlined.AutoAwesome),
        Pair("Body effects", Icons.Outlined.Person),
        Pair("Photo effects", Icons.Outlined.PhotoFilter),
        Pair("AI effects", Icons.Outlined.AutoFixHigh)
    )
    GenericSubToolbarRow(title = "Effects", items = items, onBack = onBack, onItemClick = {})
}

@Composable
fun OverlaySubToolbar(
    onBack: () -> Unit,
    onAddOverlay: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        SubToolbarBackButton(onClick = onBack)
        Spacer(modifier = Modifier.width(16.dp))
        Button(
            onClick = onAddOverlay,
            shape = RoundedCornerShape(4.dp),
            colors = ButtonDefaults.buttonColors(containerColor = PanelDarkElevated, contentColor = TextWhite),
            border = androidx.compose.foundation.BorderStroke(1.dp, PanelBorderActive),
            modifier = Modifier.height(38.dp)
        ) {
            Icon(imageVector = Icons.Outlined.Add, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Add overlay", fontSize = 12.sp, color = TextWhite)
        }
    }
}

@Composable
fun CaptionsSubToolbar(
    onBack: () -> Unit,
    onOpenAutoCaptions: () -> Unit
) {
    val items = listOf(
        Pair("Enter captions", Icons.Outlined.Keyboard),
        Pair("Auto Captions", Icons.Outlined.Subtitles),
        Pair("Caption templates", Icons.Outlined.Style),
        Pair("Auto lyrics", Icons.Outlined.MusicNote),
        Pair("Import captions", Icons.Outlined.FileUpload)
    )
    GenericSubToolbarRow(
        title = "Captions",
        items = items,
        onBack = onBack,
        onItemClick = { onOpenAutoCaptions() }
    )
}

@Composable
fun GenericSubToolbarRow(
    title: String,
    items: List<Pair<String, ImageVector>>,
    onBack: () -> Unit,
    onItemClick: (String) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        SubToolbarBackButton(onClick = onBack)

        Row(
            modifier = Modifier
                .weight(1f)
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            items.forEach { (label, icon) ->
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .widthIn(min = 52.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .clickable { onItemClick(label) }
                        .padding(horizontal = 4.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = TextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = label,
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 9.sp,
                        color = TextSecondary,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
fun SubToolbarBackButton(onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .padding(start = 6.dp, end = 4.dp)
            .size(width = 38.dp, height = 48.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(PanelDarkElevated)
            .border(1.dp, PanelBorderActive, RoundedCornerShape(4.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.AutoMirrored.Outlined.ArrowBack,
            contentDescription = "Back",
            tint = TextPrimary,
            modifier = Modifier.size(18.dp)
        )
    }
}

/**
 * FILTERS BOTTOM SHEET:
 * Shown in video at 00:49 - 00:54 with tabs: Filters, Adjust, Video quality
 * Categories: Featured, NEW, Hits, Life, Landscape, Movie, Retro
 */
@Composable
fun FiltersSheet(
    settings: ColorGradeSettings,
    onBack: () -> Unit,
    onUpdate: ((ColorGradeSettings) -> ColorGradeSettings) -> Unit
) {
    var selectedCategory by remember { mutableStateOf("Featured") }
    val categories = listOf("Featured", "NEW", "Hits", "Life", "Landscape", "Movie", "Retro")

    val filterList = listOf(
        FilterItem("none", "None", "Featured"),
        FilterItem("clear_1", "Clear I", "Featured"),
        FilterItem("hd_upscale", "HD Upscale", "Featured", isPro = true),
        FilterItem("black_gold", "Black Gold", "Featured", isPro = true),
        FilterItem("hd_cam", "HD Cam 2", "Featured"),
        FilterItem("dracula", "Dracula", "Featured", isPro = true),
        FilterItem("humble", "Humble", "Featured"),
        FilterItem("4k_cine", "4K", "Featured"),
        FilterItem("bokeh", "Bokeh", "Featured"),
        FilterItem("hd_pet", "HD Pet", "Featured")
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 6.dp)
    ) {
        // Header with Tabs & checkmark
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("Filters", style = FrameStudioTypography.titleMedium, color = TextWhite)
                Text("Adjust", style = FrameStudioTypography.titleMedium, color = TextMuted)
                Text("Video quality", style = FrameStudioTypography.titleMedium, color = TextMuted)
            }
            IconButton(onClick = onBack, modifier = Modifier.size(28.dp)) {
                Icon(imageVector = Icons.Outlined.Check, contentDescription = "Done", tint = TextWhite)
            }
        }

        // Categories row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 14.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            categories.forEach { cat ->
                val isSel = selectedCategory == cat
                Text(
                    text = cat,
                    fontFamily = FontFamily.SansSerif,
                    fontSize = 12.sp,
                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                    color = if (isSel) TextWhite else TextSecondary,
                    modifier = Modifier.clickable { selectedCategory = cat }
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Grid of Filter Cards
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 14.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            filterList.forEach { filter ->
                val isSel = settings.selectedLut == filter.name
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clickable { onUpdate { it.copy(selectedLut = filter.name) } }
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(PanelDarkElevated)
                            .border(
                                width = if (isSel) 2.dp else 1.dp,
                                color = if (isSel) AccentCoolBlue else PanelBorderActive,
                                shape = RoundedCornerShape(6.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (filter.name == "None") {
                            Icon(imageVector = Icons.Outlined.Block, contentDescription = null, tint = TextMuted)
                        } else {
                            Image(
                                painter = painterResource(id = R.drawable.thumb_city),
                                contentDescription = filter.name,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = filter.name,
                        style = TimecodeStyleSmall,
                        fontSize = 9.sp,
                        color = if (isSel) AccentCoolBlue else TextSecondary,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

/**
 * ADJUST BOTTOM SHEET:
 * Shown in video at 00:56 - 01:00 with Smart/Customize tabs,
 * Auto adjust, Color match, Brightness, Contrast, Saturation, Exposure, Sharpen, Reset, Apply checkmark
 */
@Composable
fun AdjustSheet(
    settings: ColorGradeSettings,
    onBack: () -> Unit,
    onUpdate: ((ColorGradeSettings) -> ColorGradeSettings) -> Unit
) {
    var selectedParam by remember { mutableStateOf("Brightness") }
    var adjustTab by remember { mutableStateOf("Customize") }

    val adjustTools = listOf(
        Triple("Auto adjust", Icons.Outlined.AutoFixHigh, 0f),
        Triple("Color match", Icons.Outlined.ColorLens, 0f),
        Triple("Brightness", Icons.Outlined.BrightnessMedium, settings.brightness),
        Triple("Contrast", Icons.Outlined.Contrast, settings.contrast),
        Triple("Saturation", Icons.Outlined.InvertColors, settings.saturation),
        Triple("Exposure", Icons.Outlined.Exposure, settings.exposure),
        Triple("Temperature", Icons.Outlined.Thermostat, settings.temperature),
        Triple("Sharpen", Icons.Outlined.Details, settings.sharpen)
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 6.dp)
    ) {
        // Tab row: Smart vs Customize
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Smart",
                fontFamily = FontFamily.SansSerif,
                fontSize = 12.sp,
                fontWeight = if (adjustTab == "Smart") FontWeight.Bold else FontWeight.Normal,
                color = if (adjustTab == "Smart") TextWhite else TextMuted,
                modifier = Modifier.clickable { adjustTab = "Smart" }
            )
            Text(
                text = "Customize",
                fontFamily = FontFamily.SansSerif,
                fontSize = 12.sp,
                fontWeight = if (adjustTab == "Customize") FontWeight.Bold else FontWeight.Normal,
                color = if (adjustTab == "Customize") TextWhite else TextMuted,
                modifier = Modifier.clickable { adjustTab = "Customize" }
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Active slider
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(selectedParam.uppercase(), style = TimecodeStyleSmall, color = TextWhite, modifier = Modifier.width(90.dp))
            val curVal = when (selectedParam) {
                "Brightness" -> settings.brightness
                "Contrast" -> settings.contrast
                "Exposure" -> settings.exposure
                "Temperature" -> settings.temperature
                "Saturation" -> settings.saturation
                "Sharpen" -> settings.sharpen
                else -> 0f
            }
            Slider(
                value = curVal,
                onValueChange = { newVal ->
                    onUpdate { s ->
                        when (selectedParam) {
                            "Brightness" -> s.copy(brightness = newVal)
                            "Contrast" -> s.copy(contrast = newVal)
                            "Exposure" -> s.copy(exposure = newVal)
                            "Temperature" -> s.copy(temperature = newVal)
                            "Saturation" -> s.copy(saturation = newVal)
                            "Sharpen" -> s.copy(sharpen = newVal)
                            else -> s
                        }
                    }
                },
                valueRange = -100f..100f,
                modifier = Modifier.weight(1f),
                colors = SliderDefaults.colors(thumbColor = AccentCoolBlue, activeTrackColor = AccentCoolBlue, inactiveTrackColor = PanelBorder)
            )
            Text(String.format("%+d", curVal.toInt()), style = TimecodeStyleSmall, color = AccentCoolBlue, modifier = Modifier.width(36.dp))
        }

        // Horizontal items row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 14.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            adjustTools.forEach { (label, icon, _) ->
                val isSel = selectedParam == label
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.clickable { selectedParam = label }
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated, CircleShape)
                            .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = icon, contentDescription = label, tint = if (isSel) AccentCoolBlue else TextSecondary, modifier = Modifier.size(20.dp))
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(text = label, style = TimecodeStyleSmall, fontSize = 8.sp, color = if (isSel) TextWhite else TextSecondary)
                }
            }
        }

        // Bottom action bar: Reset on left, Apply checkmark on right
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = { onUpdate { ColorGradeSettings() } }) {
                Icon(imageVector = Icons.Outlined.RestartAlt, contentDescription = "Reset", modifier = Modifier.size(16.dp), tint = TextSecondary)
                Spacer(modifier = Modifier.width(4.dp))
                Text("Reset", style = TimecodeStyleSmall, color = TextSecondary)
            }
            IconButton(onClick = onBack, modifier = Modifier.size(32.dp)) {
                Icon(imageVector = Icons.Outlined.Check, contentDescription = "Apply", tint = TextWhite)
            }
        }
    }
}

/**
 * ASPECT RATIO BOTTOM SHEET:
 * Shown in video at 01:18 - 01:25 with options: Original, 9:16 (TikTok), 16:9, 1:1, 4:3, 3:4, 2.35:1
 */
@Composable
fun AspectRatioSheet(
    onBack: () -> Unit,
    onSelectRatio: (AspectRatio) -> Unit
) {
    var curRatio by remember { mutableStateOf(AspectRatio.VERTICAL_9_16) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            AspectRatio.values().forEach { r ->
                val isSel = curRatio == r
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clickable {
                            curRatio = r
                            onSelectRatio(r)
                        }
                ) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                            .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(6.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = r.label,
                            fontFamily = MonoTimecodeFont,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = if (isSel) TextWhite else TextSecondary
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = r.platformBadge ?: r.label,
                        style = TimecodeStyleSmall,
                        fontSize = 9.sp,
                        color = if (isSel) AccentCoolBlue else TextSecondary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Bottom label & checkmark
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Ratio", style = FrameStudioTypography.titleMedium, color = TextWhite)
            IconButton(onClick = onBack, modifier = Modifier.size(32.dp)) {
                Icon(imageVector = Icons.Outlined.Check, contentDescription = "Apply", tint = TextWhite)
            }
        }
    }
}

/**
 * BACKGROUND SHEET:
 * Shown in video at 01:27 - 01:30 with Color, Image, Blur, Brand backgrounds
 */
@Composable
fun BackgroundSheet(
    activeBlur: String,
    onBack: () -> Unit,
    onSelectBlur: (String) -> Unit
) {
    var bgTab by remember { mutableStateOf("Blur") }
    val blurs = listOf("None", "Low Blur", "Medium Blur", "High Blur")

    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            blurs.forEach { blur ->
                val isSel = activeBlur == blur
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                        .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(6.dp))
                        .clickable { onSelectBlur(blur) }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = blur, style = TimecodeStyleSmall, fontSize = 9.sp, color = if (isSel) TextWhite else TextSecondary)
                }
            }
        }
        Spacer(modifier = Modifier.height(10.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("Color", style = TimecodeStyleSmall, color = TextMuted)
                Text("Image", style = TimecodeStyleSmall, color = TextMuted)
                Text("Blur", style = TimecodeStyleSmall, color = TextWhite)
            }
            IconButton(onClick = onBack, modifier = Modifier.size(32.dp)) {
                Icon(imageVector = Icons.Outlined.Check, contentDescription = "Apply", tint = TextWhite)
            }
        }
    }
}

/**
 * STICKERS SHEET:
 * Shown in video at 01:04 - 01:07 with Stickers, GIPHY, Search, Emojis, HOT, Arrows, Subscribe
 */
@Composable
fun StickersSheet(
    onBack: () -> Unit,
    onAddSticker: (String) -> Unit
) {
    var search by remember { mutableStateOf("") }
    val stickers = listOf("🔥", "❤️", "👑", "⭐", "🤫", "✨", "👀", "🔴", "➔ Arrow", "✔ Verified", "SUBSCRIBE", "FOLLOW")

    Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("Stickers", style = FrameStudioTypography.titleMedium, color = TextWhite)
                Text("GIPHY", style = FrameStudioTypography.titleMedium, color = TextMuted)
            }
            IconButton(onClick = onBack, modifier = Modifier.size(28.dp)) {
                Icon(imageVector = Icons.Outlined.Check, contentDescription = "Done", tint = TextWhite)
            }
        }

        OutlinedTextField(
            value = search,
            onValueChange = { search = it },
            placeholder = { Text("Search stickers...", fontSize = 11.sp, color = TextMuted) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().height(44.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = AccentCoolBlue,
                unfocusedBorderColor = PanelBorder,
                focusedContainerColor = PanelDarkElevated,
                unfocusedContainerColor = PanelDarkElevated
            )
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            stickers.forEach { s ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(PanelDarkElevated)
                        .border(1.dp, PanelBorder, RoundedCornerShape(4.dp))
                        .clickable { onAddSticker(s) }
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Text(text = s, fontSize = 12.sp, color = TextWhite)
                }
            }
        }
    }
}

/**
 * ANIMATIONS SHEET:
 * Shown in video at 01:34 - 01:38 with In, Out, Combo tabs,
 * categories Trending, Basic, Light, Glitch, etc.
 */
@Composable
fun AnimationsSheet(
    onBack: () -> Unit,
    onSelectAnim: (String?) -> Unit
) {
    var animTab by remember { mutableStateOf("Out") }
    var curCategory by remember { mutableStateOf("Trending") }
    val categories = listOf("Trending", "Basic", "Light", "Glitch", "Mask", "3D", "Vibrate")

    val anims = listOf(
        Pair("None", null),
        Pair("Spider Drop", "Spider Drop"),
        Pair("Alien Fade", "Alien Fade"),
        Pair("Milk Splash", "Milk Splash"),
        Pair("Search Light", "Search Light"),
        Pair("Heart Shake", "Heart Shake"),
        Pair("Space Beam", "Space Beam"),
        Pair("Slice Apart", "Slice Apart")
    )

    Column(modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                listOf("In", "Out", "Combo").forEach { tab ->
                    Text(
                        text = tab,
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 13.sp,
                        fontWeight = if (animTab == tab) FontWeight.Bold else FontWeight.Normal,
                        color = if (animTab == tab) TextWhite else TextMuted,
                        modifier = Modifier.clickable { animTab = tab }
                    )
                }
            }
            IconButton(onClick = onBack, modifier = Modifier.size(32.dp)) {
                Icon(imageVector = Icons.Outlined.Check, contentDescription = "Done", tint = TextWhite)
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 14.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            categories.forEach { cat ->
                val isSel = curCategory == cat
                Text(
                    text = cat,
                    style = TimecodeStyleSmall,
                    fontSize = 11.sp,
                    color = if (isSel) TextWhite else TextSecondary,
                    modifier = Modifier.clickable { curCategory = cat }
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 14.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            anims.forEach { (name, animKey) ->
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.clickable { onSelectAnim(animKey) }
                ) {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(PanelDarkElevated)
                            .border(1.dp, PanelBorderActive, RoundedCornerShape(6.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (animKey == null) {
                            Icon(imageVector = Icons.Outlined.Block, contentDescription = null, tint = TextMuted)
                        } else {
                            Image(
                                painter = painterResource(id = R.drawable.thumb_city),
                                contentDescription = name,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = name, style = TimecodeStyleSmall, fontSize = 8.sp, color = TextSecondary, maxLines = 1)
                }
            }
        }
    }
}

/**
 * AUTO CAPTIONS FULL DIALOG:
 * Shown in video at 00:38 - 00:43 with:
 * Generate from: Video >
 * Spoken language: Auto detect >
 * Animated Subtitle Templates
 * Generate button in Cyan
 */
@Composable
fun AutoCaptionsModal(
    onDismiss: () -> Unit,
    onGenerate: () -> Unit
) {
    var selTemplate by remember { mutableStateOf("Default") }
    val templates = listOf("Default", "Jumps", "The Quick Brown Fox", "Glow Neon", "Split Kinetic")

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = PanelDark,
        shape = RoundedCornerShape(8.dp),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Auto captions", style = FrameStudioTypography.titleMedium, color = TextWhite)
                IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                    Icon(imageVector = Icons.Outlined.Close, contentDescription = "Close", tint = TextSecondary)
                }
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Generate from row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(PanelDarkElevated, RoundedCornerShape(4.dp))
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(imageVector = Icons.Outlined.Layers, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(16.dp))
                        Text("Generate from", style = TimecodeStyleSmall, color = TextWhite)
                    }
                    Text("Video >", style = TimecodeStyleSmall, color = TextSecondary)
                }

                // Spoken language row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(PanelDarkElevated, RoundedCornerShape(4.dp))
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(imageVector = Icons.Outlined.Translate, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(16.dp))
                        Text("Spoken language", style = TimecodeStyleSmall, color = TextWhite)
                    }
                    Text("Auto detect >", style = TimecodeStyleSmall, color = AccentCoolBlue)
                }

                // Templates row
                Text("TEMPLATES", style = TimecodeStyleSmall, color = TextMuted)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    templates.forEach { t ->
                        val isSel = selTemplate == t
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                                .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                                .clickable { selTemplate = t }
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Text(text = t, style = TimecodeStyleSmall, color = if (isSel) TextWhite else TextSecondary)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onGenerate,
                shape = RoundedCornerShape(4.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AccentCoolBlue, contentColor = BgPureDark),
                modifier = Modifier.fillMaxWidth().height(42.dp)
            ) {
                Text("Generate", fontWeight = FontWeight.Bold, color = BgPureDark)
            }
        }
    )
}

/**
 * COVER PICKER MODAL:
 * Scrubber to select the video thumbnail / cover frame and add template text
 */
@Composable
fun CoverPickerModal(
    currentTimeSec: Float,
    totalDurationSec: Float,
    onDismiss: () -> Unit,
    onSaveCover: (Float) -> Unit
) {
    var coverSec by remember { mutableFloatStateOf(currentTimeSec) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = PanelDark,
        shape = RoundedCornerShape(8.dp),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("SELECT COVER FRAME", style = TimecodeStyleSmall, color = AccentCoolBlue, letterSpacing = 1.sp)
                IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                    Icon(imageVector = Icons.Outlined.Close, contentDescription = "Close", tint = TextSecondary)
                }
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 9f)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.Black)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.thumb_architecture),
                        contentDescription = "Cover preview",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                    Text(
                        text = "COVER: ${formatShortDuration(coverSec)}",
                        fontFamily = MonoTimecodeFont,
                        fontSize = 10.sp,
                        color = Color.White,
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(6.dp)
                            .background(Color.Black.copy(alpha = 0.8f))
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    )
                }

                Slider(
                    value = coverSec,
                    onValueChange = { coverSec = it },
                    valueRange = 0f..totalDurationSec,
                    colors = SliderDefaults.colors(thumbColor = AccentCoolBlue, activeTrackColor = AccentCoolBlue)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSaveCover(coverSec) },
                shape = RoundedCornerShape(4.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AccentCoolBlue, contentColor = BgPureDark)
            ) {
                Text("Save Cover", color = BgPureDark)
            }
        }
    )
}

/**
 * EXPORT DRAFT ZIP MODAL
 */
@Composable
fun ExportDraftZipModal(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = PanelDark,
        shape = RoundedCornerShape(8.dp),
        title = {
            Text("EXPORT DRAFT ZIP", style = TimecodeStyleSmall, color = AccentCoolBlue, letterSpacing = 1.sp)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Package timeline sequences, proxy media, color grades, and audio assets into an editable project archive (.zip) for backup or sharing.", style = FrameStudioTypography.bodyMedium, color = TextPrimary)
                Text("Target: Internal Storage / FrameStudio / Drafts / Master_01.fsz", fontFamily = MonoTimecodeFont, fontSize = 10.sp, color = TextSecondary)
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                shape = RoundedCornerShape(4.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AccentCoolBlue, contentColor = BgPureDark)
            ) {
                Text("Save Zip Archive", color = BgPureDark)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        }
    )
}

/**
 * SOUNDS / MUSIC LIBRARY MODAL:
 * Categorized music library with preview playback and add to timeline
 */
@Composable
fun SoundsPickerModal(
    onDismiss: () -> Unit,
    onSelectSound: (String, Float) -> Unit
) {
    var selectedCat by remember { mutableStateOf("Featured") }
    val categories = listOf("Featured", "Vlog", "Cinematic", "Hip-hop", "Lofi Beat", "Ambient")

    val tracks = listOf(
        Triple("Nordic Atmospheric Horizon", "2:14", 134f),
        Triple("Chill Sunday Dusk Groove", "1:45", 105f),
        Triple("Urban Street Drift Beat", "1:30", 90f),
        Triple("Cinematic Strings Tension", "2:40", 160f),
        Triple("Morning Coffee Acoustic", "1:18", 78f),
        Triple("Midnight Synthesizer Pulse", "2:05", 125f)
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = PanelDark,
        shape = RoundedCornerShape(8.dp),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("SOUNDS & MUSIC", style = TimecodeStyleSmall, color = AccentCoolBlue, letterSpacing = 1.sp)
                IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                    Icon(imageVector = Icons.Outlined.Close, contentDescription = "Close", tint = TextSecondary)
                }
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Category chips
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    categories.forEach { cat ->
                        val isSel = selectedCat == cat
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                                .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                                .clickable { selectedCat = cat }
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Text(text = cat, style = TimecodeStyleSmall, fontSize = 9.sp, color = if (isSel) TextWhite else TextSecondary)
                        }
                    }
                }

                // Music track list
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    tracks.forEach { (name, durText, durSec) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(4.dp))
                                .background(PanelDarkElevated)
                                .border(0.5.dp, PanelBorderActive, RoundedCornerShape(4.dp))
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .background(AccentCoolBlueSubtle, RoundedCornerShape(4.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(imageVector = Icons.Outlined.MusicNote, contentDescription = null, tint = AccentCoolBlue, modifier = Modifier.size(16.dp))
                                }
                                Column {
                                    Text(text = name, fontFamily = FontFamily.SansSerif, fontSize = 11.sp, color = TextWhite, maxLines = 1)
                                    Text(text = "$durText • Original Audio", style = TimecodeStyleSmall, fontSize = 8.sp, color = TextMuted)
                                }
                            }
                            Button(
                                onClick = {
                                    onSelectSound(name, durSec)
                                    onDismiss()
                                },
                                shape = RoundedCornerShape(3.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = AccentCoolBlue, contentColor = BgPureDark),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                modifier = Modifier.height(26.dp)
                            ) {
                                Text("Use", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = BgPureDark)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {}
    )
}

/**
 * SOUND FX MODAL:
 * Sound effects library (Whoosh, Click, Boom, Glitch, etc.)
 */
@Composable
fun SoundFxModal(
    onDismiss: () -> Unit,
    onSelectFx: (String, Float) -> Unit
) {
    val sfxList = listOf(
        Pair("Transition Whoosh Fast", 0.8f),
        Pair("Cinematic Deep Boom", 2.2f),
        Pair("Camera Shutter Click", 0.4f),
        Pair("Digital Glitch Noise", 1.2f),
        Pair("Tension Riser Buildup", 3.5f),
        Pair("Mouse Double Click Pop", 0.3f),
        Pair("Retro Vinyl Scratch", 1.0f)
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = PanelDark,
        shape = RoundedCornerShape(8.dp),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("SOUND FX LIBRARY", style = TimecodeStyleSmall, color = AccentCoolBlue, letterSpacing = 1.sp)
                IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                    Icon(imageVector = Icons.Outlined.Close, contentDescription = "Close", tint = TextSecondary)
                }
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                sfxList.forEach { (name, durSec) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(4.dp))
                            .background(PanelDarkElevated)
                            .border(0.5.dp, PanelBorderActive, RoundedCornerShape(4.dp))
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(imageVector = Icons.Outlined.GraphicEq, contentDescription = null, tint = AccentCoolBlue, modifier = Modifier.size(16.dp))
                            Text(text = "$name (${durSec}s)", fontFamily = FontFamily.SansSerif, fontSize = 11.sp, color = TextWhite)
                        }
                        Button(
                            onClick = {
                                onSelectFx(name, durSec)
                                onDismiss()
                            },
                            shape = RoundedCornerShape(3.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = AccentCoolBlue, contentColor = BgPureDark),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(26.dp)
                        ) {
                            Text("Use", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = BgPureDark)
                        }
                    }
                }
            }
        },
        confirmButton = {}
    )
}

/**
 * VOICEOVER RECORDING MODAL:
 * Live voiceover recording with animated volume meter, elapsed timer, and insert
 */
@Composable
fun VoiceoverRecordModal(
    onDismiss: () -> Unit,
    onSaveVoiceover: (Float) -> Unit
) {
    var isRecording by remember { mutableStateOf(false) }
    var elapsedSec by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(isRecording) {
        if (isRecording) {
            elapsedSec = 0f
            while (isRecording) {
                kotlinx.coroutines.delay(100)
                elapsedSec += 0.1f
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = PanelDark,
        shape = RoundedCornerShape(8.dp),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("RECORD VOICEOVER", style = TimecodeStyleSmall, color = AccentCoolBlue, letterSpacing = 1.sp)
                IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                    Icon(imageVector = Icons.Outlined.Close, contentDescription = "Close", tint = TextSecondary)
                }
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = if (isRecording) "Recording Voiceover..." else "Tap the microphone to start recording narration at playhead.",
                    style = FrameStudioTypography.bodyMedium,
                    color = if (isRecording) AccentCoolBlue else TextSecondary,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )

                // Timer
                Text(
                    text = String.format("00:%04.1f", elapsedSec),
                    fontFamily = MonoTimecodeFont,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isRecording) Color.Red else TextWhite
                )

                // Simulated dB audio meter bars
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(36.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    repeat(18) { index ->
                        val barHeight = if (isRecording) {
                            (10 + (index * 7 + (elapsedSec * 10).toInt()) % 26).dp
                        } else 6.dp
                        Box(
                            modifier = Modifier
                                .padding(horizontal = 2.dp)
                                .width(3.dp)
                                .height(barHeight)
                                .background(if (isRecording) AccentCoolBlue else PanelBorderActive, RoundedCornerShape(1.dp))
                        )
                    }
                }

                // Big Circular Record Button
                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .clip(CircleShape)
                        .background(if (isRecording) Color.Red.copy(alpha = 0.2f) else PanelDarkElevated)
                        .border(2.dp, if (isRecording) Color.Red else AccentCoolBlue, CircleShape)
                        .clickable { isRecording = !isRecording },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isRecording) Icons.Outlined.Stop else Icons.Outlined.Mic,
                        contentDescription = "Record",
                        tint = if (isRecording) Color.Red else AccentCoolBlue,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val finalDur = if (elapsedSec > 0.5f) elapsedSec else 4.0f
                    onSaveVoiceover(finalDur)
                    onDismiss()
                },
                shape = RoundedCornerShape(4.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AccentCoolBlue, contentColor = BgPureDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Insert on Audio Track", fontWeight = FontWeight.Bold, color = BgPureDark)
            }
        }
    )
}

/**
 * TEXT TO SPEECH (VOICE SYNTHESIS) MODAL:
 * Generates natural narration voice clip from typed text
 */
@Composable
fun TextToSpeechModal(
    onDismiss: () -> Unit,
    onGenerateVoice: (String) -> Unit
) {
    var textPrompt by remember { mutableStateOf("Welcome to FrameStudio professional video editor!") }
    var selectedVoice by remember { mutableStateOf("Jessie (Storyteller)") }
    val voices = listOf("Jessie (Storyteller)", "David (Deep Cinematic)", "Aria (Natural Vlog)", "Marcus (Authoritative)")

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = PanelDark,
        shape = RoundedCornerShape(8.dp),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("TEXT TO SPEECH (AI VOICES)", style = TimecodeStyleSmall, color = AccentCoolBlue, letterSpacing = 1.sp)
                IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                    Icon(imageVector = Icons.Outlined.Close, contentDescription = "Close", tint = TextSecondary)
                }
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = textPrompt,
                    onValueChange = { textPrompt = it },
                    label = { Text("Script Text", fontSize = 11.sp, color = TextMuted) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AccentCoolBlue,
                        unfocusedBorderColor = PanelBorder,
                        focusedContainerColor = PanelDarkElevated,
                        unfocusedContainerColor = PanelDarkElevated
                    )
                )

                Text("VOICE MODEL", style = TimecodeStyleSmall, color = TextMuted)
                voices.forEach { v ->
                    val isSel = selectedVoice == v
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                            .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                            .clickable { selectedVoice = v }
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(imageVector = Icons.Outlined.RecordVoiceOver, contentDescription = null, tint = if (isSel) AccentCoolBlue else TextSecondary, modifier = Modifier.size(16.dp))
                        Text(text = v, fontFamily = FontFamily.SansSerif, fontSize = 11.sp, color = if (isSel) TextWhite else TextSecondary)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onGenerateVoice(textPrompt)
                    onDismiss()
                },
                shape = RoundedCornerShape(4.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AccentCoolBlue, contentColor = BgPureDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Generate Speech Audio", fontWeight = FontWeight.Bold, color = BgPureDark)
            }
        }
    )
}
