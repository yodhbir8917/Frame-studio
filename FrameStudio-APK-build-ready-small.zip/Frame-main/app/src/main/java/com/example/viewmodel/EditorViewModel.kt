package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.R
import com.example.model.*
import com.example.util.ExtractedMediaInfo
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class ScreenDestination {
    HOME,
    EDITOR,
    MEDIA_LIBRARY,
    EXPORT,
    TEMPLATES,
    SETTINGS
}

data class ExportSimulationState(
    val isExporting: Boolean = false,
    val progress: Float = 0f,
    val currentFrame: Int = 0,
    val totalFrames: Int = 2160,
    val renderFps: Int = 64,
    val timeRemainingSec: Int = 34,
    val isCompleted: Boolean = false
)

data class EditorUiState(
    val currentScreen: ScreenDestination = ScreenDestination.HOME,
    val activeBottomTab: ScreenDestination = ScreenDestination.HOME,
    val projects: List<Project> = emptyList(),
    val currentProject: Project? = null,
    val isPlaying: Boolean = false,
    val currentTimeSec: Float = 14.5f,
    val selectedClipId: String? = null,
    val activeToolPanel: ToolPanelType = ToolPanelType.NONE,
    val activeSubToolbar: SubToolbarType? = null,
    val showGridOverlay: Boolean = false,
    val timelineZoom: Float = 36f, // pixels per second
    val colorGrade: ColorGradeSettings = ColorGradeSettings(),
    val exportConfig: ExportConfig = ExportConfig(),
    val exportSimulation: ExportSimulationState = ExportSimulationState(),
    val mediaItems: List<MediaItem> = emptyList(),
    val selectedMediaIds: Set<String> = emptySet(),
    val templates: List<TemplateItem> = emptyList(),
    val magneticSnap: Boolean = true,
    val rippleEdit: Boolean = true,
    val audioScrubbing: Boolean = true,
    val canUndo: Boolean = true,
    val canRedo: Boolean = false,
    val activeEffect: String = "Film Grain 16mm",
    val activeTransition: String = "Cross Dissolve",
    val activeBackgroundBlur: String = "None",
    val activeStickers: List<String> = emptyList(),
    val isExportDraftZipModalOpen: Boolean = false,
    val isAutoCaptionsModalOpen: Boolean = false,
    val isCoverPickerOpen: Boolean = false,
    val isSoundsModalOpen: Boolean = false,
    val isSoundFxModalOpen: Boolean = false,
    val isVoiceoverModalOpen: Boolean = false,
    val isTextToSpeechModalOpen: Boolean = false
)

class EditorViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(EditorUiState())
    val uiState: StateFlow<EditorUiState> = _uiState.asStateFlow()

    private var playbackJob: Job? = null
    private var exportJob: Job? = null
    private val screenBackStack = mutableListOf<ScreenDestination>()

    init {
        loadInitialData()
    }

    private fun loadInitialData() {
        val sampleWaveform1 = listOf(0.2f, 0.4f, 0.8f, 0.9f, 0.6f, 0.3f, 0.7f, 0.85f, 0.5f, 0.2f, 0.9f, 1f, 0.7f, 0.4f, 0.6f, 0.8f, 0.3f, 0.5f, 0.8f, 0.9f, 0.4f, 0.2f, 0.6f, 0.8f)
        val sampleWaveform2 = listOf(0.4f, 0.7f, 0.9f, 0.8f, 0.5f, 0.6f, 0.85f, 0.7f, 0.3f, 0.5f, 0.8f, 0.95f, 0.6f, 0.4f, 0.7f, 0.9f, 0.8f, 0.5f, 0.4f, 0.7f, 0.6f, 0.3f, 0.5f, 0.4f)
        val sampleWaveformSfx = listOf(0.1f, 0.15f, 0.3f, 0.95f, 0.7f, 0.3f, 0.1f, 0.05f, 0.1f, 0.6f, 0.8f, 0.2f, 0.05f, 0.05f, 0.4f, 0.9f, 0.5f, 0.1f)

        val project1Tracks = listOf(
            TimelineTrack(
                id = "track_video",
                type = TrackType.VIDEO,
                title = "Primary Video",
                clips = listOf(
                    TimelineClip(
                        id = "clip_vid_1",
                        name = "01_Architectural_Exterior.mov",
                        startTimeSec = 0f,
                        durationSec = 8.5f,
                        thumbnailRes = R.drawable.thumb_architecture,
                        transitionIn = "Dip to Black"
                    ),
                    TimelineClip(
                        id = "clip_vid_2",
                        name = "02_Misty_Pine_Ridge.mov",
                        startTimeSec = 8.5f,
                        durationSec = 11.0f,
                        thumbnailRes = R.drawable.thumb_nature,
                        transitionIn = "Cross Dissolve"
                    ),
                    TimelineClip(
                        id = "clip_vid_3",
                        name = "03_Tokyo_Overcast_Dusk.mov",
                        startTimeSec = 19.5f,
                        durationSec = 12.0f,
                        thumbnailRes = R.drawable.thumb_city,
                        transitionIn = "Whip Pan"
                    ),
                    TimelineClip(
                        id = "clip_vid_4",
                        name = "04_Rain_Highway_Drift.mov",
                        startTimeSec = 31.5f,
                        durationSec = 9.5f,
                        thumbnailRes = R.drawable.thumb_night_drive
                    )
                )
            ),
            TimelineTrack(
                id = "track_audio",
                type = TrackType.AUDIO,
                title = "Master Soundtrack",
                clips = listOf(
                    TimelineClip(
                        id = "clip_aud_1",
                        name = "Ambient Drone - E Minor 48kHz.wav",
                        startTimeSec = 0f,
                        durationSec = 22.0f,
                        waveformPoints = sampleWaveform1,
                        volume = 0.9f
                    ),
                    TimelineClip(
                        id = "clip_aud_2",
                        name = "Cinematic Sub Bass Riser.wav",
                        startTimeSec = 22.0f,
                        durationSec = 19.0f,
                        waveformPoints = sampleWaveform2,
                        volume = 0.85f
                    )
                )
            ),
            TimelineTrack(
                id = "track_text",
                type = TrackType.TEXT,
                title = "Titles & Subtitles",
                clips = listOf(
                    TimelineClip(
                        id = "clip_txt_1",
                        name = "Title: Nordic Monolith",
                        startTimeSec = 2.0f,
                        durationSec = 6.0f,
                        textOverlay = "CHAPTER 01: NORDIC MONOLITH"
                    ),
                    TimelineClip(
                        id = "clip_txt_2",
                        name = "Sub: Coastline Minimal",
                        startTimeSec = 12.0f,
                        durationSec = 8.0f,
                        textOverlay = "NATURAL LIGHT & CONCRETE"
                    )
                )
            )
        )

        val project1 = Project(
            id = "proj_1",
            name = "Nordic Architecture Reel",
            thumbnailRes = R.drawable.thumb_architecture,
            durationSec = 41.0f,
            lastEdited = "Edited 18m ago",
            aspectRatio = AspectRatio.CINEMA_16_9,
            fps = 24,
            resolution = Resolution.UHD_4K,
            tracks = project1Tracks
        )

        val project2 = Project(
            id = "proj_2",
            name = "Tokyo Fog 4K Master",
            thumbnailRes = R.drawable.thumb_city,
            durationSec = 28.5f,
            lastEdited = "Edited 2h ago",
            aspectRatio = AspectRatio.ANAMORPHIC_239,
            fps = 30,
            resolution = Resolution.UHD_4K,
            tracks = project1Tracks
        )

        val project3 = Project(
            id = "proj_3",
            name = "Misty Pines Cinematic",
            thumbnailRes = R.drawable.thumb_nature,
            durationSec = 52.0f,
            lastEdited = "Yesterday",
            aspectRatio = AspectRatio.VERTICAL_9_16,
            fps = 60,
            resolution = Resolution.FHD_1080P,
            tracks = project1Tracks
        )

        val project4 = Project(
            id = "proj_4",
            name = "Night Drift Wet Asphalt",
            thumbnailRes = R.drawable.thumb_night_drive,
            durationSec = 34.2f,
            lastEdited = "3 days ago",
            aspectRatio = AspectRatio.CINEMA_16_9,
            fps = 24,
            resolution = Resolution.FHD_1080P,
            tracks = project1Tracks
        )

        val sampleMedia = listOf(
            MediaItem("m1", "A001_C002_0824.mov", MediaTypeCategory.VIDEOS, R.drawable.thumb_architecture, 8.5f, "4K 24fps", "184 MB"),
            MediaItem("m2", "A001_C005_0824.mov", MediaTypeCategory.VIDEOS, R.drawable.thumb_nature, 11.0f, "4K 60fps", "240 MB"),
            MediaItem("m3", "A002_C011_0825.mov", MediaTypeCategory.VIDEOS, R.drawable.thumb_city, 12.0f, "4K 24fps", "295 MB"),
            MediaItem("m4", "A003_C001_0826.mov", MediaTypeCategory.VIDEOS, R.drawable.thumb_night_drive, 9.5f, "1080p 120fps", "132 MB"),
            MediaItem("m5", "STILL_EXT_MONOLITH.dng", MediaTypeCategory.PHOTOS, R.drawable.thumb_architecture, 0f, "8256 × 5504", "48 MB"),
            MediaItem("m6", "STILL_FOG_CANOPY.dng", MediaTypeCategory.PHOTOS, R.drawable.thumb_nature, 0f, "8256 × 5504", "52 MB"),
            MediaItem("m7", "STILL_TOKYO_ROOFTOP.jpg", MediaTypeCategory.PHOTOS, R.drawable.thumb_city, 0f, "6000 × 4000", "18 MB"),
            MediaItem("m8", "STILL_RAIN_HIGHWAY.jpg", MediaTypeCategory.PHOTOS, R.drawable.thumb_night_drive, 0f, "6000 × 4000", "22 MB")
        )

        val sampleTemplates = listOf(
            TemplateItem(
                id = "tpl_1",
                title = "Cinematic 2.39:1 Anamorphic",
                category = "Film & Narrative",
                aspectRatio = AspectRatio.ANAMORPHIC_239,
                durationSec = 30f,
                clipCount = 6,
                thumbnailRes = R.drawable.thumb_city,
                description = "Letterboxed ultra-widescreen layout with slow cinematic dissolves and serif mono tags."
            ),
            TemplateItem(
                id = "tpl_2",
                title = "Nordic Architecture Minimal",
                category = "Commercial & Portfolio",
                aspectRatio = AspectRatio.CINEMA_16_9,
                durationSec = 45f,
                clipCount = 8,
                thumbnailRes = R.drawable.thumb_architecture,
                description = "Strict geometry, clean cuts, zero flashy effects, pure concrete and daylight focus."
            ),
            TemplateItem(
                id = "tpl_3",
                title = "Vertical Reel 9:16 Editorial",
                category = "Social & Stories",
                aspectRatio = AspectRatio.VERTICAL_9_16,
                durationSec = 25f,
                clipCount = 5,
                thumbnailRes = R.drawable.thumb_nature,
                description = "High density 9:16 composition for mobile displays with centered caption safe guides."
            ),
            TemplateItem(
                id = "tpl_4",
                title = "Night Highway Motion",
                category = "Dynamic & Automotive",
                aspectRatio = AspectRatio.CINEMA_16_9,
                durationSec = 35f,
                clipCount = 7,
                thumbnailRes = R.drawable.thumb_night_drive,
                description = "Synchronized speed ramps with beat-matched cut points and deep black levels."
            )
        )

        _uiState.update {
            it.copy(
                projects = listOf(project1, project2, project3, project4),
                currentProject = project1,
                currentTimeSec = 14.5f,
                selectedClipId = null,
                mediaItems = sampleMedia,
                templates = sampleTemplates
            )
        }
    }

    fun navigateTo(screen: ScreenDestination) {
        if (_uiState.value.currentScreen != screen) {
            screenBackStack.add(_uiState.value.currentScreen)
            _uiState.update {
                it.copy(
                    currentScreen = screen,
                    activeBottomTab = if (screen in listOf(ScreenDestination.HOME, ScreenDestination.TEMPLATES, ScreenDestination.MEDIA_LIBRARY, ScreenDestination.SETTINGS)) screen else it.activeBottomTab
                )
            }
        }
    }

    fun navigateBack(): Boolean {
        if (screenBackStack.isNotEmpty()) {
            val previous = screenBackStack.removeAt(screenBackStack.size - 1)
            _uiState.update {
                it.copy(
                    currentScreen = previous,
                    activeBottomTab = if (previous in listOf(ScreenDestination.HOME, ScreenDestination.TEMPLATES, ScreenDestination.MEDIA_LIBRARY, ScreenDestination.SETTINGS)) previous else it.activeBottomTab
                )
            }
            return true
        } else if (_uiState.value.currentScreen != ScreenDestination.HOME) {
            _uiState.update {
                it.copy(
                    currentScreen = ScreenDestination.HOME,
                    activeBottomTab = ScreenDestination.HOME
                )
            }
            return true
        }
        return false
    }

    fun openProject(project: Project) {
        _uiState.update {
            it.copy(
                currentProject = project,
                currentTimeSec = 0f,
                isPlaying = false,
                selectedClipId = null,
                activeToolPanel = ToolPanelType.NONE
            )
        }
        navigateTo(ScreenDestination.EDITOR)
    }

    fun createNewProject(
        name: String = "Untitled Master 01",
        ratio: AspectRatio = AspectRatio.CINEMA_16_9,
        fps: Int = 30,
        resolution: Resolution = Resolution.FHD_1080P
    ) {
        val newProj = Project(
            id = "proj_${System.currentTimeMillis()}",
            name = name,
            thumbnailRes = R.drawable.thumb_architecture,
            durationSec = 35.0f,
            lastEdited = "Just now",
            aspectRatio = ratio,
            fps = fps,
            resolution = resolution,
            tracks = _uiState.value.currentProject?.tracks ?: emptyList()
        )
        _uiState.update {
            it.copy(
                projects = listOf(newProj) + it.projects,
                currentProject = newProj,
                currentTimeSec = 0f,
                isPlaying = false
            )
        }
        navigateTo(ScreenDestination.EDITOR)
    }

    fun setProjectResolution(resolution: Resolution) {
        val proj = _uiState.value.currentProject ?: return
        _uiState.update {
            it.copy(currentProject = proj.copy(resolution = resolution))
        }
    }

    fun createProjectFromGallery(
        name: String = "My Gallery Reel",
        ratio: AspectRatio = AspectRatio.VERTICAL_9_16,
        fps: Int = 30,
        resolution: Resolution = Resolution.FHD_1080P,
        mediaList: List<ExtractedMediaInfo>
    ) {
        if (mediaList.isEmpty()) {
            createNewProject(name = name, ratio = ratio, fps = fps, resolution = resolution)
            return
        }

        var cumulativeTime = 0f
        val videoClips = mediaList.mapIndexed { index, media ->
            val clipDur = if (media.durationSec > 0f) media.durationSec else 5.0f
            val clip = TimelineClip(
                id = "clip_gallery_${System.currentTimeMillis()}_$index",
                name = media.displayName,
                startTimeSec = cumulativeTime,
                durationSec = clipDur,
                thumbnailRes = R.drawable.thumb_architecture,
                contentUri = media.contentUri,
                transitionIn = if (index > 0) "Cross Dissolve" else "None"
            )
            cumulativeTime += clipDur
            clip
        }

        val videoTrack = TimelineTrack(
            id = "track_vid_${System.currentTimeMillis()}",
            type = TrackType.VIDEO,
            title = "Main Video",
            clips = videoClips
        )

        val audioTrack = TimelineTrack(
            id = "track_aud_${System.currentTimeMillis()}",
            type = TrackType.AUDIO,
            title = "Audio",
            clips = emptyList()
        )

        val textTrack = TimelineTrack(
            id = "track_txt_${System.currentTimeMillis()}",
            type = TrackType.TEXT,
            title = "Text",
            clips = emptyList()
        )

        val newProj = Project(
            id = "proj_${System.currentTimeMillis()}",
            name = name.ifBlank { mediaList.first().displayName.substringBeforeLast(".") },
            thumbnailRes = R.drawable.thumb_architecture,
            durationSec = cumulativeTime.coerceAtLeast(3.0f),
            lastEdited = "Just now",
            aspectRatio = ratio,
            fps = fps,
            resolution = resolution,
            tracks = listOf(videoTrack, audioTrack, textTrack)
        )

        val newMediaItems = mediaList.mapIndexed { idx, media ->
            MediaItem(
                id = "gal_item_${System.currentTimeMillis()}_$idx",
                title = media.displayName,
                category = MediaTypeCategory.VIDEOS,
                thumbnailRes = null,
                contentUri = media.contentUri,
                durationSec = media.durationSec,
                resolution = "FHD Video",
                fileSize = "Gallery Clip"
            )
        }

        _uiState.update {
            it.copy(
                projects = listOf(newProj) + it.projects,
                currentProject = newProj,
                mediaItems = newMediaItems + it.mediaItems,
                currentTimeSec = 0f,
                isPlaying = false,
                selectedClipId = videoClips.firstOrNull()?.id,
                activeToolPanel = ToolPanelType.NONE
            )
        }
        navigateTo(ScreenDestination.EDITOR)
    }

    fun addGalleryClipsToCurrentProject(mediaList: List<ExtractedMediaInfo>) {
        if (mediaList.isEmpty()) return
        val proj = _uiState.value.currentProject ?: return
        val vidTrack = proj.tracks.firstOrNull { it.type == TrackType.VIDEO } ?: return
        var currentEnd = vidTrack.clips.maxOfOrNull { it.endTimeSec } ?: 0f

        val newClips = mutableListOf<TimelineClip>()
        mediaList.forEachIndexed { idx, media ->
            val clipDur = if (media.durationSec > 0f) media.durationSec else 5.0f
            newClips.add(
                TimelineClip(
                    id = "clip_gal_add_${System.currentTimeMillis()}_$idx",
                    name = media.displayName,
                    startTimeSec = currentEnd,
                    durationSec = clipDur,
                    thumbnailRes = R.drawable.thumb_architecture,
                    contentUri = media.contentUri,
                    transitionIn = "Cross Dissolve"
                )
            )
            currentEnd += clipDur
        }

        val updatedTracks = proj.tracks.map {
            if (it.id == vidTrack.id) it.copy(clips = it.clips + newClips) else it
        }

        val newMediaItems = mediaList.mapIndexed { idx, media ->
            MediaItem(
                id = "gal_item_${System.currentTimeMillis()}_$idx",
                title = media.displayName,
                category = MediaTypeCategory.VIDEOS,
                thumbnailRes = null,
                contentUri = media.contentUri,
                durationSec = media.durationSec,
                resolution = "FHD Video",
                fileSize = "Gallery Clip"
            )
        }

        _uiState.update {
            it.copy(
                currentProject = proj.copy(tracks = updatedTracks, durationSec = currentEnd),
                mediaItems = newMediaItems + it.mediaItems,
                selectedClipId = newClips.firstOrNull()?.id,
                canUndo = true
            )
        }
    }

    fun importMediaFromGallery(mediaList: List<ExtractedMediaInfo>) {
        if (mediaList.isEmpty()) return
        val newMediaItems = mediaList.mapIndexed { idx, media ->
            MediaItem(
                id = "gal_item_${System.currentTimeMillis()}_$idx",
                title = media.displayName,
                category = MediaTypeCategory.VIDEOS,
                thumbnailRes = null,
                contentUri = media.contentUri,
                durationSec = media.durationSec,
                resolution = "FHD Video",
                fileSize = "Gallery Clip"
            )
        }
        _uiState.update {
            it.copy(mediaItems = newMediaItems + it.mediaItems)
        }
    }

    fun togglePlayback() {
        val willPlay = !_uiState.value.isPlaying
        _uiState.update { it.copy(isPlaying = willPlay) }
        if (willPlay) {
            startPlaybackLoop()
        } else {
            playbackJob?.cancel()
            playbackJob = null
        }
    }

    private fun startPlaybackLoop() {
        playbackJob?.cancel()
        playbackJob = viewModelScope.launch {
            val maxDur = _uiState.value.currentProject?.durationSec ?: 40f
            while (isActive && _uiState.value.isPlaying) {
                delay(33)
                _uiState.update { state ->
                    val next = state.currentTimeSec + 0.033f
                    if (next >= maxDur) {
                        state.copy(currentTimeSec = 0f, isPlaying = false)
                    } else {
                        state.copy(currentTimeSec = next)
                    }
                }
                if (!_uiState.value.isPlaying) break
            }
        }
    }

    fun seekTo(seconds: Float) {
        val maxDur = _uiState.value.currentProject?.durationSec ?: 40f
        val clamped = seconds.coerceIn(0f, maxDur)
        _uiState.update { it.copy(currentTimeSec = clamped) }
    }

    fun stepFrame(forward: Boolean) {
        val fps = _uiState.value.currentProject?.fps ?: 30
        val delta = 1f / fps
        val current = _uiState.value.currentTimeSec
        val newTime = if (forward) current + delta else current - delta
        seekTo(newTime)
    }

    fun selectClip(clipId: String?) {
        _uiState.update {
            it.copy(selectedClipId = if (it.selectedClipId == clipId) null else clipId)
        }
    }

    fun deselectClip() {
        _uiState.update { it.copy(selectedClipId = null, activeToolPanel = ToolPanelType.NONE) }
    }

    fun selectClipAtPlayhead() {
        val proj = _uiState.value.currentProject ?: return
        val time = _uiState.value.currentTimeSec
        val vidTrack = proj.tracks.firstOrNull { it.type == TrackType.VIDEO } ?: return
        val clip = vidTrack.clips.firstOrNull { time >= it.startTimeSec && time <= it.endTimeSec }
            ?: vidTrack.clips.firstOrNull()
        if (clip != null) {
            _uiState.update { it.copy(selectedClipId = clip.id) }
        }
    }

    fun toggleKeyframeAtPlayhead() {
        val selId = _uiState.value.selectedClipId ?: return
        val proj = _uiState.value.currentProject ?: return
        val updatedTracks = proj.tracks.map { track ->
            track.copy(clips = track.clips.map { clip ->
                if (clip.id == selId) clip.copy(hasKeyframe = !clip.hasKeyframe) else clip
            })
        }
        _uiState.update { it.copy(currentProject = proj.copy(tracks = updatedTracks)) }
    }

    fun openSubToolbar(type: SubToolbarType) {
        _uiState.update { it.copy(activeSubToolbar = type, activeToolPanel = ToolPanelType.NONE) }
    }

    fun closeSubToolbar() {
        _uiState.update { it.copy(activeSubToolbar = null) }
    }

    fun toggleGlobalMute() {
        val proj = _uiState.value.currentProject ?: return
        val updated = proj.copy(isAudioMutedGlobally = !proj.isAudioMutedGlobally)
        _uiState.update { it.copy(currentProject = updated) }
    }

    fun setCoverTime(sec: Float) {
        val proj = _uiState.value.currentProject ?: return
        val updated = proj.copy(coverTimeSec = sec)
        _uiState.update { it.copy(currentProject = updated, isCoverPickerOpen = false) }
    }

    fun setBackgroundBlur(blur: String) {
        _uiState.update { it.copy(activeBackgroundBlur = blur) }
    }

    fun addSticker(sticker: String) {
        _uiState.update { it.copy(activeStickers = it.activeStickers + sticker) }
    }

    fun removeSticker(sticker: String) {
        _uiState.update { it.copy(activeStickers = it.activeStickers - sticker) }
    }

    fun setExportDraftZipModal(open: Boolean) {
        _uiState.update { it.copy(isExportDraftZipModalOpen = open) }
    }

    fun setAutoCaptionsModal(open: Boolean) {
        _uiState.update { it.copy(isAutoCaptionsModalOpen = open) }
    }

    fun setCoverPickerModal(open: Boolean) {
        _uiState.update { it.copy(isCoverPickerOpen = open) }
    }

    fun setSoundsModal(open: Boolean) {
        _uiState.update { it.copy(isSoundsModalOpen = open) }
    }

    fun setSoundFxModal(open: Boolean) {
        _uiState.update { it.copy(isSoundFxModalOpen = open) }
    }

    fun setVoiceoverModal(open: Boolean) {
        _uiState.update { it.copy(isVoiceoverModalOpen = open) }
    }

    fun setTextToSpeechModal(open: Boolean) {
        _uiState.update { it.copy(isTextToSpeechModalOpen = open) }
    }

    fun addCustomAudioClip(name: String, durationSec: Float = 12f) {
        val proj = _uiState.value.currentProject ?: return
        val time = _uiState.value.currentTimeSec
        val newAudio = TimelineClip(
            id = "aud_${System.currentTimeMillis()}",
            name = name,
            startTimeSec = time,
            durationSec = durationSec,
            waveformPoints = listOf(0.2f, 0.5f, 0.8f, 0.9f, 0.6f, 0.7f, 0.85f, 0.4f, 0.9f, 0.7f, 0.5f, 0.3f),
            volume = 0.9f
        )
        val audTrack = proj.tracks.firstOrNull { it.type == TrackType.AUDIO } ?: return
        val updatedTracks = proj.tracks.map { if (it.id == audTrack.id) it.copy(clips = it.clips + newAudio) else it }
        _uiState.update { it.copy(currentProject = proj.copy(tracks = updatedTracks), canUndo = true) }
    }

    fun addVoiceoverClip(durationSec: Float) {
        val proj = _uiState.value.currentProject ?: return
        val time = _uiState.value.currentTimeSec
        val voClip = TimelineClip(
            id = "vo_${System.currentTimeMillis()}",
            name = "Voiceover_${formatShortDuration(time)}.m4a",
            startTimeSec = time,
            durationSec = durationSec.coerceAtLeast(1.5f),
            waveformPoints = listOf(0.1f, 0.4f, 0.7f, 0.95f, 0.8f, 0.6f, 0.85f, 0.9f, 0.7f, 0.5f, 0.3f, 0.1f),
            volume = 1.0f
        )
        val audTrack = proj.tracks.firstOrNull { it.type == TrackType.AUDIO } ?: return
        val updatedTracks = proj.tracks.map { if (it.id == audTrack.id) it.copy(clips = it.clips + voClip) else it }
        _uiState.update { it.copy(currentProject = proj.copy(tracks = updatedTracks), canUndo = true) }
    }

    fun toggleToolPanel(panel: ToolPanelType) {
        _uiState.update {
            it.copy(
                activeToolPanel = if (it.activeToolPanel == panel) ToolPanelType.NONE else panel,
                activeSubToolbar = null
            )
        }
    }

    fun closeToolPanel() {
        _uiState.update { it.copy(activeToolPanel = ToolPanelType.NONE) }
    }

    fun toggleGridOverlay() {
        _uiState.update { it.copy(showGridOverlay = !it.showGridOverlay) }
    }

    fun setAspectRatio(ratio: AspectRatio) {
        val proj = _uiState.value.currentProject ?: return
        val updated = proj.copy(aspectRatio = ratio)
        _uiState.update {
            it.copy(
                currentProject = updated,
                projects = it.projects.map { p -> if (p.id == updated.id) updated else p }
            )
        }
    }

    fun splitClipAtPlayhead() {
        val proj = _uiState.value.currentProject ?: return
        val time = _uiState.value.currentTimeSec
        val vidTrack = proj.tracks.firstOrNull { it.type == TrackType.VIDEO } ?: return
        val clipToSplit = vidTrack.clips.firstOrNull { time > it.startTimeSec && time < it.endTimeSec } ?: return

        val firstDuration = time - clipToSplit.startTimeSec
        val secondDuration = clipToSplit.endTimeSec - time

        val firstClip = clipToSplit.copy(
            id = "${clipToSplit.id}_part1",
            durationSec = firstDuration
        )
        val secondClip = clipToSplit.copy(
            id = "${clipToSplit.id}_part2",
            name = "${clipToSplit.name} (Split)",
            startTimeSec = time,
            durationSec = secondDuration,
            transitionIn = null
        )

        val updatedClips = mutableListOf<TimelineClip>()
        vidTrack.clips.forEach { clip ->
            if (clip.id == clipToSplit.id) {
                updatedClips.add(firstClip)
                updatedClips.add(secondClip)
            } else {
                updatedClips.add(clip)
            }
        }

        val updatedTracks = proj.tracks.map { track ->
            if (track.id == vidTrack.id) track.copy(clips = updatedClips) else track
        }
        val updatedProj = proj.copy(tracks = updatedTracks)

        _uiState.update {
            it.copy(
                currentProject = updatedProj,
                selectedClipId = secondClip.id,
                canUndo = true
            )
        }
    }

    fun deleteSelectedClip() {
        val proj = _uiState.value.currentProject ?: return
        val selId = _uiState.value.selectedClipId ?: return

        val updatedTracks = proj.tracks.map { track ->
            track.copy(clips = track.clips.filter { it.id != selId })
        }
        _uiState.update {
            it.copy(
                currentProject = proj.copy(tracks = updatedTracks),
                selectedClipId = null,
                canUndo = true
            )
        }
    }

    fun duplicateSelectedClip() {
        val selId = _uiState.value.selectedClipId ?: return
        val proj = _uiState.value.currentProject ?: return
        val vidTrack = proj.tracks.firstOrNull { it.type == TrackType.VIDEO } ?: return
        val clip = vidTrack.clips.firstOrNull { it.id == selId } ?: return

        val newClip = clip.copy(
            id = "${clip.id}_copy_${System.currentTimeMillis()}",
            name = "${clip.name} (Copy)",
            startTimeSec = clip.endTimeSec
        )

        val updatedClips = mutableListOf<TimelineClip>()
        var found = false
        for (c in vidTrack.clips) {
            if (!found) {
                updatedClips.add(c)
                if (c.id == selId) {
                    found = true
                    updatedClips.add(newClip)
                }
            } else {
                updatedClips.add(c.copy(startTimeSec = c.startTimeSec + clip.durationSec))
            }
        }

        val updatedTracks = proj.tracks.map { if (it.id == vidTrack.id) it.copy(clips = updatedClips) else it }
        val newDuration = proj.durationSec + clip.durationSec
        _uiState.update {
            it.copy(
                currentProject = proj.copy(tracks = updatedTracks, durationSec = newDuration),
                selectedClipId = newClip.id,
                canUndo = true
            )
        }
    }

    fun freezeSelectedClip() {
        val selId = _uiState.value.selectedClipId ?: return
        val proj = _uiState.value.currentProject ?: return
        val vidTrack = proj.tracks.firstOrNull { it.type == TrackType.VIDEO } ?: return
        val clip = vidTrack.clips.firstOrNull { it.id == selId } ?: return

        val freezeDuration = 3.0f
        val freezeClip = clip.copy(
            id = "${clip.id}_freeze_${System.currentTimeMillis()}",
            name = "${clip.name} [Freeze 3s]",
            startTimeSec = clip.endTimeSec,
            durationSec = freezeDuration,
            isFrozen = true
        )

        val updatedClips = mutableListOf<TimelineClip>()
        for (c in vidTrack.clips) {
            updatedClips.add(c)
            if (c.id == selId) {
                updatedClips.add(freezeClip)
            }
        }

        val updatedTracks = proj.tracks.map { if (it.id == vidTrack.id) it.copy(clips = updatedClips) else it }
        _uiState.update {
            it.copy(
                currentProject = proj.copy(tracks = updatedTracks, durationSec = proj.durationSec + freezeDuration),
                selectedClipId = freezeClip.id,
                canUndo = true
            )
        }
    }

    fun reverseSelectedClip() {
        val selId = _uiState.value.selectedClipId ?: return
        val proj = _uiState.value.currentProject ?: return
        val updatedTracks = proj.tracks.map { track ->
            track.copy(clips = track.clips.map { clip ->
                if (clip.id == selId) clip.copy(isReversed = !clip.isReversed) else clip
            })
        }
        _uiState.update { it.copy(currentProject = proj.copy(tracks = updatedTracks), canUndo = true) }
    }

    fun unlinkAudioFromSelectedClip() {
        val selId = _uiState.value.selectedClipId ?: return
        val proj = _uiState.value.currentProject ?: return
        val vidTrack = proj.tracks.firstOrNull { it.type == TrackType.VIDEO } ?: return
        val clip = vidTrack.clips.firstOrNull { it.id == selId } ?: return

        val extractedAudioClip = TimelineClip(
            id = "extracted_aud_${System.currentTimeMillis()}",
            name = "Audio from ${clip.name}",
            startTimeSec = clip.startTimeSec,
            durationSec = clip.durationSec,
            waveformPoints = listOf(0.4f, 0.7f, 0.9f, 0.6f, 0.3f, 0.8f, 0.95f, 0.5f, 0.4f, 0.7f, 0.6f, 0.4f),
            volume = 1.0f
        )

        val audTrack = proj.tracks.firstOrNull { it.type == TrackType.AUDIO }
        val updatedTracks = proj.tracks.map { track ->
            if (track.id == audTrack?.id) {
                track.copy(clips = track.clips + extractedAudioClip)
            } else track
        }
        _uiState.update { it.copy(currentProject = proj.copy(tracks = updatedTracks), canUndo = true) }
    }

    fun setClipVolume(volume: Float) {
        val selId = _uiState.value.selectedClipId ?: return
        val proj = _uiState.value.currentProject ?: return
        val updatedTracks = proj.tracks.map { track ->
            track.copy(clips = track.clips.map { clip ->
                if (clip.id == selId) clip.copy(volume = volume) else clip
            })
        }
        _uiState.update { it.copy(currentProject = proj.copy(tracks = updatedTracks)) }
    }

    fun setClipSpeed(speed: Float) {
        val selId = _uiState.value.selectedClipId ?: return
        val proj = _uiState.value.currentProject ?: return
        val updatedTracks = proj.tracks.map { track ->
            track.copy(clips = track.clips.map { clip ->
                if (clip.id == selId) clip.copy(speed = speed) else clip
            })
        }
        _uiState.update { it.copy(currentProject = proj.copy(tracks = updatedTracks)) }
    }

    fun setClipOpacity(opacity: Float) {
        val selId = _uiState.value.selectedClipId ?: return
        val proj = _uiState.value.currentProject ?: return
        val updatedTracks = proj.tracks.map { track ->
            track.copy(clips = track.clips.map { clip ->
                if (clip.id == selId) clip.copy(opacity = opacity) else clip
            })
        }
        _uiState.update { it.copy(currentProject = proj.copy(tracks = updatedTracks)) }
    }

    fun toggleNoiseReduction() {
        val selId = _uiState.value.selectedClipId ?: return
        val proj = _uiState.value.currentProject ?: return
        val updatedTracks = proj.tracks.map { track ->
            track.copy(clips = track.clips.map { clip ->
                if (clip.id == selId) clip.copy(noiseReduced = !clip.noiseReduced) else clip
            })
        }
        _uiState.update { it.copy(currentProject = proj.copy(tracks = updatedTracks)) }
    }

    fun toggleVoiceIsolation() {
        val selId = _uiState.value.selectedClipId ?: return
        val proj = _uiState.value.currentProject ?: return
        val updatedTracks = proj.tracks.map { track ->
            track.copy(clips = track.clips.map { clip ->
                if (clip.id == selId) clip.copy(voiceIsolated = !clip.voiceIsolated) else clip
            })
        }
        _uiState.update { it.copy(currentProject = proj.copy(tracks = updatedTracks)) }
    }

    fun toggleRemoveBackground() {
        val selId = _uiState.value.selectedClipId ?: return
        val proj = _uiState.value.currentProject ?: return
        val updatedTracks = proj.tracks.map { track ->
            track.copy(clips = track.clips.map { clip ->
                if (clip.id == selId) clip.copy(backgroundRemoved = !clip.backgroundRemoved) else clip
            })
        }
        _uiState.update { it.copy(currentProject = proj.copy(tracks = updatedTracks)) }
    }

    fun setClipMask(mask: String?) {
        val selId = _uiState.value.selectedClipId ?: return
        val proj = _uiState.value.currentProject ?: return
        val updatedTracks = proj.tracks.map { track ->
            track.copy(clips = track.clips.map { clip ->
                if (clip.id == selId) clip.copy(activeMask = mask) else clip
            })
        }
        _uiState.update { it.copy(currentProject = proj.copy(tracks = updatedTracks)) }
    }

    fun setClipAnimation(anim: String?) {
        val selId = _uiState.value.selectedClipId ?: return
        val proj = _uiState.value.currentProject ?: return
        val updatedTracks = proj.tracks.map { track ->
            track.copy(clips = track.clips.map { clip ->
                if (clip.id == selId) clip.copy(activeAnimation = anim) else clip
            })
        }
        _uiState.update { it.copy(currentProject = proj.copy(tracks = updatedTracks)) }
    }

    fun addAudioTrackPrompt() {
        val proj = _uiState.value.currentProject ?: return
        val time = _uiState.value.currentTimeSec
        val newAudio = TimelineClip(
            id = "bgm_${System.currentTimeMillis()}",
            name = "Cinematic Ambient Track 48k.wav",
            startTimeSec = time,
            durationSec = 15.0f,
            waveformPoints = listOf(0.3f, 0.6f, 0.8f, 0.5f, 0.4f, 0.9f, 0.7f, 0.3f, 0.6f, 0.8f),
            volume = 0.85f
        )
        val audTrack = proj.tracks.firstOrNull { it.type == TrackType.AUDIO } ?: return
        val updatedTracks = proj.tracks.map { if (it.id == audTrack.id) it.copy(clips = it.clips + newAudio) else it }
        _uiState.update { it.copy(currentProject = proj.copy(tracks = updatedTracks), canUndo = true) }
    }

    fun addTextTrackPrompt() {
        val proj = _uiState.value.currentProject ?: return
        val time = _uiState.value.currentTimeSec
        val newText = TimelineClip(
            id = "txt_${System.currentTimeMillis()}",
            name = "Default Title",
            startTimeSec = time,
            durationSec = 5.0f,
            textOverlay = "NEW TITLE TEXT"
        )
        val txtTrack = proj.tracks.firstOrNull { it.type == TrackType.TEXT } ?: return
        val updatedTracks = proj.tracks.map { if (it.id == txtTrack.id) it.copy(clips = it.clips + newText) else it }
        _uiState.update { it.copy(currentProject = proj.copy(tracks = updatedTracks), canUndo = true) }
    }

    fun addNewMediaClipToEnd() {
        val proj = _uiState.value.currentProject ?: return
        val vidTrack = proj.tracks.firstOrNull { it.type == TrackType.VIDEO } ?: return
        val lastClipEnd = vidTrack.clips.maxOfOrNull { it.endTimeSec } ?: 0f

        val newClip = TimelineClip(
            id = "clip_new_${System.currentTimeMillis()}",
            name = "05_Tokyo_Street_Rain.mov",
            startTimeSec = lastClipEnd,
            durationSec = 8.0f,
            thumbnailRes = R.drawable.thumb_city,
            transitionIn = "Cross Dissolve"
        )

        val updatedClips = vidTrack.clips + newClip
        val updatedTracks = proj.tracks.map { if (it.id == vidTrack.id) it.copy(clips = updatedClips) else it }
        _uiState.update {
            it.copy(
                currentProject = proj.copy(tracks = updatedTracks, durationSec = lastClipEnd + 8.0f),
                selectedClipId = newClip.id,
                canUndo = true
            )
        }
    }

    fun updateColorGrade(update: (ColorGradeSettings) -> ColorGradeSettings) {
        _uiState.update {
            it.copy(colorGrade = update(it.colorGrade))
        }
    }

    fun setEffect(effectName: String) {
        _uiState.update { it.copy(activeEffect = effectName) }
    }

    fun setTransition(transitionName: String) {
        _uiState.update { it.copy(activeTransition = transitionName) }
    }

    fun toggleMediaSelection(id: String) {
        _uiState.update {
            val next = it.selectedMediaIds.toMutableSet()
            if (next.contains(id)) next.remove(id) else next.add(id)
            it.copy(selectedMediaIds = next)
        }
    }

    fun clearMediaSelection() {
        _uiState.update { it.copy(selectedMediaIds = emptySet()) }
    }

    fun addSelectedMediaToProject() {
        val selected = _uiState.value.selectedMediaIds
        if (selected.isNotEmpty()) {
            val proj = _uiState.value.currentProject
            if (proj != null) {
                val vidTrack = proj.tracks.firstOrNull { it.type == TrackType.VIDEO }
                if (vidTrack != null) {
                    var currentEnd = vidTrack.clips.maxOfOrNull { it.endTimeSec } ?: 0f
                    val newClips = mutableListOf<TimelineClip>()
                    _uiState.value.mediaItems.filter { it.id in selected }.forEach { item ->
                        val dur = if (item.durationSec > 0f) item.durationSec else 5.0f
                        newClips.add(
                            TimelineClip(
                                id = "clip_med_${System.currentTimeMillis()}_${item.id}",
                                name = item.title,
                                startTimeSec = currentEnd,
                                durationSec = dur,
                                thumbnailRes = item.thumbnailRes ?: R.drawable.thumb_city,
                                contentUri = item.contentUri,
                                transitionIn = "Cross Dissolve"
                            )
                        )
                        currentEnd += dur
                    }
                    val updatedTracks = proj.tracks.map { if (it.id == vidTrack.id) it.copy(clips = it.clips + newClips) else it }
                    _uiState.update { it.copy(currentProject = proj.copy(tracks = updatedTracks, durationSec = currentEnd), canUndo = true) }
                }
            }
            clearMediaSelection()
            navigateTo(ScreenDestination.EDITOR)
        }
    }

    fun setExportResolution(resolution: Resolution) {
        _uiState.update { it.copy(exportConfig = it.exportConfig.copy(resolution = resolution)) }
    }

    fun setExportFrameRate(fps: Int) {
        _uiState.update { it.copy(exportConfig = it.exportConfig.copy(frameRate = fps)) }
    }

    fun setExportQuality(quality: String) {
        _uiState.update { it.copy(exportConfig = it.exportConfig.copy(quality = quality)) }
    }

    fun setExportFormat(format: String) {
        _uiState.update { it.copy(exportConfig = it.exportConfig.copy(format = format)) }
    }

    fun startExportSimulation() {
        exportJob?.cancel()
        _uiState.update {
            it.copy(
                exportSimulation = ExportSimulationState(
                    isExporting = true,
                    progress = 0f,
                    currentFrame = 0,
                    totalFrames = ((it.currentProject?.durationSec ?: 30f) * it.exportConfig.frameRate).toInt(),
                    renderFps = 62,
                    timeRemainingSec = 28,
                    isCompleted = false
                )
            )
        }

        exportJob = viewModelScope.launch {
            val total = _uiState.value.exportSimulation.totalFrames
            for (step in 1..100) {
                delay(80)
                val pct = step / 100f
                val frame = (total * pct).toInt()
                val rem = ((1f - pct) * 28).toInt().coerceAtLeast(0)
                _uiState.update {
                    it.copy(
                        exportSimulation = it.exportSimulation.copy(
                            progress = pct,
                            currentFrame = frame,
                            timeRemainingSec = rem,
                            isCompleted = step == 100
                        )
                    )
                }
            }
        }
    }

    fun cancelExportSimulation() {
        exportJob?.cancel()
        exportJob = null
        _uiState.update {
            it.copy(exportSimulation = ExportSimulationState(isExporting = false))
        }
    }

    fun dismissExportCompleted() {
        _uiState.update {
            it.copy(exportSimulation = ExportSimulationState(isExporting = false, isCompleted = false))
        }
        navigateTo(ScreenDestination.HOME)
    }

    fun toggleMagneticSnap() {
        _uiState.update { it.copy(magneticSnap = !it.magneticSnap) }
    }

    fun toggleRippleEdit() {
        _uiState.update { it.copy(rippleEdit = !it.rippleEdit) }
    }

    fun toggleAudioScrubbing() {
        _uiState.update { it.copy(audioScrubbing = !it.audioScrubbing) }
    }

    override fun onCleared() {
        super.onCleared()
        playbackJob?.cancel()
        exportJob?.cancel()
    }
}
