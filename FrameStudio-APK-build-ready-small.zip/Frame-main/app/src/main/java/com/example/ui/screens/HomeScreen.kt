package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.*
import com.example.ui.theme.*
import com.example.util.ExtractedMediaInfo
import com.example.util.MediaUtils
import com.example.viewmodel.ScreenDestination

@Composable
fun HomeScreen(
    projects: List<Project>,
    onOpenProject: (Project) -> Unit,
    onCreateNewProject: (String, AspectRatio, Int, Resolution) -> Unit,
    onCreateProjectFromGallery: (String, AspectRatio, Int, Resolution, List<ExtractedMediaInfo>) -> Unit = { _, _, _, _, _ -> },
    onNavigateTab: (ScreenDestination) -> Unit,
    modifier: Modifier = Modifier
) {
    var showNewProjectDialog by remember { mutableStateOf(false) }
    val context = LocalContext.current

    val directGalleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris ->
        if (uris.isNotEmpty()) {
            val mediaList = MediaUtils.extractMultiple(context, uris)
            onCreateProjectFromGallery("My Reel", AspectRatio.VERTICAL_9_16, 30, Resolution.FHD_1080P, mediaList)
        }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(BgPureDark),
        containerColor = BgPureDark,
        topBar = {
            HomeTopBar(
                onNewProjectClick = { showNewProjectDialog = true },
                onPickGalleryDirect = {
                    directGalleryLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                    )
                }
            )
        },
        bottomBar = {
            AppBottomNavBar(
                activeDestination = ScreenDestination.HOME,
                onSelectTab = onNavigateTab
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            // Storage & stats banner
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
                    .background(PanelDark, RoundedCornerShape(6.dp))
                    .border(1.dp, PanelBorder, RoundedCornerShape(6.dp))
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(AccentCoolBlue, CircleShape)
                    )
                    Text(
                        text = "INTERNAL STORAGE",
                        style = TimecodeStyleSmall,
                        color = TextSecondary
                    )
                }
                Text(
                    text = "${projects.size} PROJECTS • 4.2 GB FREE",
                    fontFamily = MonoTimecodeFont,
                    fontSize = 10.sp,
                    color = TextPrimary
                )
            }

            Text(
                text = "RECENT PROJECTS",
                style = TimecodeStyleSmall,
                color = TextMuted,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(bottom = 12.dp, top = 4.dp)
            )

            // Grid of project cards
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("projects_grid")
            ) {
                items(projects, key = { it.id }) { project ->
                    ProjectCard(
                        project = project,
                        onClick = { onOpenProject(project) }
                    )
                }
            }
        }

        if (showNewProjectDialog) {
            NewProjectModal(
                onDismiss = { showNewProjectDialog = false },
                onCreate = { name, ratio, fps, res ->
                    showNewProjectDialog = false
                    onCreateNewProject(name, ratio, fps, res)
                },
                onCreateFromGallery = { name, ratio, fps, res, mediaList ->
                    showNewProjectDialog = false
                    onCreateProjectFromGallery(name, ratio, fps, res, mediaList)
                }
            )
        }
    }
}

@Composable
fun HomeTopBar(
    onNewProjectClick: () -> Unit,
    onPickGalleryDirect: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = "FrameStudio",
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Light,
                fontSize = 20.sp,
                letterSpacing = (-0.5).sp,
                color = TextWhite
            )
            Text(
                text = "MOBILE SUITE v2.4",
                style = TimecodeStyleSmall,
                color = TextMuted
            )
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = onPickGalleryDirect,
                shape = RoundedCornerShape(4.dp),
                border = BorderStroke(1.dp, PanelBorderActive),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = TextWhite
                ),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 7.dp),
                modifier = Modifier.testTag("import_gallery_top_button")
            ) {
                Icon(
                    imageVector = Icons.Outlined.PhotoLibrary,
                    contentDescription = "Gallery",
                    tint = AccentCoolBlue,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Gallery",
                    fontFamily = FontFamily.SansSerif,
                    fontSize = 12.sp,
                    color = TextWhite
                )
            }

            Button(
                onClick = onNewProjectClick,
                shape = RoundedCornerShape(4.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = AccentCoolBlue,
                    contentColor = BgPureDark
                ),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 7.dp),
                modifier = Modifier.testTag("new_project_button")
            ) {
                Text(
                    text = "+ New Project",
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Medium,
                    fontSize = 12.sp,
                    color = BgPureDark
                )
            }
        }
    }
}

@Composable
fun ProjectCard(
    project: Project,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .border(1.dp, PanelBorder, RoundedCornerShape(6.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(6.dp),
        colors = CardDefaults.cardColors(containerColor = PanelDark)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Thumbnail container
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .background(BgPureDark)
            ) {
                val firstContentUri = project.tracks.firstOrNull { it.type == TrackType.VIDEO }
                    ?.clips?.firstOrNull()?.contentUri
                if (!firstContentUri.isNullOrBlank()) {
                    AsyncImage(
                        model = firstContentUri,
                        contentDescription = project.name,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Image(
                        painter = painterResource(id = project.thumbnailRes),
                        contentDescription = project.name,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }

                // Aspect ratio badge top-left
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(6.dp)
                        .background(BgPureDark.copy(alpha = 0.8f), RoundedCornerShape(3.dp))
                        .border(0.5.dp, PanelBorder, RoundedCornerShape(3.dp))
                        .padding(horizontal = 5.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = project.aspectRatio.label,
                        fontFamily = MonoTimecodeFont,
                        fontSize = 9.sp,
                        color = TextPrimary
                    )
                }

                // Duration badge bottom-right
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(6.dp)
                        .background(BgPureDark.copy(alpha = 0.85f), RoundedCornerShape(3.dp))
                        .border(0.5.dp, PanelBorder, RoundedCornerShape(3.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = formatShortDuration(project.durationSec),
                        fontFamily = MonoTimecodeFont,
                        fontSize = 10.sp,
                        color = TextWhite
                    )
                }
            }

            // Info rows
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp)
            ) {
                Text(
                    text = project.name,
                    style = FrameStudioTypography.titleMedium,
                    color = TextPrimary,
                    maxLines = 1
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = project.lastEdited,
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                    Text(
                        text = "${project.resolution.label.take(4)} • ${project.fps}fps",
                        fontFamily = MonoTimecodeFont,
                        fontSize = 10.sp,
                        color = AccentCoolBlue
                    )
                }
            }
        }
    }
}

@Composable
fun AppBottomNavBar(
    activeDestination: ScreenDestination,
    onSelectTab: (ScreenDestination) -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding(),
        color = PanelDark,
        tonalElevation = 0.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, PanelBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val tabs = listOf(
                Triple(ScreenDestination.HOME, "Projects", Icons.Outlined.Folder),
                Triple(ScreenDestination.TEMPLATES, "Templates", Icons.Outlined.Dashboard),
                Triple(ScreenDestination.MEDIA_LIBRARY, "Media", Icons.Outlined.PhotoLibrary),
                Triple(ScreenDestination.SETTINGS, "Settings", Icons.Outlined.Tune)
            )

            tabs.forEach { (dest, label, icon) ->
                val isSelected = activeDestination == dest
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .clickable { onSelectTab(dest) }
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = if (isSelected) AccentCoolBlue else TextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = label,
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 10.sp,
                        fontWeight = if (isSelected) FontWeight.Medium else FontWeight.Normal,
                        color = if (isSelected) AccentCoolBlue else TextSecondary
                    )
                }
            }
        }
    }
}

data class ProjectRatioOption(
    val ratio: AspectRatio,
    val title: String,
    val platformName: String,
    val dimensionsLabel: String,
    val iconWidthDp: Int,
    val iconHeightDp: Int,
    val isHot: Boolean = false
)

@Composable
fun NewProjectModal(
    onDismiss: () -> Unit,
    onCreate: (String, AspectRatio, Int, Resolution) -> Unit,
    onCreateFromGallery: (String, AspectRatio, Int, Resolution, List<ExtractedMediaInfo>) -> Unit = { _, _, _, _, _ -> }
) {
    var name by remember { mutableStateOf("New Reel 01") }
    var selectedRatio by remember { mutableStateOf(AspectRatio.VERTICAL_9_16) }
    var selectedFps by remember { mutableIntStateOf(30) }
    var selectedResolution by remember { mutableStateOf(Resolution.FHD_1080P) }
    val context = LocalContext.current

    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris ->
        if (uris.isNotEmpty()) {
            val mediaList = MediaUtils.extractMultiple(context, uris)
            onCreateFromGallery(name, selectedRatio, selectedFps, selectedResolution, mediaList)
        }
    }

    val ratioOptions = listOf(
        ProjectRatioOption(
            ratio = AspectRatio.VERTICAL_9_16,
            title = "9:16",
            platformName = "Reels / TikTok",
            dimensionsLabel = "1080 × 1920 (FHD)",
            iconWidthDp = 13,
            iconHeightDp = 23,
            isHot = true
        ),
        ProjectRatioOption(
            ratio = AspectRatio.CINEMA_16_9,
            title = "16:9",
            platformName = "YouTube / Web",
            dimensionsLabel = "1920 × 1080 (FHD)",
            iconWidthDp = 23,
            iconHeightDp = 13
        ),
        ProjectRatioOption(
            ratio = AspectRatio.SQUARE_1_1,
            title = "1:1",
            platformName = "Instagram Post",
            dimensionsLabel = "1080 × 1080 (Square)",
            iconWidthDp = 16,
            iconHeightDp = 16
        ),
        ProjectRatioOption(
            ratio = AspectRatio.PORTRAIT_4_5,
            title = "4:5",
            platformName = "Social Feed",
            dimensionsLabel = "1080 × 1350 (Vertical)",
            iconWidthDp = 15,
            iconHeightDp = 19
        ),
        ProjectRatioOption(
            ratio = AspectRatio.ANAMORPHIC_239,
            title = "2.35:1",
            platformName = "Cinema Film",
            dimensionsLabel = "2560 × 1080 (Ultra)",
            iconWidthDp = 26,
            iconHeightDp = 11
        ),
        ProjectRatioOption(
            ratio = AspectRatio.STANDARD_4_3,
            title = "4:3",
            platformName = "Classic Retro",
            dimensionsLabel = "1440 × 1080 (Standard)",
            iconWidthDp = 18,
            iconHeightDp = 14
        )
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = PanelDark,
        shape = RoundedCornerShape(10.dp),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "CREATE NEW PROJECT",
                    style = TimecodeStyleSmall,
                    color = AccentCoolBlue,
                    letterSpacing = 1.2.sp
                )
                IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                    Icon(imageVector = Icons.Outlined.Close, contentDescription = "Close", tint = TextSecondary, modifier = Modifier.size(16.dp))
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // 1. Interactive Dynamic Viewfinder Monitor Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(96.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(BgPureDark)
                        .border(1.dp, PanelBorderActive, RoundedCornerShape(6.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    // Scaled viewfinder canvas adapting to selected ratio
                    Box(
                        modifier = Modifier
                            .fillMaxHeight(0.82f)
                            .aspectRatio(selectedRatio.ratio, matchHeightConstraintsFirst = true)
                            .clip(RoundedCornerShape(3.dp))
                            .background(PanelDarkElevated)
                            .border(1.2.dp, AccentCoolBlue, RoundedCornerShape(3.dp))
                    ) {
                        // Subtle framing grid lines
                        Column(modifier = Modifier.fillMaxSize()) {
                            Spacer(modifier = Modifier.weight(1f))
                            HorizontalDivider(thickness = 0.5.dp, color = AccentCoolBlue.copy(alpha = 0.2f))
                            Spacer(modifier = Modifier.weight(1f))
                            HorizontalDivider(thickness = 0.5.dp, color = AccentCoolBlue.copy(alpha = 0.2f))
                            Spacer(modifier = Modifier.weight(1f))
                        }
                        Row(modifier = Modifier.fillMaxSize()) {
                            Spacer(modifier = Modifier.weight(1f))
                            VerticalDivider(thickness = 0.5.dp, color = AccentCoolBlue.copy(alpha = 0.2f))
                            Spacer(modifier = Modifier.weight(1f))
                            VerticalDivider(thickness = 0.5.dp, color = AccentCoolBlue.copy(alpha = 0.2f))
                            Spacer(modifier = Modifier.weight(1f))
                        }
                        Icon(
                            imageVector = Icons.Outlined.Add,
                            contentDescription = null,
                            tint = AccentCoolBlue.copy(alpha = 0.6f),
                            modifier = Modifier
                                .size(10.dp)
                                .align(Alignment.Center)
                        )
                    }

                    // Top overlay labels
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.TopCenter)
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("CANVAS VIEWPORT", style = TimecodeStyleSmall, fontSize = 7.5.sp, color = AccentCoolBlue)
                        Text("RATIO ${selectedRatio.label}", fontFamily = MonoTimecodeFont, fontSize = 8.5.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                    }

                    // Bottom overlay labels
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomCenter)
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        val currentOpt = ratioOptions.firstOrNull { it.ratio == selectedRatio }
                        Text(currentOpt?.dimensionsLabel ?: "1080 × 1920", fontFamily = MonoTimecodeFont, fontSize = 8.sp, color = TextSecondary)
                        Text(currentOpt?.platformName ?: "Vertical", fontFamily = FontFamily.SansSerif, fontSize = 8.sp, color = AccentCoolBlue)
                    }
                }

                // 2. Aspect Ratio Selector (2 Rows of 3 Cards with proportional wireframe boxes)
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("ASPECT RATIO", style = TimecodeStyleSmall, color = TextSecondary)

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        // Row 1: Top 3 Popular Formats
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            ratioOptions.take(3).forEach { opt ->
                                AspectRatioCard(
                                    option = opt,
                                    isSelected = selectedRatio == opt.ratio,
                                    onClick = { selectedRatio = opt.ratio },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        // Row 2: Secondary Formats
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            ratioOptions.drop(3).take(3).forEach { opt ->
                                AspectRatioCard(
                                    option = opt,
                                    isSelected = selectedRatio == opt.ratio,
                                    onClick = { selectedRatio = opt.ratio },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }

                // 3. Project Name & Quick Preset Chips
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Project Name", style = TimecodeStyleSmall) },
                        textStyle = TimecodeStyleSmall.copy(color = TextWhite),
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AccentCoolBlue,
                            unfocusedBorderColor = PanelBorder,
                            focusedLabelColor = AccentCoolBlue,
                            unfocusedLabelColor = TextSecondary,
                            cursorColor = AccentCoolBlue,
                            focusedContainerColor = PanelDarkElevated,
                            unfocusedContainerColor = PanelDarkElevated
                        ),
                        singleLine = true
                    )

                    // Quick name preset suggestions
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("Reel Master", "Cinematic Film", "Vlog Ep. 01", "Shorts Edit", "Quick Cut").forEach { suggestion ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(PanelDarkElevated)
                                    .border(0.5.dp, PanelBorder, RoundedCornerShape(3.dp))
                                    .clickable { name = suggestion }
                                    .padding(horizontal = 6.dp, vertical = 3.dp)
                            ) {
                                Text(suggestion, fontFamily = MonoTimecodeFont, fontSize = 8.sp, color = TextSecondary)
                            }
                        }
                    }
                }

                // 4. Frame Rate & Resolution Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Frame Rate
                    Column(modifier = Modifier.weight(1.2f)) {
                        Text("FRAME RATE", style = TimecodeStyleSmall, color = TextSecondary)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf(24, 30, 60).forEach { fps ->
                                val isSel = selectedFps == fps
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                                        .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                                        .clickable { selectedFps = fps }
                                        .padding(vertical = 6.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "${fps}fps",
                                        style = TimecodeStyleSmall,
                                        fontSize = 9.sp,
                                        color = if (isSel) TextWhite else TextSecondary
                                    )
                                }
                            }
                        }
                    }

                    // Resolution Selector (720p, 1080p, 4K)
                    Column(modifier = Modifier.weight(1.2f)) {
                        Text("RESOLUTION", style = TimecodeStyleSmall, color = TextSecondary)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf(
                                Pair(Resolution.HD_720P, "720p"),
                                Pair(Resolution.FHD_1080P, "1080p"),
                                Pair(Resolution.UHD_4K, "4K")
                            ).forEach { (res, label) ->
                                val isSel = selectedResolution == res
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                                        .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                                        .clickable { selectedResolution = res }
                                        .padding(vertical = 6.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = label,
                                        style = TimecodeStyleSmall,
                                        fontSize = 9.sp,
                                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSel) TextWhite else TextSecondary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        galleryLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                        )
                    },
                    shape = RoundedCornerShape(4.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AccentCoolBlue,
                        contentColor = BgPureDark
                    ),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("select_gallery_videos_button")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.PhotoLibrary,
                        contentDescription = null,
                        tint = BgPureDark,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Select Videos from Gallery",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = BgPureDark
                    )
                }

                OutlinedButton(
                    onClick = { onCreate(name, selectedRatio, selectedFps, selectedResolution) },
                    shape = RoundedCornerShape(4.dp),
                    border = BorderStroke(1.dp, PanelBorderActive),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = TextSecondary
                    ),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(36.dp)
                        .testTag("start_sample_timeline_button")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Movie,
                        contentDescription = null,
                        tint = TextSecondary,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Or start with Sample Video",
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        }
    )
}

@Composable
fun AspectRatioCard(
    option: ProjectRatioOption,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (isSelected) AccentCoolBlueSubtle else PanelDarkElevated)
            .border(
                width = if (isSelected) 1.5.dp else 1.dp,
                color = if (isSelected) AccentCoolBlue else PanelBorder,
                shape = RoundedCornerShape(6.dp)
            )
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp, horizontal = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // Visual wireframe box showing actual aspect ratio proportion
            Box(
                modifier = Modifier
                    .size(width = 30.dp, height = 26.dp),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(width = option.iconWidthDp.dp, height = option.iconHeightDp.dp)
                        .background(if (isSelected) AccentCoolBlue.copy(alpha = 0.25f) else Color.Transparent)
                        .border(
                            1.dp,
                            if (isSelected) AccentCoolBlue else TextMuted,
                            RoundedCornerShape(2.dp)
                        )
                )
            }

            // Ratio title (e.g. 9:16)
            Text(
                text = option.title,
                fontFamily = MonoTimecodeFont,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = if (isSelected) TextWhite else TextPrimary
            )

            // Platform tag (e.g. Reels, YouTube, Post)
            Text(
                text = option.platformName.substringBefore(" /"),
                fontFamily = FontFamily.SansSerif,
                fontSize = 7.5.sp,
                color = if (isSelected) AccentCoolBlue else TextSecondary,
                maxLines = 1
            )
        }

        // HOT badge for 9:16 Reels/TikTok
        if (option.isHot) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = (-3).dp, y = 3.dp)
                    .background(AccentCoolBlue, RoundedCornerShape(2.dp))
                    .padding(horizontal = 3.dp, vertical = 0.5.dp)
            ) {
                Text("HOT", fontSize = 6.sp, fontWeight = FontWeight.Bold, color = BgPureDark)
            }
        }
    }
}
