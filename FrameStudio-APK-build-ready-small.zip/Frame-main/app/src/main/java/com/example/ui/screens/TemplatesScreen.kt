package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.TemplateItem
import com.example.ui.theme.*
import com.example.viewmodel.ScreenDestination

@Composable
fun TemplatesScreen(
    templates: List<TemplateItem>,
    onSelectTemplate: (TemplateItem) -> Unit,
    onBack: () -> Unit,
    onNavigateTab: (ScreenDestination) -> Unit,
    modifier: Modifier = Modifier
) {
    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(BgPureDark),
        containerColor = BgPureDark,
        topBar = {
            TemplatesTopBar(onBack = onBack)
        },
        bottomBar = {
            AppBottomNavBar(
                activeDestination = ScreenDestination.TEMPLATES,
                onSelectTab = onNavigateTab
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text(
                    text = "CURATED ARCHITECTURE & CINEMA PRESETS",
                    style = TimecodeStyleSmall,
                    color = TextMuted,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(top = 4.dp, bottom = 2.dp)
                )
            }

            items(templates, key = { it.id }) { template ->
                TemplateCard(
                    template = template,
                    onUse = { onSelectTemplate(template) }
                )
            }

            item {
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}

@Composable
fun TemplatesTopBar(onBack: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.padding(start = 6.dp)) {
            Text(
                text = "TEMPLATES",
                style = TimecodeStyleSmall,
                color = AccentCoolBlue,
                letterSpacing = 1.5.sp
            )
            Text(
                text = "Cinematic Aspect Ratios & Timing",
                fontFamily = FontFamily.SansSerif,
                fontSize = 11.sp,
                color = TextSecondary
            )
        }

        IconButton(onClick = { }) {
            Icon(
                imageVector = Icons.Outlined.Search,
                contentDescription = "Search",
                tint = TextSecondary,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
fun TemplateCard(
    template: TemplateItem,
    onUse: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .border(1.dp, PanelBorder, RoundedCornerShape(6.dp)),
        shape = RoundedCornerShape(6.dp),
        colors = CardDefaults.cardColors(containerColor = PanelDark)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 8f)
                    .background(BgPureDark)
            ) {
                Image(
                    painter = painterResource(id = template.thumbnailRes),
                    contentDescription = template.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )

                // Aspect ratio badge
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp)
                        .background(BgPureDark.copy(alpha = 0.8f), RoundedCornerShape(3.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = template.aspectRatio.label,
                        fontFamily = MonoTimecodeFont,
                        fontSize = 9.sp,
                        color = TextWhite
                    )
                }

                // Placeholders badge
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(8.dp)
                        .background(BgPureDark.copy(alpha = 0.85f), RoundedCornerShape(3.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "${template.clipCount} CLIPS • ${template.durationSec.toInt()}s",
                        fontFamily = MonoTimecodeFont,
                        fontSize = 9.sp,
                        color = AccentCoolBlue
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = template.title,
                            style = FrameStudioTypography.titleMedium,
                            color = TextWhite
                        )
                        Text(
                            text = template.category,
                            style = TimecodeStyleSmall,
                            color = TextSecondary
                        )
                    }

                    Button(
                        onClick = onUse,
                        shape = RoundedCornerShape(4.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AccentCoolBlue,
                            contentColor = BgPureDark
                        ),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Text("Use Template", fontSize = 11.sp, fontWeight = FontWeight.Medium, color = BgPureDark)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = template.description,
                    style = FrameStudioTypography.bodyMedium,
                    color = TextSecondary
                )
            }
        }
    }
}
