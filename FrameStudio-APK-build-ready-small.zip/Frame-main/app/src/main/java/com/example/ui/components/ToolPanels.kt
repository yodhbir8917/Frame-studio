package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*

@Composable
fun ToolPanelContainer(
    panelType: ToolPanelType,
    colorGrade: ColorGradeSettings,
    activeEffect: String,
    activeTransition: String,
    onUpdateColor: ((ColorGradeSettings) -> ColorGradeSettings) -> Unit,
    onSelectEffect: (String) -> Unit,
    onSelectTransition: (String) -> Unit,
    onSetSpeed: (Float) -> Unit,
    onSetVolume: (Float) -> Unit,
    onSetOpacity: (Float) -> Unit,
    onSetMask: (String?) -> Unit,
    onSetAnimation: (String?) -> Unit,
    onClose: () -> Unit,
    onSplit: () -> Unit = {},
    onDuplicate: () -> Unit = {},
    onDelete: () -> Unit = {},
    onFreeze: () -> Unit = {},
    onReverse: () -> Unit = {},
    onReplace: () -> Unit = {},
    onAddSticker: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    if (panelType == ToolPanelType.NONE) return

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(PanelDark)
            .border(width = 1.dp, color = PanelBorder)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        // Panel Header with close button
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = panelType.label.uppercase(),
                style = TimecodeStyleSmall,
                color = AccentCoolBlue,
                letterSpacing = 1.5.sp
            )
            IconButton(
                onClick = onClose,
                modifier = Modifier.size(24.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.Close,
                    contentDescription = "Close",
                    tint = TextSecondary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        when (panelType) {
            ToolPanelType.SPEED -> SpeedControlPanel(onSpeedChange = onSetSpeed)
            ToolPanelType.VOLUME -> VolumeControlPanel(onVolumeChange = onSetVolume)
            ToolPanelType.OPACITY -> OpacityControlPanel(onOpacityChange = onSetOpacity)
            ToolPanelType.ANIMATIONS -> AnimationsPanel(onSelectAnimation = onSetAnimation)
            ToolPanelType.MASK -> MaskControlPanel(onSelectMask = onSetMask)
            ToolPanelType.CROP -> CropControlPanel()
            ToolPanelType.TRANSFORM -> TransformControlPanel()
            ToolPanelType.BEATS -> BeatsControlPanel()
            ToolPanelType.RELIGHT -> RelightPanel()
            ToolPanelType.CAMERA_TRACKING -> CameraTrackingPanel()
            ToolPanelType.ENHANCE_VOICE -> EnhanceVoicePanel()
            ToolPanelType.REDUCE_NOISE -> NoiseReductionPanel()
            ToolPanelType.ISOLATE_VOICE -> VoiceIsolationPanel()
            ToolPanelType.EXTRACT_AUDIO, ToolPanelType.UNLINK -> UnlinkAudioPanel()
            ToolPanelType.REMOVE_BG -> RemoveBackgroundPanel()
            ToolPanelType.STABILIZE -> StabilizePanel()
            ToolPanelType.AUDIO_EFFECTS -> AudioEffectsPanel()
            ToolPanelType.AUTO_REFRAME -> AutoReframePanel()
            ToolPanelType.MOTION_BLUR -> MotionBlurPanel()
            ToolPanelType.RETOUCH -> RetouchPanel()
            ToolPanelType.VIDEO_QUALITY -> VideoQualityPanel()
            ToolPanelType.COLOR, ToolPanelType.ADJUST -> ColorGradePanel(settings = colorGrade, onUpdate = onUpdateColor)
            ToolPanelType.FILTERS -> FiltersPanel(settings = colorGrade, onUpdate = onUpdateColor)
            ToolPanelType.EFFECTS -> EffectsPanel(activeEffect = activeEffect, onSelectEffect = onSelectEffect)
            ToolPanelType.TRANSITIONS -> TransitionsPanel(activeTransition = activeTransition, onSelectTransition = onSelectTransition)
            ToolPanelType.AUDIO -> AudioControlPanel()
            ToolPanelType.TEXT -> TextEditPanel()
            ToolPanelType.CAPTIONS -> CaptionsPanel()
            ToolPanelType.ASPECT_RATIO -> AspectRatioPanel()
            ToolPanelType.BACKGROUND -> CanvasBackgroundPanel()
            ToolPanelType.STICKERS -> StickersPanel(onAddSticker = onAddSticker)
            ToolPanelType.OVERLAY -> OverlayPipPanel()
            ToolPanelType.FREEZE -> FreezeControlPanel(onFreeze = onFreeze)
            ToolPanelType.REVERSE -> ReverseControlPanel(onReverse = onReverse)
            ToolPanelType.SPLIT -> SplitControlPanel(onSplit = onSplit)
            ToolPanelType.DUPLICATE -> DuplicateControlPanel(onDuplicate = onDuplicate)
            ToolPanelType.DELETE -> DeleteControlPanel(onDelete = onDelete)
            ToolPanelType.REPLACE -> ReplaceControlPanel(onReplace = onReplace)
            ToolPanelType.EDIT -> EditControlPanel(onSplit = onSplit)
            else -> {
                Text(
                    text = "${panelType.label} controls ready for active sequence / clip",
                    style = FrameStudioTypography.bodyMedium,
                    color = TextSecondary
                )
            }
        }
    }
}

/**
 * 1. VOLUME CONTROL PANEL
 * Volume (0-200%), Fade In, Fade Out, Pitch shift, Vocal clarity, Mute
 */
@Composable
fun VolumeControlPanel(onVolumeChange: (Float) -> Unit) {
    var volume by remember { mutableFloatStateOf(100f) }
    var fadeInSec by remember { mutableFloatStateOf(0.5f) }
    var fadeOutSec by remember { mutableFloatStateOf(0.5f) }
    var isMuted by remember { mutableStateOf(false) }
    var keepPitch by remember { mutableStateOf(true) }
    var vocalBoost by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxWidth()) {
        ParamSlider(
            label = "VOLUME",
            value = if (isMuted) 0f else volume,
            range = 0f..200f,
            onValueChange = {
                volume = it
                isMuted = false
                onVolumeChange(it / 100f)
            }
        )

        // Quick volume preset buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf(0f, 50f, 100f, 150f, 200f).forEach { preset ->
                val isSel = !isMuted && volume == preset
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(3.dp))
                        .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                        .border(0.8.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(3.dp))
                        .clickable {
                            volume = preset
                            isMuted = preset == 0f
                            onVolumeChange(preset / 100f)
                        }
                        .padding(vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${preset.toInt()}%",
                        fontFamily = MonoTimecodeFont,
                        fontSize = 9.sp,
                        color = if (isSel) TextWhite else TextSecondary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Fade in & Fade out sliders
        ParamSlider(
            label = "FADE IN (s)",
            value = fadeInSec,
            range = 0f..5.0f,
            onValueChange = { fadeInSec = it }
        )
        ParamSlider(
            label = "FADE OUT (s)",
            value = fadeOutSec,
            range = 0f..5.0f,
            onValueChange = { fadeOutSec = it }
        )

        Spacer(modifier = Modifier.height(4.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("KEEP NATURAL PITCH", style = TimecodeStyleSmall, color = TextSecondary)
            Switch(
                checked = keepPitch,
                onCheckedChange = { keepPitch = it },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = AccentCoolBlue,
                    checkedTrackColor = AccentCoolBlueMuted,
                    uncheckedTrackColor = PanelDarkElevated,
                    uncheckedThumbColor = TextMuted
                )
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("VOCAL CLARITY BOOST", style = TimecodeStyleSmall, color = TextSecondary)
            Switch(
                checked = vocalBoost,
                onCheckedChange = { vocalBoost = it },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = AccentCoolBlue,
                    checkedTrackColor = AccentCoolBlueMuted,
                    uncheckedTrackColor = PanelDarkElevated,
                    uncheckedThumbColor = TextMuted
                )
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("MUTE CLIP AUDIO", style = TimecodeStyleSmall, color = TextSecondary)
            Switch(
                checked = isMuted,
                onCheckedChange = {
                    isMuted = it
                    onVolumeChange(if (it) 0f else volume / 100f)
                },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = AccentCoolBlue,
                    checkedTrackColor = AccentCoolBlueMuted,
                    uncheckedTrackColor = PanelDarkElevated,
                    uncheckedThumbColor = TextMuted
                )
            )
        }
    }
}

/**
 * 2. OPACITY CONTROL PANEL
 * Opacity slider (0-100%) and 10 Blend Modes (Normal, Screen, Multiply, Overlay, etc.)
 */
@Composable
fun OpacityControlPanel(onOpacityChange: (Float) -> Unit) {
    var opacity by remember { mutableFloatStateOf(100f) }
    var selectedBlend by remember { mutableStateOf("Normal") }
    val blendModes = listOf("Normal", "Screen", "Multiply", "Overlay", "Darken", "Lighten", "Soft Light", "Color Dodge", "Hard Light", "Difference")

    Column(modifier = Modifier.fillMaxWidth()) {
        ParamSlider(
            label = "OPACITY",
            value = opacity,
            range = 0f..100f,
            onValueChange = {
                opacity = it
                onOpacityChange(it / 100f)
            }
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text("BLEND MODE", style = TimecodeStyleSmall, color = TextSecondary)
        Spacer(modifier = Modifier.height(4.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            blendModes.forEach { mode ->
                val isSel = selectedBlend == mode
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                        .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                        .clickable { selectedBlend = mode }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = mode,
                        style = TimecodeStyleSmall,
                        color = if (isSel) TextWhite else TextSecondary
                    )
                }
            }
        }
    }
}

/**
 * 3. SPEED CONTROL PANEL
 * Standard rates (0.1x - 100x), Velocity Curves (Montage, Hero, Bullet, Flash-In), Bezier curve graph
 */
@Composable
fun SpeedControlPanel(onSpeedChange: (Float) -> Unit) {
    var speed by remember { mutableFloatStateOf(1.0f) }
    var modeTab by remember { mutableStateOf("Standard") }
    var smoothSlowMo by remember { mutableStateOf(true) }
    var pitchCorrection by remember { mutableStateOf(true) }
    val rates = listOf(0.1f, 0.5f, 1.0f, 2.0f, 5.0f, 10.0f, 50.0f, 100.0f)
    val curves = listOf("Montage", "Hero", "Bullet", "Jump Cut", "Flash-In", "Custom")

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("Standard", "Curve").forEach { tab ->
                val isSel = modeTab == tab
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                        .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                        .clickable { modeTab = tab }
                        .padding(vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = tab,
                        style = TimecodeStyleSmall,
                        color = if (isSel) TextWhite else TextSecondary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (modeTab == "Standard") {
            ParamSlider(
                label = "SPEED",
                value = speed,
                range = 0.1f..10.0f,
                onValueChange = {
                    speed = it
                    onSpeedChange(it)
                }
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                rates.forEach { rate ->
                    val isSelected = speed == rate
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isSelected) AccentCoolBlueSubtle else PanelDarkElevated)
                            .border(1.dp, if (isSelected) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                            .clickable {
                                speed = rate
                                onSpeedChange(rate)
                            }
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "${rate}x",
                            style = TimecodeStyleSmall,
                            color = if (isSelected) TextWhite else TextSecondary
                        )
                    }
                }
            }
        } else {
            var selectedCurve by remember { mutableStateOf("Hero") }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                curves.forEach { curve ->
                    val isSel = selectedCurve == curve
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                            .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                            .clickable {
                                selectedCurve = curve
                                val factor = when (curve) {
                                    "Montage" -> 2.5f
                                    "Hero" -> 3.2f
                                    "Bullet" -> 5.0f
                                    "Jump Cut" -> 4.0f
                                    "Flash-In" -> 7.5f
                                    else -> 1.0f
                                }
                                onSpeedChange(factor)
                            }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(text = curve, style = TimecodeStyleSmall, color = if (isSel) TextWhite else TextPrimary)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // CapCut Velocity Curve Graph Canvas
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(84.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(PanelDarkElevated)
                    .border(1.dp, PanelBorderActive, RoundedCornerShape(6.dp))
                    .padding(8.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    drawLine(Color(0xFF333333), Offset(0f, h * 0.5f), Offset(w, h * 0.5f), 1f)
                    val path = Path().apply {
                        moveTo(0f, h * 0.7f)
                        cubicTo(w * 0.25f, h * 0.75f, w * 0.38f, h * 0.15f, w * 0.52f, h * 0.15f)
                        cubicTo(w * 0.68f, h * 0.15f, w * 0.82f, h * 0.85f, w, h * 0.65f)
                    }
                    drawPath(path, color = AccentCoolBlue, style = Stroke(width = 2.5f))
                    drawCircle(Color.White, radius = 5f, center = Offset(w * 0.52f, h * 0.15f))
                    drawCircle(AccentCoolBlue, radius = 4f, center = Offset(w * 0.25f, h * 0.72f))
                    drawCircle(AccentCoolBlue, radius = 4f, center = Offset(w * 0.82f, h * 0.82f))
                }
                Text(
                    text = "$selectedCurve Velocity: 0.3x ➔ 3.2x ➔ 0.5x (Smooth Speed Ramp)",
                    fontFamily = MonoTimecodeFont,
                    fontSize = 9.sp,
                    color = AccentCoolBlue,
                    modifier = Modifier.align(Alignment.BottomStart)
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("SMOOTH SLOW-MOTION (OPTICAL FLOW)", style = TimecodeStyleSmall, color = TextSecondary)
            Switch(
                checked = smoothSlowMo,
                onCheckedChange = { smoothSlowMo = it },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = AccentCoolBlue,
                    checkedTrackColor = AccentCoolBlueMuted,
                    uncheckedTrackColor = PanelDarkElevated,
                    uncheckedThumbColor = TextMuted
                )
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("PITCH CORRECTION", style = TimecodeStyleSmall, color = TextSecondary)
            Switch(
                checked = pitchCorrection,
                onCheckedChange = { pitchCorrection = it },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = AccentCoolBlue,
                    checkedTrackColor = AccentCoolBlueMuted,
                    uncheckedTrackColor = PanelDarkElevated,
                    uncheckedThumbColor = TextMuted
                )
            )
        }
    }
}

/**
 * 4. ANIMATIONS PANEL
 * In, Out, Combo animations with duration slider
 */
@Composable
fun AnimationsPanel(onSelectAnimation: (String?) -> Unit) {
    var animTab by remember { mutableStateOf("In") }
    var selectedAnim by remember { mutableStateOf<String?>(null) }
    var animDuration by remember { mutableFloatStateOf(0.8f) }
    val inAnims = listOf("Fade In", "Zoom 1", "Zoom 2", "Slide Right", "Rotate Spin", "Swing", "Whip In", "Glitch In")
    val outAnims = listOf("Fade Out", "Zoom Out", "Slide Left", "Drop Off", "Blur Out", "Whip Out", "Shatter")
    val comboAnims = listOf("Pendulum", "Spin Fall", "Wobble", "Shake Zoom", "Distort", "3D Flip", "Bounce Flash")

    val activeList = if (animTab == "In") inAnims else if (animTab == "Out") outAnims else comboAnims

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("In", "Out", "Combo").forEach { tab ->
                val isSel = animTab == tab
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                        .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                        .clickable { animTab = tab }
                        .padding(vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = tab, style = TimecodeStyleSmall, color = if (isSel) TextWhite else TextSecondary)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (selectedAnim == null) AccentCoolBlueSubtle else PanelDarkElevated)
                    .border(1.dp, if (selectedAnim == null) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                    .clickable {
                        selectedAnim = null
                        onSelectAnimation(null)
                    }
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text("None", style = TimecodeStyleSmall, color = TextSecondary)
            }

            activeList.forEach { anim ->
                val isSel = selectedAnim == anim
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                        .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                        .clickable {
                            selectedAnim = anim
                            onSelectAnimation(anim)
                        }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(text = anim, style = TimecodeStyleSmall, color = if (isSel) TextWhite else TextPrimary)
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        ParamSlider(label = "DURATION (s)", value = animDuration, range = 0.1f..3.0f, onValueChange = { animDuration = it })
    }
}

/**
 * 5. MASK CONTROL PANEL
 * Shapes, Invert, Feather, Scale, Rotation
 */
@Composable
fun MaskControlPanel(onSelectMask: (String?) -> Unit) {
    var activeMask by remember { mutableStateOf("None") }
    var isInverted by remember { mutableStateOf(false) }
    var feather by remember { mutableFloatStateOf(10f) }
    var maskScale by remember { mutableFloatStateOf(100f) }
    var maskRotation by remember { mutableFloatStateOf(0f) }
    val masks = listOf("None", "Split", "Filmstrip", "Circle", "Rectangle", "Heart", "Star")

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            masks.forEach { mask ->
                val isSel = activeMask == mask
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                        .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                        .clickable {
                            activeMask = mask
                            onSelectMask(if (mask == "None") null else mask)
                        }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(text = mask, style = TimecodeStyleSmall, color = if (isSel) TextWhite else TextSecondary)
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        ParamSlider(label = "FEATHER", value = feather, range = 0f..100f, onValueChange = { feather = it })
        ParamSlider(label = "MASK SCALE", value = maskScale, range = 50f..200f, onValueChange = { maskScale = it })
        ParamSlider(label = "ROTATION", value = maskRotation, range = -180f..180f, onValueChange = { maskRotation = it })

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("INVERT MASK", style = TimecodeStyleSmall, color = TextSecondary)
            Switch(
                checked = isInverted,
                onCheckedChange = { isInverted = it },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = AccentCoolBlue,
                    checkedTrackColor = AccentCoolBlueMuted,
                    uncheckedTrackColor = PanelDarkElevated,
                    uncheckedThumbColor = TextMuted
                )
            )
        }
    }
}

/**
 * 6. CROP CONTROL PANEL
 * Presets, Straighten Angle (-45° to +45°), Rotate 90°, Flip Horizontal & Vertical
 */
@Composable
fun CropControlPanel() {
    var selectedRatio by remember { mutableStateOf("Free") }
    var straightenAngle by remember { mutableFloatStateOf(0f) }
    val ratios = listOf("Free", "16:9", "9:16", "1:1", "4:5", "3:4", "2.39:1")

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ratios.forEach { ratio ->
                val isSel = selectedRatio == ratio
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                        .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                        .clickable { selectedRatio = ratio }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(text = ratio, style = TimecodeStyleSmall, color = if (isSel) TextWhite else TextSecondary)
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        ParamSlider(
            label = "STRAIGHTEN",
            value = straightenAngle,
            range = -45f..45f,
            onValueChange = { straightenAngle = it }
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = { },
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text("Rotate 90°", style = TimecodeStyleSmall, color = TextPrimary)
            }
            OutlinedButton(
                onClick = { },
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text("Flip H", style = TimecodeStyleSmall, color = TextPrimary)
            }
            OutlinedButton(
                onClick = { },
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text("Flip V", style = TimecodeStyleSmall, color = TextPrimary)
            }
        }
    }
}

/**
 * 7. TRANSFORM CONTROL PANEL
 * Scale (10-500%), Position X/Y, Rotation (-180° to 180°), Alignment Presets
 */
@Composable
fun TransformControlPanel() {
    var scale by remember { mutableFloatStateOf(100f) }
    var posX by remember { mutableFloatStateOf(0f) }
    var posY by remember { mutableFloatStateOf(0f) }
    var rotation by remember { mutableFloatStateOf(0f) }

    Column(modifier = Modifier.fillMaxWidth()) {
        ParamSlider(label = "SCALE", value = scale, range = 10f..300f, onValueChange = { scale = it })
        ParamSlider(label = "POS X", value = posX, range = -300f..300f, onValueChange = { posX = it })
        ParamSlider(label = "POS Y", value = posY, range = -300f..300f, onValueChange = { posY = it })
        ParamSlider(label = "ROTATION", value = rotation, range = -180f..180f, onValueChange = { rotation = it })

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf("Center", "Top", "Bottom", "Reset").forEach { align ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(3.dp))
                        .background(PanelDarkElevated)
                        .border(0.8.dp, PanelBorder, RoundedCornerShape(3.dp))
                        .clickable {
                            when (align) {
                                "Center" -> { posX = 0f; posY = 0f }
                                "Top" -> posY = -150f
                                "Bottom" -> posY = 150f
                                "Reset" -> { scale = 100f; posX = 0f; posY = 0f; rotation = 0f }
                            }
                        }
                        .padding(vertical = 5.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = align, fontFamily = MonoTimecodeFont, fontSize = 8.5.sp, color = TextSecondary)
                }
            }
        }
    }
}

/**
 * 8. REMOVE BACKGROUND PANEL
 * Auto Cutout (AI), Chroma Key (color picker, intensity, shadow), Custom Stroke
 */
@Composable
fun RemoveBackgroundPanel() {
    var mode by remember { mutableStateOf("Auto Cutout (AI)") }
    var feather by remember { mutableFloatStateOf(20f) }
    var chromaIntensity by remember { mutableFloatStateOf(50f) }
    var chromaShadow by remember { mutableFloatStateOf(30f) }
    var strokeColor by remember { mutableStateOf("None") }
    val modes = listOf("Auto Cutout (AI)", "Chroma Key", "Custom Stroke")

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            modes.forEach { m ->
                val isSel = mode == m
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                        .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                        .clickable { mode = m }
                        .padding(vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = m, style = TimecodeStyleSmall, fontSize = 8.5.sp, color = if (isSel) TextWhite else TextSecondary)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        when (mode) {
            "Auto Cutout (AI)" -> {
                ParamSlider(label = "EDGE FEATHER", value = feather, range = 0f..100f, onValueChange = { feather = it })
                Text("OUTLINE STROKE AURA", style = TimecodeStyleSmall, color = TextSecondary)
                Spacer(modifier = Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("None", "White Glow", "Cyan Neon", "Gold").forEach { str ->
                        val isSel = strokeColor == str
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                                .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                                .clickable { strokeColor = str }
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Text(text = str, style = TimecodeStyleSmall, color = if (isSel) TextWhite else TextSecondary)
                        }
                    }
                }
            }
            "Chroma Key" -> {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("KEY COLOR:", style = TimecodeStyleSmall, color = TextSecondary)
                    Box(modifier = Modifier.size(20.dp).background(Color(0xFF00FF00), CircleShape).border(1.dp, Color.White, CircleShape))
                    Box(modifier = Modifier.size(20.dp).background(Color(0xFF0055FF), CircleShape))
                    Box(modifier = Modifier.size(20.dp).background(Color(0xFF000000), CircleShape))
                }
                Spacer(modifier = Modifier.height(6.dp))
                ParamSlider(label = "INTENSITY", value = chromaIntensity, range = 0f..100f, onValueChange = { chromaIntensity = it })
                ParamSlider(label = "SHADOW", value = chromaShadow, range = 0f..100f, onValueChange = { chromaShadow = it })
            }
            "Custom Stroke" -> {
                var strokeWidth by remember { mutableFloatStateOf(4f) }
                ParamSlider(label = "STROKE WIDTH", value = strokeWidth, range = 1f..20f, onValueChange = { strokeWidth = it })
            }
        }
    }
}

/**
 * 9. STABILIZE PANEL
 * Minimal, Recommended, Most Stable, Tripod Lock with Rolling Shutter Reduction
 */
@Composable
fun StabilizePanel() {
    var level by remember { mutableStateOf("Recommended") }
    var rollingShutter by remember { mutableStateOf(true) }
    var cropBuffer by remember { mutableFloatStateOf(10f) }
    val levels = listOf("Minimal", "Recommended", "Most Stable", "Tripod Lock")

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            levels.forEach { lvl ->
                val isSel = level == lvl
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                        .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                        .clickable { level = lvl }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = lvl, style = TimecodeStyleSmall, fontSize = 8.sp, color = if (isSel) TextWhite else TextSecondary)
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        ParamSlider(label = "AUTO CROP BUFFER", value = cropBuffer, range = 5f..25f, onValueChange = { cropBuffer = it })

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("ROLLING SHUTTER REDUCTION", style = TimecodeStyleSmall, color = TextSecondary)
            Switch(
                checked = rollingShutter,
                onCheckedChange = { rollingShutter = it },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = AccentCoolBlue,
                    checkedTrackColor = AccentCoolBlueMuted,
                    uncheckedTrackColor = PanelDarkElevated,
                    uncheckedThumbColor = TextMuted
                )
            )
        }
    }
}

/**
 * 10. AUDIO EFFECTS PANEL
 * Voice Changers (Studio, Deep, Chipmunk, Robot, Echo, Megaphone, Synth, Monster), Ambient Environments
 */
@Composable
fun AudioEffectsPanel() {
    var activeTab by remember { mutableStateOf("Voice Changers") }
    var activeEffect by remember { mutableStateOf("Studio") }
    var pitchShift by remember { mutableFloatStateOf(0f) }
    var reverbAmount by remember { mutableFloatStateOf(30f) }

    val voices = listOf("Studio", "Deep", "Chipmunk", "Monster", "Robot", "Echo", "Megaphone", "Synth Vocoder")
    val ambient = listOf("Telephone 8kHz", "Vinyl 33RPM", "Bathroom Reverb", "Tunnel Echo", "Cathedral", "Lo-Fi Radio")

    val currentList = if (activeTab == "Voice Changers") voices else ambient

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("Voice Changers", "Atmosphere & Filters").forEach { tab ->
                val isSel = activeTab == tab
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                        .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                        .clickable { activeTab = tab }
                        .padding(vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = tab, style = TimecodeStyleSmall, color = if (isSel) TextWhite else TextSecondary)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            currentList.forEach { eff ->
                val isSel = activeEffect == eff
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                        .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                        .clickable { activeEffect = eff }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(text = eff, style = TimecodeStyleSmall, color = if (isSel) TextWhite else TextSecondary)
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        ParamSlider(label = "PITCH SHIFT (st)", value = pitchShift, range = -12f..12f, onValueChange = { pitchShift = it })
        ParamSlider(label = "REVERB AMOUNT", value = reverbAmount, range = 0f..100f, onValueChange = { reverbAmount = it })
    }
}

/**
 * 11. AUTO REFRAME PANEL
 * Aspect ratios (9:16, 1:1, 16:9, 4:5, 2.35:1), Target focus (Face, Action, Multi-Person)
 */
@Composable
fun AutoReframePanel() {
    var ratio by remember { mutableStateOf("9:16") }
    var trackingFocus by remember { mutableStateOf("Face Tracking") }
    var motionSpeed by remember { mutableStateOf("Balanced") }
    val ratios = listOf("9:16", "1:1", "16:9", "4:5", "2.35:1")

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ratios.forEach { r ->
                val isSel = ratio == r
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                        .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                        .clickable { ratio = r }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = r, style = TimecodeStyleSmall, color = if (isSel) TextWhite else TextSecondary)
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text("TRACKING FOCUS", style = TimecodeStyleSmall, color = TextSecondary)
        Spacer(modifier = Modifier.height(4.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf("Face Tracking", "Action Subject", "Multi-Person").forEach { focus ->
                val isSel = trackingFocus == focus
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                        .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                        .clickable { trackingFocus = focus }
                        .padding(vertical = 5.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = focus, style = TimecodeStyleSmall, fontSize = 8.sp, color = if (isSel) TextWhite else TextSecondary)
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf("Smooth Cine", "Balanced", "Rapid Action").forEach { speed ->
                val isSel = motionSpeed == speed
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                        .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                        .clickable { motionSpeed = speed }
                        .padding(vertical = 5.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = speed, style = TimecodeStyleSmall, fontSize = 8.sp, color = if (isSel) TextWhite else TextSecondary)
                }
            }
        }
    }
}

/**
 * 12. MOTION BLUR PANEL
 * Blur, Blend, Direction, Samples, Shutter Angle
 */
@Composable
fun MotionBlurPanel() {
    var intensity by remember { mutableFloatStateOf(65f) }
    var blend by remember { mutableFloatStateOf(50f) }
    var direction by remember { mutableStateOf("Both") }
    var shutterAngle by remember { mutableStateOf("180° (Cine)") }

    Column(modifier = Modifier.fillMaxWidth()) {
        ParamSlider(label = "BLUR INTENSITY", value = intensity, range = 0f..100f, onValueChange = { intensity = it })
        ParamSlider(label = "BLEND OPACITY", value = blend, range = 0f..100f, onValueChange = { blend = it })

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf("Forward", "Both", "Reverse").forEach { dir ->
                val isSel = direction == dir
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                        .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                        .clickable { direction = dir }
                        .padding(vertical = 5.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = dir, style = TimecodeStyleSmall, color = if (isSel) TextWhite else TextSecondary)
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf("90° Sharp", "180° (Cine)", "360° Dreamy").forEach { ang ->
                val isSel = shutterAngle == ang
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                        .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                        .clickable { shutterAngle = ang }
                        .padding(vertical = 5.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = ang, style = TimecodeStyleSmall, fontSize = 8.5.sp, color = if (isSel) TextWhite else TextSecondary)
                }
            }
        }
    }
}

/**
 * 13. RETOUCH PANEL
 * Face Smooth, Skin Tone, Whiten Teeth, Brighten Eyes, Face Slimming, Blemishes
 */
@Composable
fun RetouchPanel() {
    var smooth by remember { mutableFloatStateOf(60f) }
    var tone by remember { mutableFloatStateOf(40f) }
    var teeth by remember { mutableFloatStateOf(45f) }
    var eyes by remember { mutableFloatStateOf(50f) }
    var slim by remember { mutableFloatStateOf(35f) }
    var removeBlemish by remember { mutableStateOf(true) }

    Column(modifier = Modifier.fillMaxWidth()) {
        ParamSlider(label = "SMOOTH SKIN", value = smooth, range = 0f..100f, onValueChange = { smooth = it })
        ParamSlider(label = "SKIN TONE", value = tone, range = -50f..50f, onValueChange = { tone = it })
        ParamSlider(label = "WHITEN TEETH", value = teeth, range = 0f..100f, onValueChange = { teeth = it })
        ParamSlider(label = "BRIGHTEN EYES", value = eyes, range = 0f..100f, onValueChange = { eyes = it })
        ParamSlider(label = "SLIM FACE", value = slim, range = 0f..100f, onValueChange = { slim = it })

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("AUTO BLEMISH REMOVAL", style = TimecodeStyleSmall, color = TextSecondary)
            Switch(
                checked = removeBlemish,
                onCheckedChange = { removeBlemish = it },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = AccentCoolBlue,
                    checkedTrackColor = AccentCoolBlueMuted,
                    uncheckedTrackColor = PanelDarkElevated,
                    uncheckedThumbColor = TextMuted
                )
            )
        }
    }
}

/**
 * 14. VIDEO QUALITY PANEL
 * 4K AI Upscale, 60fps Frame Interpolation, AI HDR Color, AI De-noise, Smart Sharpen
 */
@Composable
fun VideoQualityPanel() {
    var mode by remember { mutableStateOf("4K AI Upscale") }
    var targetBitrate by remember { mutableFloatStateOf(2.0f) }
    val options = listOf("4K AI Upscale", "60fps SVP", "AI HDR Color", "De-noise", "Sharpen")

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            options.forEach { opt ->
                val isSel = mode == opt
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                        .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                        .clickable { mode = opt }
                        .padding(horizontal = 12.dp, vertical = 7.dp)
                ) {
                    Text(text = opt, style = TimecodeStyleSmall, color = if (isSel) TextWhite else TextSecondary)
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        ParamSlider(label = "BITRATE MULTIPLIER", value = targetBitrate, range = 1.0f..3.5f, onValueChange = { targetBitrate = it })

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(4.dp))
                .background(PanelDarkElevated)
                .border(0.5.dp, PanelBorder, RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "AI ENGINE: $mode READY", fontFamily = MonoTimecodeFont, fontSize = 9.5.sp, color = AccentCoolBlue)
                    Text(text = "Enhances edges & reconstructs high-frequency details", fontFamily = FontFamily.SansSerif, fontSize = 10.sp, color = TextSecondary)
                }
                Text(text = "Active ✓", fontFamily = MonoTimecodeFont, fontSize = 10.sp, color = TextWhite)
            }
        }
    }
}

/**
 * 15. BEATS CONTROL PANEL
 * Auto beats, Manual tap, Sub-bass, Beat 1 & 2 markers, Yellow beat waveform
 */
@Composable
fun BeatsControlPanel() {
    var mode by remember { mutableStateOf("Auto Beats") }
    var beatSpeed by remember { mutableStateOf("Beat 1 (Strong)") }
    var detectedCount by remember { mutableIntStateOf(16) }

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("Auto Beats", "Manual Tap", "Sub-bass").forEach { tab ->
                val isSel = mode == tab
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                        .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                        .clickable { mode = tab }
                        .padding(vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = tab, style = TimecodeStyleSmall, color = if (isSel) TextWhite else TextSecondary)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Beat 1 (Strong)", "Beat 2 (Double)").forEach { beat ->
                    val isSel = beatSpeed == beat
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                            .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                            .clickable {
                                beatSpeed = beat
                                detectedCount = if (beat.contains("Double")) 32 else 16
                            }
                            .padding(horizontal = 8.dp, vertical = 5.dp)
                    ) {
                        Text(text = beat, style = TimecodeStyleSmall, fontSize = 9.sp, color = if (isSel) TextWhite else TextSecondary)
                    }
                }
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(3.dp))
                    .background(Color(0xFF2E2600))
                    .border(0.8.dp, Color(0xFFFFD54F), RoundedCornerShape(3.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "● $detectedCount BEATS DETECTED",
                    fontFamily = MonoTimecodeFont,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFFFD54F)
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Visual Rhythmic Beat Waveform Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(28.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(PanelDarkElevated)
                .border(0.5.dp, PanelBorder, RoundedCornerShape(4.dp))
                .padding(horizontal = 8.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                for (i in 0 until 16) {
                    val isYellowBeat = i % 2 == 0
                    Box(
                        modifier = Modifier
                            .size(if (isYellowBeat) 6.dp else 4.dp)
                            .clip(CircleShape)
                            .background(if (isYellowBeat) Color(0xFFFFD54F) else AccentCoolBlue.copy(alpha = 0.5f))
                    )
                }
            }
        }
    }
}

/**
 * 16. RELIGHT PANEL
 * 3D Keylight, Ambient fill, Golden Sunset, Neon Cyan, Noir with 3D angle selector
 */
@Composable
fun RelightPanel() {
    var lightSource by remember { mutableStateOf("Face Keylight") }
    var intensity by remember { mutableFloatStateOf(65f) }
    var radius by remember { mutableFloatStateOf(50f) }
    var lightAngle by remember { mutableStateOf("Top-Left 45°") }

    val lightTypes = listOf("Face Keylight", "Ambient Fill", "Golden Sunset", "Neon Cyan", "Moody Noir")
    val angles = listOf("Top-Left 45°", "Top Center", "Top-Right 45°", "Front Direct")

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            lightTypes.forEach { type ->
                val isSel = lightSource == type
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                        .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                        .clickable { lightSource = type }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(text = type, style = TimecodeStyleSmall, color = if (isSel) TextWhite else TextSecondary)
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        ParamSlider(label = "LIGHT INTENSITY", value = intensity, range = 0f..100f, onValueChange = { intensity = it })
        ParamSlider(label = "RADIUS & SPREAD", value = radius, range = 10f..100f, onValueChange = { radius = it })

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            angles.forEach { angle ->
                val isSel = lightAngle == angle
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(3.dp))
                        .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                        .border(0.8.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(3.dp))
                        .clickable { lightAngle = angle }
                        .padding(vertical = 5.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = angle.take(8), fontFamily = MonoTimecodeFont, fontSize = 8.sp, color = if (isSel) TextWhite else TextSecondary)
                }
            }
        }
    }
}

/**
 * 17. CAMERA TRACKING PANEL
 * Target: Face, Body, Object, Text Pin
 */
@Composable
fun CameraTrackingPanel() {
    var trackTarget by remember { mutableStateOf("Face") }
    var isTrackingActive by remember { mutableStateOf(true) }

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("Face", "Body", "Object", "Text Pin").forEach { target ->
                val isSel = trackTarget == target
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                        .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                        .clickable { trackTarget = target }
                        .padding(vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = target, style = TimecodeStyleSmall, color = if (isSel) TextWhite else TextSecondary)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(text = "MOTION TRACKING: $trackTarget", style = TimecodeStyleSmall, color = TextWhite)
                Text(text = "Tracks clip subject through keyframe spline", fontFamily = FontFamily.SansSerif, fontSize = 10.sp, color = TextSecondary)
            }
            Button(
                onClick = { isTrackingActive = !isTrackingActive },
                shape = RoundedCornerShape(4.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isTrackingActive) AccentCoolBlue else PanelDarkElevated,
                    contentColor = if (isTrackingActive) BgPureDark else TextPrimary
                ),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 5.dp),
                modifier = Modifier.height(30.dp)
            ) {
                Text(text = if (isTrackingActive) "Locked ✓" else "Start Track", fontSize = 10.sp)
            }
        }
    }
}

/**
 * 18. ENHANCE VOICE PANEL
 * Presets: Studio Mic, Clean Speech, De-Reverb, Podcast Boost, Warm Tone
 */
@Composable
fun EnhanceVoicePanel() {
    var clarity by remember { mutableFloatStateOf(75f) }
    var preset by remember { mutableStateOf("Studio Mic") }
    val presets = listOf("Studio Mic", "Clean Speech", "De-Reverb", "Podcast Boost", "Warm Tone")

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            presets.forEach { p ->
                val isSel = preset == p
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                        .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                        .clickable { preset = p }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(text = p, style = TimecodeStyleSmall, color = if (isSel) TextWhite else TextSecondary)
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        ParamSlider(label = "VOICE ENHANCE INTENSITY", value = clarity, range = 0f..100f, onValueChange = { clarity = it })
    }
}

/**
 * 19. NOISE REDUCTION PANEL
 * Wind Noise, Background Hiss, Traffic/AC, Low-cut 80Hz
 */
@Composable
fun NoiseReductionPanel() {
    var level by remember { mutableFloatStateOf(80f) }
    var mode by remember { mutableStateOf("Background Hiss") }
    val modes = listOf("Wind Noise", "Background Hiss", "Traffic / AC", "Low-cut 80Hz")

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            modes.forEach { m ->
                val isSel = mode == m
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                        .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                        .clickable { mode = m }
                        .padding(vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = m.take(9), style = TimecodeStyleSmall, fontSize = 8.sp, color = if (isSel) TextWhite else TextSecondary)
                }
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        ParamSlider(label = "REDUCTION STRENGTH", value = level, range = 0f..100f, onValueChange = { level = it })
    }
}

/**
 * 20. VOICE ISOLATION PANEL
 * Keep Vocals (Acapella), Remove Vocals (Karaoke), Equalize BGM
 */
@Composable
fun VoiceIsolationPanel() {
    var isolateMode by remember { mutableStateOf("Keep Vocals") }
    var vocalBoost by remember { mutableFloatStateOf(3.0f) }

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("Keep Vocals", "Remove Vocals (Karaoke)", "Equalize BGM").forEach { mode ->
                val isSel = isolateMode == mode
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                        .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                        .clickable { isolateMode = mode }
                        .padding(vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = mode, style = TimecodeStyleSmall, fontSize = 9.sp, color = if (isSel) TextWhite else TextSecondary)
                }
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        ParamSlider(label = "VOCAL GAIN (dB)", value = vocalBoost, range = -6f..12f, onValueChange = { vocalBoost = it })
    }
}

/**
 * 21. UNLINK & EXTRACT AUDIO PANEL
 */
@Composable
fun UnlinkAudioPanel() {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "AUDIO EXTRACTED TO TIMELINE ♪",
            style = TimecodeStyleSmall,
            color = AccentCoolBlue,
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Audio track has been separated from video clip and placed on the audio track below. You can trim, fade, or edit both independently.",
            fontFamily = FontFamily.SansSerif,
            fontSize = 11.sp,
            color = TextSecondary
        )
    }
}

/**
 * 22. FREEZE CONTROL PANEL
 * Duration selector (1s, 2s, 3s, 5s) and Insert Freeze Frame
 */
@Composable
fun FreezeControlPanel(onFreeze: () -> Unit) {
    var duration by remember { mutableFloatStateOf(3.0f) }
    var muteFreezeAudio by remember { mutableStateOf(true) }

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf(1.0f, 2.0f, 3.0f, 5.0f).forEach { d ->
                val isSel = duration == d
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                        .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                        .clickable { duration = d }
                        .padding(vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "${d.toInt()}s Freeze", style = TimecodeStyleSmall, color = if (isSel) TextWhite else TextSecondary)
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("MUTE AUDIO DURING FREEZE", style = TimecodeStyleSmall, color = TextSecondary)
            Switch(
                checked = muteFreezeAudio,
                onCheckedChange = { muteFreezeAudio = it },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = AccentCoolBlue,
                    checkedTrackColor = AccentCoolBlueMuted,
                    uncheckedTrackColor = PanelDarkElevated,
                    uncheckedThumbColor = TextMuted
                )
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Button(
            onClick = onFreeze,
            shape = RoundedCornerShape(4.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AccentCoolBlue, contentColor = BgPureDark),
            modifier = Modifier.fillMaxWidth().height(36.dp)
        ) {
            Text("Insert Freeze Frame (${duration.toInt()}s) at Playhead", fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, color = BgPureDark)
        }
    }
}

/**
 * 23. REVERSE CONTROL PANEL
 * Reverse video, Reverse audio, and Processing
 */
@Composable
fun ReverseControlPanel(onReverse: () -> Unit) {
    var reverseVideo by remember { mutableStateOf(true) }
    var reverseAudio by remember { mutableStateOf(false) }
    var isReversedDone by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("REVERSE VIDEO STREAM", style = TimecodeStyleSmall, color = TextSecondary)
            Switch(
                checked = reverseVideo,
                onCheckedChange = { reverseVideo = it },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = AccentCoolBlue,
                    checkedTrackColor = AccentCoolBlueMuted,
                    uncheckedTrackColor = PanelDarkElevated,
                    uncheckedThumbColor = TextMuted
                )
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("REVERSE AUDIO STREAM", style = TimecodeStyleSmall, color = TextSecondary)
            Switch(
                checked = reverseAudio,
                onCheckedChange = { reverseAudio = it },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = AccentCoolBlue,
                    checkedTrackColor = AccentCoolBlueMuted,
                    uncheckedTrackColor = PanelDarkElevated,
                    uncheckedThumbColor = TextMuted
                )
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = {
                onReverse()
                isReversedDone = true
            },
            shape = RoundedCornerShape(4.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AccentCoolBlue, contentColor = BgPureDark),
            modifier = Modifier.fillMaxWidth().height(36.dp)
        ) {
            Text(if (isReversedDone) "Reversed ✓ (Tap to Toggle)" else "Execute Reverse Playback", fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, color = BgPureDark)
        }
    }
}

/**
 * 24. SPLIT CONTROL PANEL
 */
@Composable
fun SplitControlPanel(onSplit: () -> Unit) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text("PRECISION SPLIT AT PLAYHEAD", style = TimecodeStyleSmall, color = TextWhite)
        Spacer(modifier = Modifier.height(4.dp))
        Text("Splits active clip into two independent segments at the vertical playhead line", fontFamily = FontFamily.SansSerif, fontSize = 11.sp, color = TextSecondary)
        Spacer(modifier = Modifier.height(8.dp))
        Button(
            onClick = onSplit,
            shape = RoundedCornerShape(4.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AccentCoolBlue, contentColor = BgPureDark),
            modifier = Modifier.fillMaxWidth().height(36.dp)
        ) {
            Text("Split Clip Now", fontWeight = FontWeight.Medium, color = BgPureDark)
        }
    }
}

/**
 * 25. DUPLICATE CONTROL PANEL
 */
@Composable
fun DuplicateControlPanel(onDuplicate: () -> Unit) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text("DUPLICATE CLIP", style = TimecodeStyleSmall, color = TextWhite)
        Spacer(modifier = Modifier.height(4.dp))
        Text("Creates an identical copy of the clip with all current effects and timing", fontFamily = FontFamily.SansSerif, fontSize = 11.sp, color = TextSecondary)
        Spacer(modifier = Modifier.height(8.dp))
        Button(
            onClick = onDuplicate,
            shape = RoundedCornerShape(4.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AccentCoolBlue, contentColor = BgPureDark),
            modifier = Modifier.fillMaxWidth().height(36.dp)
        ) {
            Text("Duplicate to Right on Timeline", fontWeight = FontWeight.Medium, color = BgPureDark)
        }
    }
}

/**
 * 26. DELETE CONTROL PANEL
 */
@Composable
fun DeleteControlPanel(onDelete: () -> Unit) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text("DELETE CLIP", style = TimecodeStyleSmall, color = Color(0xFFFF6B6B))
        Spacer(modifier = Modifier.height(4.dp))
        Text("Removes the selected clip from the timeline. Timeline will ripple to close gap.", fontFamily = FontFamily.SansSerif, fontSize = 11.sp, color = TextSecondary)
        Spacer(modifier = Modifier.height(8.dp))
        Button(
            onClick = onDelete,
            shape = RoundedCornerShape(4.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8B2B2B), contentColor = Color.White),
            modifier = Modifier.fillMaxWidth().height(36.dp)
        ) {
            Text("Confirm Delete Clip", fontWeight = FontWeight.Medium, color = Color.White)
        }
    }
}

/**
 * 27. REPLACE CONTROL PANEL
 */
@Composable
fun ReplaceControlPanel(onReplace: () -> Unit) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text("REPLACE CLIP MEDIA", style = TimecodeStyleSmall, color = TextWhite)
        Spacer(modifier = Modifier.height(4.dp))
        Text("Select a new video or photo from your device to swap in place while keeping transitions", fontFamily = FontFamily.SansSerif, fontSize = 11.sp, color = TextSecondary)
        Spacer(modifier = Modifier.height(8.dp))
        Button(
            onClick = onReplace,
            shape = RoundedCornerShape(4.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AccentCoolBlue, contentColor = BgPureDark),
            modifier = Modifier.fillMaxWidth().height(36.dp)
        ) {
            Text("Open Gallery / Media Picker", fontWeight = FontWeight.Medium, color = BgPureDark)
        }
    }
}

/**
 * 28. EDIT CONTROL PANEL (when Edit is tapped from main toolbar)
 */
@Composable
fun EditControlPanel(onSplit: () -> Unit) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text("EDIT MODE: SELECT & CUT", style = TimecodeStyleSmall, color = TextWhite)
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = onSplit,
                shape = RoundedCornerShape(4.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AccentCoolBlue, contentColor = BgPureDark),
                modifier = Modifier.weight(1f).height(36.dp)
            ) {
                Text("Split Clip", fontWeight = FontWeight.Medium, color = BgPureDark)
            }
        }
    }
}

/**
 * 29. ASPECT RATIO PANEL
 */
@Composable
fun AspectRatioPanel() {
    var selRatio by remember { mutableStateOf("9:16") }
    var fitMode by remember { mutableStateOf("Fit") }
    val ratios = listOf(
        Triple("9:16", "Reels/TikTok", Pair(13, 23)),
        Triple("16:9", "YouTube", Pair(23, 13)),
        Triple("1:1", "Instagram", Pair(16, 16)),
        Triple("4:5", "Social Feed", Pair(15, 19)),
        Triple("3:4", "Portrait", Pair(15, 20)),
        Triple("2.35:1", "Cinema", Pair(26, 11))
    )

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ratios.forEach { (r, platform, iconDims) ->
                val isSel = selRatio == r
                Box(
                    modifier = Modifier
                        .widthIn(min = 68.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                        .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(6.dp))
                        .clickable { selRatio = r }
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Box(
                            modifier = Modifier.size(width = 28.dp, height = 24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(width = iconDims.first.dp, height = iconDims.second.dp)
                                    .background(if (isSel) AccentCoolBlue.copy(alpha = 0.25f) else Color.Transparent)
                                    .border(1.dp, if (isSel) AccentCoolBlue else TextMuted, RoundedCornerShape(2.dp))
                            )
                        }
                        Text(text = r, fontFamily = MonoTimecodeFont, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = if (isSel) TextWhite else TextSecondary)
                        Text(text = platform, fontFamily = FontFamily.SansSerif, fontSize = 7.5.sp, color = if (isSel) AccentCoolBlue else TextMuted, maxLines = 1)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("Fit (Letterbox)", "Fill (Crop to Screen)", "Blur Canvas").forEach { mode ->
                val isSel = fitMode == mode
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                        .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                        .clickable { fitMode = mode }
                        .padding(vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = mode, style = TimecodeStyleSmall, fontSize = 8.sp, color = if (isSel) TextWhite else TextSecondary)
                }
            }
        }
    }
}

/**
 * 30. CANVAS BACKGROUND PANEL
 */
@Composable
fun CanvasBackgroundPanel() {
    var blurLevel by remember { mutableStateOf("Medium Blur") }
    var selectedColor by remember { mutableStateOf("Pure Dark") }
    val options = listOf("None", "Low Blur", "Medium Blur", "High Blur")
    val colors = listOf("Pure Dark", "Charcoal", "Slate Blue", "Emerald", "Maroon")

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            options.forEach { opt ->
                val isSel = blurLevel == opt
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                        .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                        .clickable { blurLevel = opt }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(text = opt, style = TimecodeStyleSmall, color = if (isSel) TextWhite else TextSecondary)
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            colors.forEach { c ->
                val isSel = selectedColor == c
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                        .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                        .clickable { selectedColor = c }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(text = c, style = TimecodeStyleSmall, color = if (isSel) TextWhite else TextSecondary)
                }
            }
        }
    }
}

/**
 * 31. STICKERS PANEL
 */
@Composable
fun StickersPanel(onAddSticker: (String) -> Unit = {}) {
    var category by remember { mutableStateOf("Badges") }
    val badges = listOf("★ Star", "▲ Play", "● REC", "4K UHD", "PRO", "LIVE", "SUB", "60FPS")
    val social = listOf("Subscribe", "Like", "Bell", "Follow", "Share", "Link in Bio")
    val vlog = listOf("NYC 2026", "VLOG 01", "● Sunset", "Travel Diary", "Behind Scenes")

    val currentItems = if (category == "Badges") badges else if (category == "Social") social else vlog

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("Badges", "Social", "Vlog").forEach { cat ->
                val isSel = category == cat
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                        .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                        .clickable { category = cat }
                        .padding(vertical = 5.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = cat, style = TimecodeStyleSmall, color = if (isSel) TextWhite else TextSecondary)
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            currentItems.forEach { item ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(PanelDarkElevated)
                        .border(1.dp, PanelBorder, RoundedCornerShape(4.dp))
                        .clickable { onAddSticker(item) }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(text = item, style = TimecodeStyleSmall, color = TextPrimary)
                }
            }
        }
    }
}

/**
 * 32. OVERLAY PIP PANEL
 */
@Composable
fun OverlayPipPanel() {
    var layout by remember { mutableStateOf("Corner Pin") }
    var pipOpacity by remember { mutableFloatStateOf(100f) }
    var cornerRadius by remember { mutableFloatStateOf(12f) }

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("Corner Pin", "Split Screen", "Full Overlay").forEach { l ->
                val isSel = layout == l
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                        .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                        .clickable { layout = l }
                        .padding(vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = l, style = TimecodeStyleSmall, color = if (isSel) TextWhite else TextSecondary)
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        ParamSlider(label = "PIP OPACITY", value = pipOpacity, range = 0f..100f, onValueChange = { pipOpacity = it })
        ParamSlider(label = "CORNER RADIUS", value = cornerRadius, range = 0f..32f, onValueChange = { cornerRadius = it })
    }
}

/**
 * 33. FILTERS PANEL
 */
@Composable
fun FiltersPanel(
    settings: ColorGradeSettings,
    onUpdate: ((ColorGradeSettings) -> ColorGradeSettings) -> Unit
) {
    val luts = listOf("Monochrome 400", "Neutral", "Bleach Bypass", "Nordic Cool", "Kodak 250D", "Fuji Eterna", "Cinematic Teal", "Moody Amber")
    var filterIntensity by remember { mutableFloatStateOf(80f) }

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            luts.forEach { lut ->
                val isSelected = settings.selectedLut == lut
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSelected) AccentCoolBlueSubtle else PanelDarkElevated)
                        .border(1.dp, if (isSelected) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                        .clickable { onUpdate { it.copy(selectedLut = lut) } }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = lut,
                        style = TimecodeStyleSmall,
                        color = if (isSelected) TextWhite else TextSecondary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        ParamSlider(label = "FILTER INTENSITY", value = filterIntensity, range = 0f..100f, onValueChange = { filterIntensity = it })
    }
}

/**
 * 34. COLOR GRADE & ADJUST PANEL
 * Exposure, Contrast, Temperature, Saturation, Sharpen, Vignette
 */
@Composable
fun ColorGradePanel(
    settings: ColorGradeSettings,
    onUpdate: ((ColorGradeSettings) -> ColorGradeSettings) -> Unit
) {
    var saturation by remember { mutableFloatStateOf(10f) }
    var sharpen by remember { mutableFloatStateOf(20f) }
    var vignette by remember { mutableFloatStateOf(15f) }

    Column(modifier = Modifier.fillMaxWidth()) {
        ParamSlider(
            label = "EXPOSURE",
            value = settings.exposure,
            range = -100f..100f,
            onValueChange = { v -> onUpdate { it.copy(exposure = v) } }
        )
        ParamSlider(
            label = "CONTRAST",
            value = settings.contrast,
            range = -100f..100f,
            onValueChange = { v -> onUpdate { it.copy(contrast = v) } }
        )
        ParamSlider(
            label = "TEMPERATURE",
            value = settings.temperature,
            range = -100f..100f,
            onValueChange = { v -> onUpdate { it.copy(temperature = v) } }
        )
        ParamSlider(
            label = "SATURATION",
            value = saturation,
            range = -100f..100f,
            onValueChange = { saturation = it }
        )
        ParamSlider(
            label = "SHARPEN",
            value = sharpen,
            range = 0f..100f,
            onValueChange = { sharpen = it }
        )
        ParamSlider(
            label = "VIGNETTE",
            value = vignette,
            range = 0f..100f,
            onValueChange = { vignette = it }
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            TextButton(
                onClick = {
                    onUpdate { it.copy(exposure = 0f, contrast = 0f, temperature = 0f) }
                    saturation = 0f
                    sharpen = 0f
                    vignette = 0f
                }
            ) {
                Text("Reset All Adjustments", style = TimecodeStyleSmall, color = AccentCoolBlue)
            }
        }
    }
}

/**
 * PARAM SLIDER (Common helper)
 */
@Composable
fun ParamSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = TimecodeStyleSmall,
            color = TextSecondary,
            modifier = Modifier.width(96.dp)
        )
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            modifier = Modifier.weight(1f),
            colors = SliderDefaults.colors(
                thumbColor = AccentCoolBlue,
                activeTrackColor = AccentCoolBlue,
                inactiveTrackColor = PanelBorder
            )
        )
        Text(
            text = String.format("%+d", value.toInt()),
            style = TimecodeStyleSmall,
            color = TextPrimary,
            modifier = Modifier.width(36.dp)
        )
    }
}

/**
 * 35. EFFECTS PANEL
 */
@Composable
fun EffectsPanel(
    activeEffect: String,
    onSelectEffect: (String) -> Unit
) {
    val effects = listOf(
        "Film Grain 16mm",
        "Subtle Vignette",
        "Anamorphic Streak",
        "Lens Softening",
        "Halation Glow",
        "Letterbox 2.39:1",
        "Glitch Warp",
        "RGB Split"
    )

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            effects.forEach { effect ->
                val isSelected = activeEffect == effect
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSelected) AccentCoolBlueSubtle else PanelDarkElevated)
                        .border(1.dp, if (isSelected) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                        .clickable { onSelectEffect(effect) }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = effect,
                        style = TimecodeStyleSmall,
                        color = if (isSelected) TextWhite else TextSecondary
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        var intensity by remember { mutableFloatStateOf(65f) }
        ParamSlider(
            label = "INTENSITY",
            value = intensity,
            range = 0f..100f,
            onValueChange = { intensity = it }
        )
    }
}

/**
 * 36. TRANSITIONS PANEL
 */
@Composable
fun TransitionsPanel(
    activeTransition: String,
    onSelectTransition: (String) -> Unit
) {
    val transitions = listOf(
        "Cross Dissolve",
        "Dip to Black",
        "Dip to White",
        "Whip Pan Left",
        "Whip Pan Right",
        "Zoom In Fast",
        "Spin Blur",
        "Glitch Flash"
    )

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            transitions.forEach { trans ->
                val isSelected = activeTransition == trans
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSelected) AccentCoolBlueSubtle else PanelDarkElevated)
                        .border(1.dp, if (isSelected) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                        .clickable { onSelectTransition(trans) }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = trans,
                        style = TimecodeStyleSmall,
                        color = if (isSelected) TextWhite else TextSecondary
                    )
                }
            }
        }
    }
}

/**
 * 37. AUDIO CONTROL PANEL
 */
@Composable
fun AudioControlPanel() {
    var volume by remember { mutableFloatStateOf(85f) }
    var noiseReduction by remember { mutableStateOf(false) }
    var vocalClarity by remember { mutableStateOf(true) }

    Column(modifier = Modifier.fillMaxWidth()) {
        ParamSlider(
            label = "MASTER VOL",
            value = volume,
            range = 0f..150f,
            onValueChange = { volume = it }
        )
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("VOICE ISOLATION / DE-NOISE", style = TimecodeStyleSmall, color = TextSecondary)
            Switch(
                checked = noiseReduction,
                onCheckedChange = { noiseReduction = it },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = AccentCoolBlue,
                    checkedTrackColor = AccentCoolBlueMuted,
                    uncheckedTrackColor = PanelDarkElevated,
                    uncheckedThumbColor = TextMuted
                )
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("VOCAL CLARITY ENHANCER", style = TimecodeStyleSmall, color = TextSecondary)
            Switch(
                checked = vocalClarity,
                onCheckedChange = { vocalClarity = it },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = AccentCoolBlue,
                    checkedTrackColor = AccentCoolBlueMuted,
                    uncheckedTrackColor = PanelDarkElevated,
                    uncheckedThumbColor = TextMuted
                )
            )
        }
    }
}

/**
 * 38. TEXT EDIT PANEL
 */
@Composable
fun TextEditPanel() {
    var titleText by remember { mutableStateOf("CHAPTER 01: NORDIC MONOLITH") }
    var fontSize by remember { mutableFloatStateOf(16f) }
    var fontStyle by remember { mutableStateOf("MONO") }

    Column(modifier = Modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = titleText,
            onValueChange = { titleText = it },
            label = { Text("TITLE / CAPTION", style = TimecodeStyleSmall) },
            textStyle = TimecodeStyleSmall.copy(color = TextWhite),
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = AccentCoolBlue,
                unfocusedBorderColor = PanelBorder,
                focusedLabelColor = AccentCoolBlue,
                unfocusedLabelColor = TextSecondary,
                cursorColor = AccentCoolBlue
            ),
            singleLine = true
        )
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("MONO", "SANS", "SERIF", "DISPLAY").forEach { style ->
                val isSel = fontStyle == style
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                        .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                        .clickable { fontStyle = style }
                        .padding(vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = style, style = TimecodeStyleSmall, color = if (isSel) TextWhite else TextSecondary)
                }
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        ParamSlider(label = "FONT SIZE", value = fontSize, range = 10f..48f, onValueChange = { fontSize = it })
    }
}

/**
 * 39. CAPTIONS PANEL
 */
@Composable
fun CaptionsPanel() {
    var isGenerating by remember { mutableStateOf(false) }
    var language by remember { mutableStateOf("Auto-Detect") }
    val languages = listOf("Auto-Detect", "English", "Hindi", "Spanish", "Japanese")

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            languages.forEach { lang ->
                val isSel = language == lang
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSel) AccentCoolBlueSubtle else PanelDarkElevated)
                        .border(1.dp, if (isSel) AccentCoolBlue else PanelBorder, RoundedCornerShape(4.dp))
                        .clickable { language = lang }
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(text = lang, style = TimecodeStyleSmall, color = if (isSel) TextWhite else TextSecondary)
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("AUTO CAPTIONS (SPEECH TO TEXT)", style = TimecodeStyleSmall, color = TextWhite)
                Text(if (isGenerating) "✓ Transcribed: 14 subtitle blocks created" else "Generate subtitles from video voice track", fontFamily = FontFamily.SansSerif, fontSize = 11.sp, color = TextSecondary)
            }
            Button(
                onClick = { isGenerating = true },
                shape = RoundedCornerShape(4.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AccentCoolBlue, contentColor = BgPureDark),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(if (isGenerating) "Generated ✓" else "Generate", fontWeight = FontWeight.Medium, color = BgPureDark)
            }
        }
    }
}
