package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.*
import com.example.ui.theme.*
import com.example.util.ExtractedMediaInfo
import com.example.util.MediaUtils
import com.example.viewmodel.ScreenDestination

@Composable
fun MediaLibraryScreen(
    mediaItems: List<MediaItem>,
    selectedIds: Set<String>,
    onToggleSelect: (String) -> Unit,
    onClearSelection: () -> Unit,
    onAddSelected: () -> Unit,
    onImportFromGallery: (List<ExtractedMediaInfo>) -> Unit = { },
    onBack: () -> Unit,
    onNavigateTab: (ScreenDestination) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedCategory by remember { mutableStateOf(MediaTypeCategory.ALL) }
    val context = LocalContext.current

    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris ->
        if (uris.isNotEmpty()) {
            val mediaList = MediaUtils.extractMultiple(context, uris)
            onImportFromGallery(mediaList)
        }
    }

    val filteredItems = remember(selectedCategory, mediaItems) {
        if (selectedCategory == MediaTypeCategory.ALL) mediaItems
        else mediaItems.filter { it.category == selectedCategory }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(BgPureDark),
        containerColor = BgPureDark,
        topBar = {
            MediaLibraryTopBar(
                onBack = onBack,
                onImportGallery = {
                    galleryLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                    )
                }
            )
        },
        bottomBar = {
            Column(modifier = Modifier.fillMaxWidth().navigationBarsPadding()) {
                if (selectedIds.isNotEmpty()) {
                    SelectedMediaActionBar(
                        selectedCount = selectedIds.size,
                        onClear = onClearSelection,
                        onAdd = onAddSelected
                    )
                }
                AppBottomNavBar(
                    activeDestination = ScreenDestination.MEDIA_LIBRARY,
                    onSelectTab = onNavigateTab
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            // Category filter tabs
            CategoryFilterRow(
                selected = selectedCategory,
                onSelect = { selectedCategory = it }
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Media Grid
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("media_grid")
            ) {
                items(filteredItems, key = { it.id }) { item ->
                    val isSelected = selectedIds.contains(item.id)
                    val selectIndex = if (isSelected) {
                        selectedIds.toList().indexOf(item.id) + 1
                    } else null

                    MediaThumbnailCard(
                        item = item,
                        isSelected = isSelected,
                        selectionOrder = selectIndex,
                        onToggle = { onToggleSelect(item.id) }
                    )
                }
            }
        }
    }
}

@Composable
fun MediaLibraryTopBar(
    onBack: () -> Unit,
    onImportGallery: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Outlined.ArrowBack,
                    contentDescription = "Back",
                    tint = TextPrimary,
                    modifier = Modifier.size(20.dp)
                )
            }
            Column {
                Text(
                    text = "MEDIA BROWSER",
                    style = TimecodeStyleSmall,
                    color = AccentCoolBlue,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Device Storage & Recents",
                    fontFamily = FontFamily.SansSerif,
                    fontSize = 11.sp,
                    color = TextSecondary
                )
            }
        }

        Button(
            onClick = onImportGallery,
            shape = RoundedCornerShape(4.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = AccentCoolBlue,
                contentColor = BgPureDark
            ),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
            modifier = Modifier.height(32.dp).testTag("import_gallery_media_button")
        ) {
            Icon(
                imageVector = Icons.Outlined.PhotoLibrary,
                contentDescription = null,
                tint = BgPureDark,
                modifier = Modifier.size(15.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "Pick Gallery",
                fontFamily = FontFamily.SansSerif,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = BgPureDark
            )
        }
    }
}

@Composable
fun CategoryFilterRow(
    selected: MediaTypeCategory,
    onSelect: (MediaTypeCategory) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        MediaTypeCategory.values().forEach { cat ->
            val isSel = selected == cat
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (isSel) AccentCoolBlueSubtle else PanelDark)
                    .border(
                        1.dp,
                        if (isSel) AccentCoolBlue else PanelBorder,
                        RoundedCornerShape(4.dp)
                    )
                    .clickable { onSelect(cat) }
                    .padding(vertical = 7.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = cat.name.lowercase().replaceFirstChar { it.uppercase() },
                    style = TimecodeStyleSmall,
                    color = if (isSel) TextWhite else TextSecondary
                )
            }
        }
    }
}

@Composable
fun MediaThumbnailCard(
    item: MediaItem,
    isSelected: Boolean,
    selectionOrder: Int?,
    onToggle: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .clip(RoundedCornerShape(4.dp))
            .background(PanelDark)
            .border(
                1.5.dp,
                if (isSelected) AccentCoolBlue else PanelBorder,
                RoundedCornerShape(4.dp)
            )
            .clickable(onClick = onToggle)
    ) {
        // Thumbnail Image
        if (!item.contentUri.isNullOrBlank()) {
            AsyncImage(
                model = item.contentUri,
                contentDescription = item.title,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else if (item.thumbnailRes != null) {
            Image(
                painter = painterResource(id = item.thumbnailRes),
                contentDescription = item.title,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else {
            Box(
                modifier = Modifier.fillMaxSize().background(PanelDarkElevated),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Outlined.PhotoLibrary,
                    contentDescription = item.title,
                    tint = AccentCoolBlue,
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        // Dark gradient scrim overlay
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    if (isSelected) AccentCoolBlue.copy(alpha = 0.25f)
                    else Color.Black.copy(alpha = 0.3f)
                )
        )

        // Duration or Resolution badge bottom-start
        Box(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(4.dp)
                .background(BgPureDark.copy(alpha = 0.8f), RoundedCornerShape(2.dp))
                .padding(horizontal = 4.dp, vertical = 2.dp)
        ) {
            Text(
                text = if (item.durationSec > 0) formatShortDuration(item.durationSec) else "PHOTO",
                fontFamily = MonoTimecodeFont,
                fontSize = 9.sp,
                color = TextWhite
            )
        }

        // Selection Checkmark badge top-end
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(6.dp)
                .size(20.dp)
                .clip(CircleShape)
                .background(if (isSelected) AccentCoolBlue else BgPureDark.copy(alpha = 0.7f))
                .border(1.dp, if (isSelected) AccentCoolBlue else PanelBorderActive, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (isSelected) {
                Text(
                    text = "${selectionOrder ?: 1}",
                    fontFamily = MonoTimecodeFont,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    color = BgPureDark
                )
            }
        }
    }
}

@Composable
fun SelectedMediaActionBar(
    selectedCount: Int,
    onClear: () -> Unit,
    onAdd: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = PanelDarkElevated,
        tonalElevation = 0.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, PanelBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "$selectedCount SELECTED",
                    style = TimecodeStyleSmall,
                    color = TextPrimary
                )
                TextButton(onClick = onClear) {
                    Text("Clear", style = TimecodeStyleSmall, color = TextMuted)
                }
            }

            Button(
                onClick = onAdd,
                shape = RoundedCornerShape(4.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = AccentCoolBlue,
                    contentColor = BgPureDark
                ),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                modifier = Modifier.testTag("add_selected_media_button")
            ) {
                Text(
                    text = "Add to Timeline ($selectedCount)",
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Medium,
                    fontSize = 12.sp,
                    color = BgPureDark
                )
            }
        }
    }
}
