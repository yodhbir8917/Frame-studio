package com.example.model

enum class AspectRatio(val label: String, val ratio: Float, val platformBadge: String? = null) {
    ORIGINAL("Original", 9f / 16f, null),
    VERTICAL_9_16("9:16", 9f / 16f, "TikTok"),
    CINEMA_16_9("16:9", 16f / 9f, "YouTube"),
    SQUARE_1_1("1:1", 1f / 1f, "Instagram"),
    STANDARD_4_3("4:3", 4f / 3f, null),
    PORTRAIT_3_4("3:4", 3f / 4f, null),
    PORTRAIT_4_5("4:5", 4f / 5f, null),
    ANAMORPHIC_239("2.35:1", 2.35f / 1f, "Cinema")
}

enum class Resolution(val label: String, val dimensions: String, val bitMultiplier: Float) {
    HD_720P("720p HD", "1280 × 720", 0.6f),
    FHD_1080P("1080p FHD", "1920 × 1080", 1.0f),
    QHD_2K("2K QHD", "2560 × 1440", 1.8f),
    UHD_4K("4K UHD", "3840 × 2160", 2.8f)
}

enum class TrackType {
    TEXT,
    VIDEO,
    AUDIO
}

data class TimelineClip(
    val id: String,
    val name: String,
    val startTimeSec: Float,
    val durationSec: Float,
    val thumbnailRes: Int? = null,
    val contentUri: String? = null,
    val waveformPoints: List<Float> = emptyList(),
    val textOverlay: String? = null,
    val speed: Float = 1.0f,
    val volume: Float = 1.0f,
    val opacity: Float = 1.0f,
    val transitionIn: String? = null,
    val isReversed: Boolean = false,
    val isFrozen: Boolean = false,
    val hasKeyframe: Boolean = false,
    val noiseReduced: Boolean = false,
    val voiceIsolated: Boolean = false,
    val backgroundRemoved: Boolean = false,
    val activeMask: String? = null,
    val activeAnimation: String? = null
) {
    val endTimeSec: Float get() = startTimeSec + durationSec
}

data class TimelineTrack(
    val id: String,
    val type: TrackType,
    val title: String,
    val clips: List<TimelineClip>,
    val isMuted: Boolean = false,
    val isLocked: Boolean = false
)

data class Project(
    val id: String,
    val name: String,
    val thumbnailRes: Int,
    val durationSec: Float,
    val lastEdited: String,
    val aspectRatio: AspectRatio = AspectRatio.VERTICAL_9_16,
    val fps: Int = 30,
    val resolution: Resolution = Resolution.UHD_4K,
    val tracks: List<TimelineTrack> = emptyList(),
    val isAudioMutedGlobally: Boolean = false,
    val coverTimeSec: Float = 0f
)

enum class SubToolbarType {
    AUDIO_MENU,
    TEXT_MENU,
    EFFECTS_MENU,
    OVERLAY_MENU,
    CAPTIONS_MENU,
    FILTERS_SHEET,
    ADJUST_SHEET,
    STICKERS_SHEET,
    ASPECT_RATIO_SHEET,
    BACKGROUND_SHEET,
    ANIMATIONS_SHEET,
    AUTO_CAPTIONS_MODAL,
    COVER_PICKER_MODAL
}

enum class ToolPanelType(val label: String) {
    NONE("None"),

    // Sequence-level tools (Default when NO clip is selected)
    EDIT("Edit"),
    AUDIO("Audio"),
    TEXT("Text"),
    EFFECTS("Effects"),
    TRANSITIONS("Transitions"),
    OVERLAY("Overlay"),
    CAPTIONS("Captions"),
    FILTERS("Filters"),
    ADJUST("Adjust"),
    COLOR("Color"),
    STICKERS("Stickers"),
    ASPECT_RATIO("Aspect ratio"),
    BACKGROUND("Background"),

    // Clip-level tools (When video clip IS selected)
    SPLIT("Split"),
    SPEED("Speed"),
    VOLUME("Volume"),
    ANIMATIONS("Animations"),
    CROP("Crop"),
    DELETE("Delete"),
    BEATS("Beats"),
    DUPLICATE("Duplicate"),
    REPLACE("Replace"),
    TRANSFORM("Transform"),
    AUTO_REFRAME("Auto reframe"),
    STABILIZE("Stabilize"),
    CAMERA_TRACKING("Camera tracking"),
    EXTRACT_AUDIO("Extract audio"),
    ISOLATE_VOICE("Isolate voice"),
    REDUCE_NOISE("Reduce noise"),
    AUDIO_EFFECTS("Audio effects"),
    ENHANCE_VOICE("Enhance voice"),
    FREEZE("Freeze"),
    REVERSE("Reverse"),
    MASK("Mask"),
    REMOVE_BG("Remove BG"),
    RELIGHT("Relight"),
    OPACITY("Opacity"),
    MOTION_BLUR("Motion blur"),
    RETOUCH("Retouch"),
    VIDEO_QUALITY("Video quality"),
    UNLINK("Unlink")
}

data class FilterItem(
    val id: String,
    val name: String,
    val category: String,
    val isPro: Boolean = false
)

data class ColorGradeSettings(
    val exposure: Float = 0f,
    val contrast: Float = 0f,
    val brightness: Float = 0f,
    val highlights: Float = 0f,
    val shadows: Float = 0f,
    val temperature: Float = 0f,
    val tint: Float = 0f,
    val saturation: Float = 0f,
    val sharpen: Float = 0f,
    val selectedLut: String = "Clear I"
)

data class ExportConfig(
    val resolution: Resolution = Resolution.UHD_4K,
    val frameRate: Int = 30,
    val quality: String = "High (24 Mbps)",
    val format: String = "MP4 (H.264)",
    val audioCodec: String = "AAC 320 kbps (48kHz)"
)

enum class MediaTypeCategory {
    ALL,
    VIDEOS,
    PHOTOS,
    MUSIC
}

data class MediaItem(
    val id: String,
    val title: String,
    val category: MediaTypeCategory,
    val thumbnailRes: Int? = null,
    val durationSec: Float = 0f,
    val resolution: String = "4K",
    val fileSize: String = "150 MB",
    val contentUri: String? = null
)

data class TemplateItem(
    val id: String,
    val title: String,
    val category: String,
    val aspectRatio: AspectRatio,
    val durationSec: Float,
    val clipCount: Int,
    val thumbnailRes: Int,
    val description: String
)

// Helper formatting function for video timecodes HH:MM:SS:FF or MM:SS:FF
fun formatTimecode(seconds: Float, fps: Int = 30): String {
    val totalSeconds = seconds.toInt().coerceAtLeast(0)
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val secs = totalSeconds % 60
    val fractional = (seconds - totalSeconds).coerceAtLeast(0f)
    val frames = (fractional * fps).toInt().coerceIn(0, fps - 1)
    return String.format("%02d:%02d:%02d:%02d", hours, minutes, secs, frames)
}

fun formatShortDuration(seconds: Float): String {
    val totalSeconds = seconds.toInt().coerceAtLeast(0)
    val minutes = totalSeconds / 60
    val secs = totalSeconds % 60
    return String.format("%02d:%02d", minutes, secs)
}
